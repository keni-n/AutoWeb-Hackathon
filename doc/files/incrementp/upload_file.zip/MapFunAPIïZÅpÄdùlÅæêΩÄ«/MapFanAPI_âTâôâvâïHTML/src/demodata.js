var datailHeader = "<p><strong>◆説明</strong><br>";
var srcHeader = "<div class='article'>";
var srcFooter = "</div></p>";

var demoText = [

{
title: "1.地図表示",
sum: "<p>本サービスの基本となる認証処理と地図表示のコードが確認できます。</p>",
detail: "\
HTMLのBODYタグの初期処理 onload にて、認証リクエストの処理 auth メソッドを実行します。\
認証手続きが完了すると、上記 auth メソッドで指定されたコールバック関数 task_func を呼び出します。\
関数 task_func 内では、mapCreate メソッドにて、指定されたDIVタグ上に地図画像を作成します。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１．地図表示 ＊＊＊<br>\
<br>\
    //### イニシャル処理 ###<br>\
    // 本サンプルページ読み出し時に本関数が呼ばれます。<br>\
    window.onload = function() {<br>\
<br>\
      //### サーバ名設定 ###<br>\
      // 利用する地図APIサーバ名を設定します。<br>\
      // なお、このサンプルではテスト利用サーバー名を設定しています。<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
<br>\
      //### 認証リクエスト処理 ###<br>\
      // 認証APIの実行要求を行います。<br>\
      // 第１パラメータには、お客様専用に発行した顧客IDを設定します。<br>\
      // 第２パラメータには、認証手続き完了後に呼び出すコールバック関数を設定します。<br>\
      Mfapi.auth( &#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 各種処理 ###<br>\
    function task_func(authStatus) {<br>\
<br>\
      //### 認証結果確認 ###<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        // 認証手続き処理失敗時の処理コードをここに記述してください<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // 地図作成条件をセット。<br>\
      // このサンプルでは地図初期の中心緯度経度とスケールを指定します。<br>\
      // 詳細はMapOptionsクラスの仕様をご参照下さい。<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.70030321482975,35.68955994193983),<br>\
        mapScale : 16<br>\
      };<br>\
<br>\
      //### 地図作成処理 ###<br>\
      // 地図作成処理メソッドを実行。id=&#x27;sample_map&#x27;のDIVタグ上に地図を生成します。<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample1.html"
},

{
title: "2.図形表示",
sum: "<p>サークル、ポリゴン等の図形表示の基本的なコードが確認できます。</p>",
detail: "\
地図作成後にジオメトリーレイヤーを追加します。サークル、ポリゴン、ポリラインの条件を作成したら、\
addCircle , addPolygon, addPolyline のメソッドで、ジオメトリーレイヤーに登録すると、各図形が地図上に表示されます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル２&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル２．図形表示 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),<br>\
        mapScale : 11<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### ジオメトリーレイヤー追加 ###<br>\
      // ジオメトリーレイヤーを生成し、地図のあるDIVタグに追加します。<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer&#x27;);<br>\
<br>\
      //### サークル　条件セット ###<br>\
      // サークルオブジェクト object#1 用の作成条件 opt1 を作成します。<br>\
      // 詳細はCircleOptionsクラスの仕様をご参照下さい。<br>\
      var opt1 = {<br>\
        edgeColor : &#x27;#ff0000&#x27;, // 枠線の色<br>\
        edgeWidth : 4, // 枠線の幅<br>\
        fillColor : &#x27;#00ff00&#x27;, // 塗り色<br>\
        opacity : 0.5, // 不透明度<br>\
        position :  new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),  // 東京駅<br>\
        radius : 1600, // 半径<br>\
        visible : true // 表示状態<br>\
      };<br>\
<br>\
      //### ポリゴン　条件セット ###<br>\
      // ポリゴンオブジェクト object#2 用の作成条件 opt2 を作成します。<br>\
      // 詳細はPolygonOptionsクラスの仕様をご参照下さい。<br>\
      var opt2 = {<br>\
        edgeColor : &#x27;#ff00ff&#x27;, // 枠線の色<br>\
        edgeWidth : 4, // 枠線の幅<br>\
        fillColor : &#x27;#00ff00&#x27;, // 塗り色<br>\
        opacity : 0.5, // 不透明度<br>\
        positions : [<br>\
           new Mfapi.Util.LonLat(139.75821002138233,35.66657238126213),  // 新橋駅<br>\
           new Mfapi.Util.LonLat(139.7959191978587,35.655211407306176),  // 豊洲駅<br>\
           new Mfapi.Util.LonLat(139.79315890678254,35.63467955160454),  // 有明駅<br>\
           new Mfapi.Util.LonLat(139.73875357500563,35.62850770123775),  // 品川駅<br>\
           new Mfapi.Util.LonLat(139.70134957426947,35.65864567145413)  // 渋谷駅<br>\
          ],<br>\
        visible : true // 表示状態<br>\
      };<br>\
<br>\
      //### ポリライン　条件セット ###<br>\
      // ポリラインオブジェクト object#3 用の作成条件 opt3 を作成します。<br>\
      // 詳細はPolylineOptionsクラスの仕様をご参照下さい。<br>\
      var opt3 = {<br>\
        lineColor : &#x27;#0000ff&#x27;, // 線の色<br>\
        lineWidth : 4, // 線の幅<br>\
        opacity : 0.8, // 不透明度<br>\
        positions : [<br>\
            new Mfapi.Util.LonLat(139.70090283767686,35.68851826791775),  // 新宿駅<br>\
            new Mfapi.Util.LonLat(139.7108740987224,35.72992490706989),  // 池袋駅<br>\
            new Mfapi.Util.LonLat(139.77649106403516,35.713413463237565),  // 上野駅<br>\
            new Mfapi.Util.LonLat(139.8166571438273,35.718386818767186),  // 曳舟駅<br>\
            new Mfapi.Util.LonLat(139.826947289596,35.69723830373342),  // 亀戸駅<br>\
            new Mfapi.Util.LonLat(139.77311565279877,35.69837872503799)  // 秋葉原駅<br>\
          ],<br>\
        visible : true // 表示状態<br>\
      };<br>\
<br>\
      //### 図形作成＆レイヤー追加 ###<br>\
      // オブジェクト作成＋ジオメトリーレイヤーへの登録を行います。<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addCircle(opt1,&#x27;object#1&#x27;);<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolygon(opt2,&#x27;object#2&#x27;);<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolyline(opt3,&#x27;object#3&#x27;);<br>\
<br>\
      //### 補足 ###<br>\
      // 上記コードでは、オブジェクト作成とレイヤーへの登録を一緒に行うメソッドを用いて<br>\
      // いますが、下記のように２つのメソッドに分けて記述することも可能です。<br>\
      // (サークルの場合)<br>\
      //   オブジェクト生成：<br>\
      //     Mfapi.Features.createCircle(opt1,&#x27;object#1&#x27;);<br>\
      //   レイヤー登録：<br>\
      //     Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].attached(Mfapi.Features.Circle[&#x27;object#1&#x27;]);<br>\
<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample2.html"
},

{
title: "3.マーカー・ポップアップ表示",
sum: "<p>地点データ列を用いたマーカー表示、およびポップアップ表示設定の基本的なコードが確認できます。</p>",
detail: "\
ポップアップの表示オプションを設定し、地図作成します。その後マーカーレイヤーを追加します。\
次に、createPopUpメソッドでポップアップを生成後、条件にポップアップのフィーチャー識別子をセットして、addMarkerメソッドを実行します。\
このメソッドにより、マーカー生成とマーカーレイヤーへの登録が行われ、地図画面上にマーカーが表示されます。\
また、マーカーをクリックすると最初に設定した内容に従ってポップアップが表示されます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル３&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
    //＊＊＊ サンプル３．マーカー・ポップアップ表示 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // 地図作成条件をセット。<br>\
      // ポップアップ一括非表示モード(hidePopUpOnMapClick)プロパティにtrueを設定し、一括非表示を可能とします。<br>\
      // ポップアップの単一表示モード(singlePopUp)プロパティにtrueを設定し、ポップアップ単一表示を可能とします。<br>\
      // ポップアップの表示タイミング(popUpDisplayMode)プロパティに2を設定し、マーカーからマウス(指)を離した時にポップアップ表示を可能にします。<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12,<br>\
        hidePopUpOnMapClick : true,<br>\
        singlePopUp : true,<br>\
        popUpDisplayMode : 2<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### 地点データ列セット ###<br>\
      var pointData = [<br>\
        { name: &#x27;東京本社ビル&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;東京本社ビル&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/a.gif&#x27;, width:48, height:48, x:-24, y:-36 },<br>\
        { name: &#x27;新橋営業所&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新橋営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 10:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;豊洲配送事業所&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;豊洲配送事業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/b.gif&#x27;, width:48, height:48, x:-24, y:-30  },<br>\
        { name: &#x27;有明駅営業所&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;有明駅営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 11:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;品川営業所&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;品川営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;渋谷営業所&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;渋谷営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;新宿営業所&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新宿営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 ２４時間営業&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 6 }<br>\
      ];<br>\
<br>\
      //### マーカーレイヤー追加 ###<br>\
      // マーカーメトリーレイヤーを生成し、地図のあるDIVタグに追加します。<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### マーカー、ポップアップ作成ループ処理 ###<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
<br>\
        //### ポップアップ　フィーチャー識別子作成および条件セット ###<br>\
        // ポップアップ用にユニークなフィーチャー識別子 id1を生成します。<br>\
        // また、ポップアップ用の作成条件 opt1 を作成します。<br>\
        // 詳細はPopUpOptionsクラスの仕様をご参照下さい。<br>\
        var id1 = &#x27;popup#&#x27;+i;<br>\
        var opt1 = {<br>\
          size : new Mfapi.Util.ScreenSize(180,80),<br>\
          popUpType : pointData[i].popUpType,<br>\
          contentHtml : pointData[i].text,<br>\
          visible : false<br>\
        };<br>\
<br>\
        //### ポップアップ作成 ###<br>\
        // ポップアップのオブジェクトを生成します。<br>\
        Mfapi.Features.createPopUp(opt1, id1);<br>\
<br>\
        //### マーカー　フィーチャー識別子作成および条件セット ###<br>\
        // マーカー用にユニークなフィーチャー識別子 id2を生成します。<br>\
        // また、マーカー用の作成条件 opt2 を作成します。<br>\
        // このサンプルでは本サービスで用意された画像を使うケースと、お客様が用意<br>\
        // した画像を使うケースの２種類に対応しています。<br>\
        // また、フィールド popUpKey にて、上記ポップアップと紐付けています。<br>\
        // 詳細はMarkerOptionsクラスの仕様をご参照下さい。<br>\
        var id2 = &#x27;marker#&#x27;+i;<br>\
        var opt2 = {<br>\
          position : new Mfapi.Util.LonLat(pointData[i].lon, pointData[i].lat),<br>\
          popUpKey : id1<br>\
        };<br>\
        if( pointData[i].imageUrl !== undefined ) {<br>\
          opt2.imageUrl = pointData[i].imageUrl;<br>\
          opt2.imageSize = new Mfapi.Util.ScreenSize(pointData[i].width, pointData[i].height);<br>\
          opt2.imageOffset = new Mfapi.Util.ScreenPoint(pointData[i].x, pointData[i].y);<br>\
          opt2.imageOpacity = 0.8;<br>\
        } else {<br>\
          opt2.markerType = pointData[i].markerType;<br>\
        }<br>\
<br>\
        //### マーカー作成＆レイヤー追加 ###<br>\
        // オブジェクト作成＋マーカーレイヤーへの登録を行います。<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt2, id2);<br>\
      }<br>\
<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample3.html"
},

{
title: "4.コントローラー設定",
sum: "<p>ズームボタンなどのコントローラーの表示ON/OFF、およびカスタマイズ方法の確認ができます。</p>",
detail: "\
本サンプルでは、ズームボタン、スケールスライダー、スケーラーのコントローラーの表示ON/OFF、\
および各パーツのタイプや色などの属性の設定方法が確認できます。\
また、地図中心点を示すDIVタグの作成方法も本サンプルにて確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル４&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
      outline: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--地図中心を示すパーツのアイコン画像とDIVのスタイル：<br>\
    地図画像地図画面の中央座標を計算して、イメージを配置するだけで、中心点パーツを<br>\
    表示することができます。位置計算は下記を参考にしてください。（お客様の地図DIVの<br>\
    配置方法に合わせて、微調整してください。）<br>\
      left:[地図DIV幅]/2+[マージン]-[中心アイコン幅]/2 =660/2+10-34/2=323<br>\
      top: [地図DIV高さ]/2+[マージン]-[中心アイコン高さ]/2 =280/2+10-30/2=135 --&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #center_image {<br>\
      width: 34px;<br>\
      height: 30px;<br>\
    }<br>\
    #center_div {<br>\
      z-index: 5000000;<br>\
      position: absolute;<br>\
      left: 323px;<br>\
      top: 135px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル４．コントローラー設定 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // このサンプルでは中心緯度経度とスケールに加え、地図コントローラの設定も<br>\
      // 指定します。詳細はMapOptionsクラスの仕様をご参照下さい。<br>\
      // なお、説明上、このサンプルではズームボタンとスケールスライダーの両方を<br>\
      // 表示させていますが、片方のみを表示させることを推奨します。<br>\
      var options = {<br>\
<br>\
        //### ズームボタン ###<br>\
        zoomButtonShown: true, // 表示ON-OFF<br>\
        zoomButtonTextColor: &#x27;#000088&#x27;, // ボタン文字色<br>\
        zoomButtonColor: &#x27;#888888&#x27;, // ボタン色<br>\
        zoomButtonOpacity: 0.7, // 不透明度<br>\
        zoomButtonSize: new Mfapi.Util.ScreenSize(32,32), // ボタンサイズ<br>\
        zoomButtonOffset: new Mfapi.Util.ScreenPoint(48,10), // 表示位置<br>\
<br>\
        //### スケールスライダー ###<br>\
        scaleSliderShown: true, // 表示ON-OFF<br>\
        scaleSliderType: Mfapi.Const.ScaleSliderType.STANDARD_SIZE, // タイプ<br>\
        scaleSliderOffset: new Mfapi.Util.ScreenPoint(13,10), // 表示位置<br>\
<br>\
        //### スケーラー ###<br>\
        scalerShown: true, // 表示ON-OFF<br>\
        scalerType: Mfapi.Const.ScalerType.MI_FT, // タイプ<br>\
        scalerOffset: new Mfapi.Util.ScreenPoint(10,15), // 表示位置<br>\
<br>\
        //--- 中心緯度経度とスケール：サンプル１参照 ---<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),<br>\
        mapScale : 11<br>\
      };<br>\
<br>\
      //--- 地図作成：サンプル１参照 ---<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地図中心を示すパーツのDIVタグ--&gt;<br>\
  &lt;div id=&#x27;center_div&#x27;&gt;&lt;img id=&#x27;center_image&#x27; src=&#x27;img/center.png&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample4.html"
},

{
title: "5.地図描画設定",
sum: "<p>地図のデザインやタイルサイズなどの設定方法の確認ができます。</p>",
detail: "\
本サンプルでは、地図のデザイン、ロゴ、言語(外国語地図は追加オプション)、タイルサイズの\
パラメータの設定方法が確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル５&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル５．地図描画設定 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // このサンプルでは中心緯度経度とスケールに加え、地図描画に関する設定も指定します。<br>\
      // 詳細はMapOptionsクラスの仕様をご参照下さい。<br>\
      var options = {<br>\
<br>\
        //### 地図表示スタイル ###<br>\
        mapStyle: &#x27;std_sp&#x27;, // 地図配信API mapstyle パラメータ<br>\
<br>\
        //### 地図ロゴマークアイコン表示設定 ###<br>\
        logoSettings: &#x27;on&#x27;, // 地図配信API logo パラメータ<br>\
<br>\
        //### 地図注記表示言語 ###<br>\
        language: &#x27;ja&#x27;, // 地図配信API lang パラメータ<br>\
<br>\
        //### タイルサイズ ###<br>\
        // 地図タイルサイズの指定を行います。<br>\
        // スマートフォン等の高精細モニターで利用するとき、地図表示が<br>\
        // 細かすぎて、見にくくなるのを防ぎたいときに利用します。<br>\
        tileSize: 512, // ２倍設定(標準のデフォルトは256px)<br>\
<br>\
        //--- 中心緯度経度とスケール：サンプル１参照 ---<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
<br>\
      //--- 地図作成：サンプル１参照 ---<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample5.html"
},

{
title: "6.地図操作",
sum: "<p>地図操作に関する各種コードが確認できます。</p>",
detail: "\
本サンプルでは、地図状態変化時に発行されるイベントを受け取って、中心緯度経度およびスケールを表示します。\
また、マウスやタップによる地図操作の許可・禁止制御の方法や、カーソルキーによる地図移動の操作を\
有効にする方法も、合わせて本サンプルにて確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル６&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル：<br>\
    本サンプルではフォーカスが当たったときに枠線が出ないように、outlineをnoneとしています。--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      float: left;<br>\
      width: 480px;<br>\
      height: 280px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
      outline: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--情報表示DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #info {<br>\
      float: left;<br>\
      margin: 4px;<br>\
      padding: 4px;<br>\
      background-color:#eeeeee;<br>\
    }<br>\
    .value1 {<br>\
      width: 130px;<br>\
    }<br>\
    .value2 {<br>\
      width: 36px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--地図中心を示すパーツのアイコン画像とDIVのスタイル：サンプル４参照--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #center_image {<br>\
      width: 34px;<br>\
      height: 30px;<br>\
    }<br>\
    #center_div {<br>\
      position: absolute;<br>\
      z-index: 5000000;<br>\
      left: 233px;<br>\
      top: 135px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル６．地図操作 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // このサンプルでは中心緯度経度とスケールに加え、地図操作に関する設定も指定します。<br>\
      // 詳細はMapOptionsクラスの仕様をご参照下さい。<br>\
      var options = {<br>\
<br>\
        //### 地図操作の許可、禁止設定 ###<br>\
        // マウスやタッチなどの操作による地図の緯度経度やスケール変更の機能の<br>\
        // 許可、禁止ができます。<br>\
        mapOperationEnable: true,<br>\
<br>\
        //--- 中心緯度経度とスケール：サンプル１参照 ---<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
<br>\
      //--- 地図作成：サンプル１参照 ---<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### 地図中心緯度経度変更時の処理 ###<br>\
      function map_position_event(position) {<br>\
<br>\
        //### 情報表示：中心緯度経度を代入 ###<br>\
        document.getElementById(&#x27;lon&#x27;).value = position.lon;<br>\
        document.getElementById(&#x27;lat&#x27;).value = position.lat;<br>\
      }<br>\
<br>\
      //### 地図スケール変更時の処理 ###<br>\
      function map_scale_event(scale) {<br>\
<br>\
        //### 情報表示：スケールを代入 ###<br>\
        document.getElementById(&#x27;scale&#x27;).value = scale;<br>\
      }<br>\
<br>\
      //### 地図状態変更イベントのコールバック関数をセット ###<br>\
      Mfapi.Events.onChangedMapCenter = map_position_event;<br>\
      Mfapi.Events.onChangedMapScale = map_scale_event;<br>\
<br>\
      //### 初期の地図DIVのフォーカスをonに設定 ###<br>\
      // 地図のDIVにフォーカスが当たったときに、カーソルキーで地図スクロールが可能。<br>\
      // 初期状態は強制的に地図のDIVにフォーカスを当てます。<br>\
      document.getElementById(&#x27;sample_map&#x27;).focus();<br>\
<br>\
      //### 情報表示：初期の中心緯度経度、スケール、フォーカスを代入 ###<br>\
      var scale = Mfapi.Map.getMapScale();<br>\
      var position = Mfapi.Map.getCenterPosition();<br>\
      document.getElementById(&#x27;scale&#x27;).value = scale;<br>\
      document.getElementById(&#x27;lon&#x27;).value = position.lon;<br>\
      document.getElementById(&#x27;lat&#x27;).value = position.lat;<br>\
      document.getElementById(&#x27;key-ctrl&#x27;).value = &#x27;on&#x27;;<br>\
    }<br>\
    //### フォーカスの状態表示(on/off) ###<br>\
    function onMapFocus() {<br>\
      document.getElementById(&#x27;key-ctrl&#x27;).value = &#x27;on&#x27;;<br>\
    }<br>\
    function onMapBlur() {<br>\
      document.getElementById(&#x27;key-ctrl&#x27;).value = &#x27;off&#x27;;<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ：地図画面にフォーカスがあたるようにtabindexを追記しています。--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27; tabindex=&#x27;1&#x27; onfocus=&#x27;onMapFocus();&#x27;  onblur=&#x27;onMapBlur();&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--情報表示DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info&#x27;&gt;<br>\
    &lt;p&gt;経度(longitude)：&lt;br&gt;<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;lon&#x27; class=&#x27;value1&#x27; tabindex=&#x27;2&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
    &lt;p&gt;緯度(latitude)：&lt;br&gt;<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;lat&#x27; class=&#x27;value1&#x27; tabindex=&#x27;3&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
    &lt;p&gt;スケール：<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;scale&#x27; class=&#x27;value2&#x27; tabindex=&#x27;4&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
    &lt;p&gt;フォーカス：<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;key-ctrl&#x27; class=&#x27;value2&#x27; tabindex=&#x27;5&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--地図中心を示すパーツのDIVタグ--&gt;<br>\
  &lt;div id=&#x27;center_div&#x27;&gt;&lt;img id=&#x27;center_image&#x27; src=&#x27;img/center.png&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample6.html"
},

{
title: "7.図形の制御",
sum: "<p>図形の表示ON/OFF制御や属性変更のコードが確認できます。</p>",
detail: "\
本サンプルでは、サークル、ポリゴン、ポリラインの図形の表示ON/OFFをチェックボックスで制御するコードと、\
サークルの半径(m)、ポリゴンの塗り色、ポリラインの線の幅(px)を書き換えるコードが確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル７&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      float: left;<br>\
      width: 440px;<br>\
      height: 280px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--情報表示DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #info {<br>\
      float: left;<br>\
      margin: 4px;<br>\
      padding: 4px;<br>\
      background-color:#eeeeee;<br>\
    }<br>\
    .indent1 {<br>\
      margin-left: 1.2em;<br>\
    }<br>\
    .value1 {<br>\
      width: 60px;<br>\
    }<br>\
    .button1 {<br>\
      width: 40px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル７．図形の制御 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    var opt1 = {};<br>\
    var opt2 = {};<br>\
    var opt3 = {};<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),<br>\
        mapScale : 11<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //--- ジオメトリーレイヤー、図形追加：サンプル２参照 ---<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer&#x27;);<br>\
      opt1 = {<br>\
        edgeColor : &#x27;#ff0000&#x27;, // 枠線の色<br>\
        edgeWidth : 4, // 枠線の幅<br>\
        fillColor : &#x27;#00ff00&#x27;, // 塗り色<br>\
        opacity : 0.5, // 不透明度<br>\
        position :  new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),  // 東京駅<br>\
        radius : 1600, // 半径<br>\
        visible : true // 表示状態<br>\
      };<br>\
      opt2 = {<br>\
        edgeColor : &#x27;#ff00ff&#x27;, // 枠線の色<br>\
        edgeWidth : 4, // 枠線の幅<br>\
        fillColor : &#x27;#00ff00&#x27;, // 塗り色<br>\
        opacity : 0.5, // 不透明度<br>\
        positions : [<br>\
           new Mfapi.Util.LonLat(139.75821002138233,35.66657238126213),  // 新橋駅<br>\
           new Mfapi.Util.LonLat(139.7959191978587,35.655211407306176),  // 豊洲駅<br>\
           new Mfapi.Util.LonLat(139.79315890678254,35.63467955160454),  // 有明駅<br>\
           new Mfapi.Util.LonLat(139.73875357500563,35.62850770123775),  // 品川駅<br>\
           new Mfapi.Util.LonLat(139.70134957426947,35.65864567145413)  // 渋谷駅<br>\
          ],<br>\
        visible : true // 表示状態<br>\
      };<br>\
      opt3 = {<br>\
        lineColor : &#x27;#0000ff&#x27;, // 線の色<br>\
        lineWidth : 4, // 線の幅<br>\
        opacity : 0.8, // 不透明度<br>\
        positions : [<br>\
            new Mfapi.Util.LonLat(139.70090283767686,35.68851826791775),  // 新宿駅<br>\
            new Mfapi.Util.LonLat(139.7108740987224,35.72992490706989),  // 池袋駅<br>\
            new Mfapi.Util.LonLat(139.77649106403516,35.713413463237565),  // 上野駅<br>\
            new Mfapi.Util.LonLat(139.8166571438273,35.718386818767186),  // 曳舟駅<br>\
            new Mfapi.Util.LonLat(139.826947289596,35.69723830373342),  // 亀戸駅<br>\
            new Mfapi.Util.LonLat(139.77311565279877,35.69837872503799)  // 秋葉原駅<br>\
          ],<br>\
        visible : true // 表示状態<br>\
      };<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addCircle(opt1,&#x27;object#1&#x27;);<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolygon(opt2,&#x27;object#2&#x27;);<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolyline(opt3,&#x27;object#3&#x27;);<br>\
<br>\
      //### 表示ON/OFFチェックボックスの初期状態セット ###<br>\
      document.getElementById(&#x27;chk1&#x27;).checked = true;<br>\
      document.getElementById(&#x27;chk2&#x27;).checked = true;<br>\
      document.getElementById(&#x27;chk3&#x27;).checked = true;<br>\
<br>\
      //### 属性入力テキストボックスの初期状態セット(半径、塗色、線幅) ###<br>\
      document.getElementById(&#x27;para1&#x27;).value = opt1.radius;<br>\
      document.getElementById(&#x27;para2&#x27;).value = opt2.fillColor;<br>\
      document.getElementById(&#x27;para3&#x27;).value = opt3.lineWidth;<br>\
    }<br>\
<br>\
    //### サークルの表示ON/OFF制御 ###<br>\
    function chkCircle(status) {<br>\
<br>\
      //### チェックボックスの状態をオブジェクト側に反映 ###<br>\
      Mfapi.Features.Circle[&#x27;object#1&#x27;].setVisible(status);<br>\
    }<br>\
<br>\
    //### ポリゴンの表示ON/OFF制御 ###<br>\
    function chkPolygon(status) {<br>\
<br>\
      //### チェックボックスの状態をオブジェクト側に反映 ###<br>\
      Mfapi.Features.Polygon[&#x27;object#2&#x27;].setVisible(status);<br>\
    }<br>\
<br>\
    //### ポリラインの表示ON/OFF制御 ###<br>\
    function chkPolyline(status) {<br>\
<br>\
      //### チェックボックスの状態をオブジェクト側に反映 ###<br>\
      Mfapi.Features.Polyline[&#x27;object#3&#x27;].setVisible(status);<br>\
    }<br>\
<br>\
    //### サークル：半径の更新 ###<br>\
    // 図形オブジェクトの各属性値を直接変更するメソッドはないため、一度該当オブジェクトを<br>\
    // 削除してから、同じフィーチャーIDで、該当属性値を変えた条件を使って、オブジェクトを<br>\
    // 再作成します。なお、マーカーも同様の方法で属性を変更することができます。<br>\
    function updateCircle() {<br>\
<br>\
      //### オブジェクト削除 ###<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].removeFeature(&#x27;object#1&#x27;);<br>\
<br>\
      //### テキストボックスから属性値を取得 ###<br>\
      opt1.radius = parseInt(document.getElementById(&#x27;para1&#x27;).value);<br>\
<br>\
      //### オブジェクト作成＆レイヤー登録 ###<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addCircle(opt1,&#x27;object#1&#x27;);<br>\
<br>\
      //### チェックボックスの状態を表示ONとする ###<br>\
      document.getElementById(&#x27;chk1&#x27;).checked = true;<br>\
    }<br>\
<br>\
    //### ポリゴン：塗色の更新 ###<br>\
    function updatePolygon() {<br>\
<br>\
      //### オブジェクト削除 ###<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].removeFeature(&#x27;object#2&#x27;);<br>\
<br>\
      //### テキストボックスから属性値を取得 ###<br>\
      opt2.fillColor = document.getElementById(&#x27;para2&#x27;).value;<br>\
<br>\
      //### オブジェクト作成＆レイヤー登録 ###<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolygon(opt2,&#x27;object#2&#x27;);<br>\
<br>\
      //### チェックボックスの状態を表示ONとする ###<br>\
      document.getElementById(&#x27;chk2&#x27;).checked = true;<br>\
    }<br>\
<br>\
    //### ポリライン：線幅の更新 ###<br>\
    function updatePolyline() {<br>\
<br>\
      //### オブジェクト削除 ###<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].removeFeature(&#x27;object#3&#x27;);<br>\
<br>\
      //### テキストボックスから属性値を取得 ###<br>\
      opt3.lineWidth = parseInt(document.getElementById(&#x27;para3&#x27;).value);<br>\
<br>\
      //### オブジェクト作成＆レイヤー登録 ###<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolyline(opt3,&#x27;object#3&#x27;);<br>\
<br>\
      //### チェックボックスの状態を表示ONとする ###<br>\
      document.getElementById(&#x27;chk3&#x27;).checked = true;<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--情報表示DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info&#x27;&gt;<br>\
    &lt;p&gt;<br>\
      &lt;input type=&quot;checkbox&quot; id=&#x27;chk1&#x27; onclick=&#x27;chkCircle(this.checked)&#x27;&gt;サークル&lt;br&gt;<br>\
      &lt;span class=&#x27;indent1&#x27;&gt;半径&lt;input type=&#x27;text&#x27; id=&#x27;para1&#x27; class=&#x27;value1&#x27;&gt;<br>\
      &lt;input type=&#x27;button&#x27; style=&#x27;button1&#x27; value=&#x27;更新&#x27; onclick=&#x27;updateCircle()&#x27;&gt;<br>\
      &lt;br&gt;&lt;br&gt;<br>\
      &lt;input type=&quot;checkbox&quot; id=&#x27;chk2&#x27; onclick=&#x27;chkPolygon(this.checked)&#x27;&gt;ポリゴン&lt;br&gt;<br>\
      &lt;span class=&#x27;indent1&#x27;&gt;塗色&lt;input type=&#x27;text&#x27; id=&#x27;para2&#x27; class=&#x27;value1&#x27;&gt;<br>\
      &lt;input type=&#x27;button&#x27; class=&#x27;button1&#x27; value=&#x27;更新&#x27; onclick=&#x27;updatePolygon()&#x27;&gt;<br>\
      &lt;br&gt;&lt;br&gt;<br>\
      &lt;input type=&quot;checkbox&quot; id=&#x27;chk3&#x27; onclick=&#x27;chkPolyline(this.checked)&#x27;&gt;ポリライン&lt;br&gt;<br>\
      &lt;span class=&#x27;indent1&#x27;&gt;線幅&lt;input type=&#x27;text&#x27; id=&#x27;para3&#x27; class=&#x27;value1&#x27;&gt;<br>\
      &lt;input type=&#x27;button&#x27; class=&#x27;button1&#x27; value=&#x27;更新&#x27; onclick=&#x27;updatePolyline()&#x27;&gt;<br>\
    &lt;/p&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample7.html"
},

{
title: "8.地点リスト",
sum: "<p>地点リスト表示と地図との連携を行います。</p>",
detail: "\
本サンプルでは、画面右側の地点リストからアイテムを選択(クリック)すると、該当地点の緯度経度に地図が移動して、\
該当マーカーのポップアップを表示するコードが確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル８&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      float: left;<br>\
      width: 460px;<br>\
      height: 280px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--地点リストDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #list {<br>\
      float: left;<br>\
      margin: 4px;<br>\
      padding: 4px;<br>\
      background-color:#eeeeee;<br>\
    }<br>\
    .item1 {<br>\
      display: block;<br>\
      floet: left;<br>\
      width: 124px;<br>\
      background-color: #aaaaaa;<br>\
      padding: 4px;<br>\
      margin: 4px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル８．地点リスト ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    var pointData;<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7472311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //--- 地点データ列セットとマーカー、ポップアップ生成：サンプル３参照 ---<br>\
      pointData = [<br>\
        { name: &#x27;東京本社ビル&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;東京本社ビル&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/a.gif&#x27;, width:48, height:48, x:-24, y:-36 },<br>\
        { name: &#x27;新橋営業所&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新橋営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 10:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;豊洲配送事業所&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;豊洲配送事業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/b.gif&#x27;, width:48, height:48, x:-24, y:-30  },<br>\
        { name: &#x27;有明駅営業所&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;有明駅営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 11:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;品川営業所&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;品川営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;渋谷営業所&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;渋谷営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;新宿営業所&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新宿営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 ２４時間営業&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 6 }<br>\
      ];<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
        var id1 = &#x27;popup#&#x27;+i;<br>\
        var opt1 = {<br>\
          size : new Mfapi.Util.ScreenSize(180,80),<br>\
          popUpType : pointData[i].popUpType,<br>\
          contentHtml : pointData[i].text,<br>\
          visible : false<br>\
        };<br>\
        Mfapi.Features.createPopUp(opt1, id1);<br>\
        var id2 = &#x27;marker#&#x27;+i;<br>\
        var opt2 = {<br>\
          position : new Mfapi.Util.LonLat(pointData[i].lon, pointData[i].lat),<br>\
          popUpKey : id1<br>\
        };<br>\
        if( pointData[i].imageUrl !== undefined ) {<br>\
          opt2.imageUrl = pointData[i].imageUrl;<br>\
          opt2.imageSize = new Mfapi.Util.ScreenSize(pointData[i].width, pointData[i].height);<br>\
          opt2.imageOffset = new Mfapi.Util.ScreenPoint(pointData[i].x, pointData[i].y);<br>\
          opt2.imageOpacity = 0.8;<br>\
        } else {<br>\
          opt2.markerType = pointData[i].markerType;<br>\
        }<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt2, id2);<br>\
<br>\
        //### 地点リスト作成 ###<br>\
        // 地点データ分のラベルタグを生成し、クリック時に関数&#x27;selectItem&#x27;を呼ぶようにセットします。<br>\
        // ラベルのidは&#x27;label#n&#x27;とします。(nは通し番号0,1,2,..)<br>\
        var text = document.createTextNode(pointData[i].name);<br>\
        var label = document.createElement(&#x27;label&#x27;);<br>\
          label.appendChild(text);<br>\
          label.setAttribute(&#x27;id&#x27;, &#x27;label#&#x27;+i);<br>\
          label.setAttribute(&#x27;class&#x27;, &#x27;item1&#x27;);<br>\
          label.setAttribute(&#x27;onclick&#x27;,&#x27;selectItem(this.id)&#x27;);<br>\
        var divItem = document.createElement(&#x27;div&#x27;);<br>\
          divItem.appendChild(label);<br>\
        var divList = document.getElementById(&#x27;list&#x27;);<br>\
          divList.appendChild(divItem);<br>\
      }<br>\
<br>\
    }<br>\
<br>\
    var prevItemNumber = 0;<br>\
<br>\
    //### リスト選択時の処理 ###<br>\
    function selectItem(id) {<br>\
<br>\
      //### 前に選択した地点のラベル背景色を元に戻す ###<br>\
      document.getElementById(&#x27;label#&#x27;+prevItemNumber).style.backgroundColor = &#x27;#aaaaaa&#x27;;<br>\
<br>\
      //### 前に選択した地点のマーカーに紐づくポップアップの表示をOFFにする ###<br>\
      Mfapi.Features.PopUp[&#x27;popup#&#x27;+prevItemNumber].setVisible(false);<br>\
<br>\
      //### 選択した地点のラベル背景色を変える ###<br>\
      document.getElementById(id).style.backgroundColor = &#x27;#ff0000&#x27;;<br>\
<br>\
      //### 選択した地点の番号を検出 ###<br>\
      var itemNumber = parseInt(id.substr(6)); // 先頭６文字&#x27;label#&#x27;を除いた文字列を整数化<br>\
<br>\
      //### 選択した地点のマーカーに紐づくポップアップの表示をONにする ###<br>\
      Mfapi.Features.PopUp[&#x27;popup#&#x27;+itemNumber].setVisible(true);<br>\
<br>\
      //### 選択した地点の緯度経度に地図を移動する ###<br>\
      var center = new Mfapi.Util.LonLat(pointData[itemNumber].lon, pointData[itemNumber].lat);<br>\
      Mfapi.Map.setCenterPosition(center);<br>\
<br>\
      //### 選択した地点の番号を記憶 ###<br>\
      prevItemNumber = itemNumber;<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図を描画対象となるDIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地点リストDIVタグ--&gt;<br>\
  &lt;div id=&#x27;list&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample8.html"
},

{
title: "9.ルート描画",
sum: "<p>ルート検索およびルート描画機能のコードが確認できます。</p>",
detail: "\
本サンプルでは、ルート検索の出発地、経由地、目的地を指定して、ルート検索および地図上に\
ルート描画を行うルート関連の基本的な処理のコードが確認できます。また、プルダウンメニューでポリラインタイプおよび\
マーカータイプを選択すると、描画条件を変更して、ルート描画のみ再実行するコードも確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル９&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      float: left;<br>\
      width: 460px;<br>\
      height: 252px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--地点リストDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #list {<br>\
      float: left;<br>\
      margin: 4px;<br>\
      padding: 4px;<br>\
      background-color:#eeeeee;<br>\
    }<br>\
    .item1 {<br>\
      display: block;<br>\
      floet: left;<br>\
      width: 124px;<br>\
      background-color: #aaaaaa;<br>\
      padding: 4px;<br>\
      margin: 4px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--ルート関連のDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #type_bar {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 262px;<br>\
      left: 2px;<br>\
      width: 646px;<br>\
      height: 26px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #loading {<br>\
      margin: 0px;<br>\
      position: absolute;<br>\
      top: 0px;<br>\
      left: 0px;<br>\
      width: 100%;<br>\
      height: 100%;<br>\
      z-index: 5000001;<br>\
      visibility : hidden;<br>\
      background-color: rgba(0,0,0,0.2);<br>\
      filter:progid:DXImageTransform.Microsoft.Gradient(<br>\
       GradientType=0,StartColorStr=#22000000,EndColorStr=#22000000);<br>\
    }<br>\
    #loading_title {<br>\
      padding-top: 20px;<br>\
      text-align: center;<br>\
      position: absolute;<br>\
      top: 40px;<br>\
      left:120px;<br>\
      width: 240px;<br>\
      height: 60px;<br>\
      color: black;<br>\
      background-color: white;<br>\
    }<br>\
    .item2 {<br>\
      margin: 3px;<br>\
      float: left;<br>\
    }<br>\
    .item3 {<br>\
      margin: 1px;<br>\
      float: left;<br>\
    }<br>\
    &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル９．ルート描画 ＊＊＊<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    //--- 地点データ配列：サンプル８参照 ---<br>\
    var pointData = [<br>\
      { name: &#x27;東京本社ビル&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
        text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;東京本社ビル&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
        popUpType: 2, imageUrl:&#x27;./img/a.gif&#x27;, width:48, height:48, x:-24, y:-36 },<br>\
      { name: &#x27;新橋営業所&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
        text: &#x27;&lt;div&gt;&lt;b&gt;新橋営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 10:00-19:00&lt;/div&gt;&#x27;,<br>\
        popUpType: 1, markerType: 1 },<br>\
      { name: &#x27;豊洲配送事業所&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
        text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;豊洲配送事業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
        popUpType: 2, imageUrl:&#x27;./img/b.gif&#x27;, width:48, height:48, x:-24, y:-30  },<br>\
      { name: &#x27;有明駅営業所&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
        text: &#x27;&lt;div&gt;&lt;b&gt;有明駅営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 11:00-21:00&lt;/div&gt;&#x27;,<br>\
        popUpType: 1, markerType: 1 },<br>\
      { name: &#x27;品川営業所&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
        text: &#x27;&lt;div&gt;&lt;b&gt;品川営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-19:00&lt;/div&gt;&#x27;,<br>\
        popUpType: 1, markerType: 1 },<br>\
      { name: &#x27;渋谷営業所&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
        text: &#x27;&lt;div&gt;&lt;b&gt;渋谷営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-21:00&lt;/div&gt;&#x27;,<br>\
        popUpType: 1, markerType: 1 },<br>\
      { name: &#x27;新宿営業所&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
        text: &#x27;&lt;div&gt;&lt;b&gt;新宿営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 ２４時間営業&lt;/div&gt;&#x27;,<br>\
        popUpType: 1, markerType: 6 }<br>\
    ];<br>\
<br>\
    //--- 前操作で選択した地点リストのアイテム番号：サンプル８参照 ---<br>\
    var prevItemNumber = 0;<br>\
<br>\
    //＊＊＊　イニシャル処理　＊＊＊<br>\
<br>\
    //### 認証処理とパス設定 ###<br>\
    // ルートサーバのパスを追記。<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.routeHost = &#x27;api-route-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 認証後の各種イニシャル処理 ###<br>\
    // サンプル８からの変更点は以下の通り。<br>\
    //  ・経路描画用ジオメトリーレイヤーを追加。<br>\
    //  ・タイプ選択のプルダウンメニューの選択肢生成と選択状態初期化<br>\
    //  ・ルートの検索条件と描画条件作成、およびルート検索＆描画要求のメソッド実行<br>\
    //  ・検索中画面の表示ON<br>\
    function task_func(authStatus) {<br>\
<br>\
      //### 認証結果確認と地図作成 ###<br>\
      // 速度改善のため、地図optionsのポリライン間引き&quot;polylineThinningDown&quot;を有効にする。<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        polylineThinningDown : true,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7472311841094,35.66119593467379),<br>\
        mapScale : 11<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### ジオメトリーレイヤー、マーカーレイヤー追加 ###<br>\
      // ジオメトリーレイヤーは経路描画用。<br>\
      // マーカーレイヤーは地点マーカーとルートの出発地、経由地、目的地マーカーで共有。<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer&#x27;);<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //--- 地点データ列セットとマーカー、ポップアップ生成：サンプル８参照 ---<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
        var id1 = &#x27;popup#&#x27;+i;<br>\
        var opt1 = {<br>\
          size : new Mfapi.Util.ScreenSize(180,80),<br>\
          popUpType : pointData[i].popUpType,<br>\
          contentHtml : pointData[i].text,<br>\
          visible : false<br>\
        };<br>\
        Mfapi.Features.createPopUp(opt1, id1);<br>\
        var id2 = &#x27;marker#&#x27;+i;<br>\
        var opt2 = {<br>\
          position : new Mfapi.Util.LonLat(pointData[i].lon, pointData[i].lat),<br>\
          popUpKey : id1<br>\
        };<br>\
        if( pointData[i].imageUrl !== undefined ) {<br>\
          opt2.imageUrl = pointData[i].imageUrl;<br>\
          opt2.imageSize = new Mfapi.Util.ScreenSize(pointData[i].width, pointData[i].height);<br>\
          opt2.imageOffset = new Mfapi.Util.ScreenPoint(pointData[i].x, pointData[i].y);<br>\
          opt2.imageOpacity = 0.8;<br>\
        } else {<br>\
          opt2.markerType = pointData[i].markerType;<br>\
        }<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt2, id2);<br>\
        var text = document.createTextNode(pointData[i].name);<br>\
        var label = document.createElement(&#x27;label&#x27;);<br>\
          label.appendChild(text);<br>\
          label.setAttribute(&#x27;id&#x27;, &#x27;label#&#x27;+i);<br>\
          label.setAttribute(&#x27;class&#x27;, &#x27;item1&#x27;);<br>\
          label.setAttribute(&#x27;onclick&#x27;,&#x27;selectItem(this.id)&#x27;);<br>\
        var divItem = document.createElement(&#x27;div&#x27;);<br>\
          divItem.appendChild(label);<br>\
        var divList = document.getElementById(&#x27;list&#x27;);<br>\
          divList.appendChild(divItem);<br>\
      }<br>\
<br>\
      //### 検索中画面の表示ON ###<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
<br>\
      //### タイプ選択のプルダウンメニューの選択肢生成 ###<br>\
      var polylineTypeOptions = [<br>\
        { name:&#x27;グリーン／標準サイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_GREEN},<br>\
        { name:&#x27;イエロー／標準サイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_YELLOW},<br>\
        { name:&#x27;ブルー／標準サイズ&#x27;,     value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_BLUE},<br>\
        { name:&#x27;レッド／標準サイズ&#x27;,     value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_RED},<br>\
        { name:&#x27;モノクロ／標準サイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_MONOCHROME},<br>\
        { name:&#x27;ＲＰＧ風／標準サイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_MAP_RPG},<br>\
        { name:&#x27;古地図風／標準サイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_MAP_ANTIQUE},<br>\
        { name:&#x27;グリーン／大きいサイズ&#x27;, value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_COLOR_GREEN},<br>\
        { name:&#x27;イエロー／大きいサイズ&#x27;, value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_COLOR_YELLOW},<br>\
        { name:&#x27;ブルー／大きいサイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_COLOR_BLUE},<br>\
        { name:&#x27;レッド／大きいサイズ&#x27;,   value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_COLOR_RED},<br>\
        { name:&#x27;モノクロ／大きいサイズ&#x27;, value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_COLOR_MONOCHROME},<br>\
        { name:&#x27;ＲＰＧ風／大きいサイズ&#x27;, value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_MAP_RPG},<br>\
        { name:&#x27;古地図風／大きいサイズ&#x27;, value:Mfapi.Const.DrawPolylineType.BIG_ROUTE_MAP_ANTIQUE}<br>\
      ];<br>\
      for( var i=0; i&lt;polylineTypeOptions.length; i++ ) {<br>\
        var option = document.createElement(&#x27;option&#x27;);<br>\
        option.setAttribute(&#x27;value&#x27;, polylineTypeOptions[i].value);<br>\
        option.innerHTML = polylineTypeOptions[i].name;<br>\
        document.getElementById(&#x27;select_polyline_type&#x27;).appendChild(option);<br>\
      }<br>\
      var markerTypeOptions = [<br>\
        { name:&#x27;標準デザイン／標準サイズ&#x27;,   value:Mfapi.Const.DrawMarkerType.STANDARD_ROUTE},<br>\
        { name:&#x27;標準デザイン／大きいサイズ&#x27;, value:Mfapi.Const.DrawMarkerType.BIG_ROUTE},<br>\
        { name:&#x27;ＲＰＧ風／標準サイズ&#x27;,       value:Mfapi.Const.DrawMarkerType.STANDARD_ROUTE_MAP_RPG},<br>\
        { name:&#x27;ＲＰＧ風／大きいサイズ&#x27;,     value:Mfapi.Const.DrawMarkerType.BIG_ROUTE_MAP_RPG},<br>\
        { name:&#x27;古地図風／標準サイズ&#x27;,       value:Mfapi.Const.DrawMarkerType.STANDARD_ROUTE_MAP_ANTIQUE},<br>\
        { name:&#x27;古地図風／大きいサイズ&#x27;,     value:Mfapi.Const.DrawMarkerType.BIG_ROUTE_MAP_ANTIQUE}<br>\
      ];<br>\
      for( var i=0; i&lt;markerTypeOptions.length; i++ ) {<br>\
        var option = document.createElement(&#x27;option&#x27;);<br>\
        option.setAttribute(&#x27;value&#x27;, markerTypeOptions[i].value);<br>\
        option.innerHTML = markerTypeOptions[i].name;<br>\
        document.getElementById(&#x27;select_marker_type&#x27;).appendChild(option);<br>\
      }<br>\
<br>\
      //### タイプ選択の選択状態初期化 ###<br>\
      document.getElementById(&#x27;select_polyline_type&#x27;).selectedIndex = 0;<br>\
      document.getElementById(&#x27;select_marker_type&#x27;).selectedIndex = 0;<br>\
<br>\
      //### ルート検索条件&quot;optCalc&quot;の作成 ###<br>\
      // 本サンプルでは、７件ある地点リストのうち、１番目を出発地、２番目～６番目を経由地、<br>\
      // ７番目を目的地としてセットする。なお、経由地は配列に格納してからセットする。<br>\
      var viaPoints = [];<br>\
      for(var loop=0; loop&lt;5; loop++)<br>\
        viaPoints[loop] = new Mfapi.Util.LonLat(pointData[loop+1].lon,pointData[loop+1].lat);<br>\
      var optCalc = {<br>\
        start : new Mfapi.Util.LonLat(pointData[0].lon,pointData[0].lat),<br>\
        via : viaPoints,<br>\
        destination : new Mfapi.Util.LonLat(pointData[6].lon,pointData[6].lat)<br>\
      };<br>\
<br>\
      //### 経路描画条件&quot;optDraw&quot;の作成 ###<br>\
      // 経路(ルートのポリライン)描画用のレイヤーIDと、出発地、目的地、経由地のマーカーを<br>\
      // 表示用のレイヤーIDを指定。ここでは各描画タイプの指定を省略しているため、デフォルト<br>\
      // の描画タイプが適用される。<br>\
      var optDraw = {<br>\
        geometryLayerId : &#x27;gLayer&#x27;,<br>\
        markerLayerId : &#x27;mLayer&#x27;<br>\
      };<br>\
<br>\
      //### ルート検索＆描画要求のメソッド実行 ###<br>\
      Mfapi.Route.requestRouteCalcAndDraw(&#x27;route_sample&#x27;,optCalc,optDraw,route_calc_and_draw_completed);<br>\
    }<br>\
<br>\
    //＊＊＊　各種イベント処理　＊＊＊<br>\
<br>\
    //--- アイテム選択時の処理：サンプル８参照 ---<br>\
    function selectItem(id) {<br>\
      document.getElementById(&#x27;label#&#x27;+prevItemNumber).style.backgroundColor = &#x27;#aaaaaa&#x27;;<br>\
      Mfapi.Features.PopUp[&#x27;popup#&#x27;+prevItemNumber].setVisible(false);<br>\
      document.getElementById(id).style.backgroundColor = &#x27;#ff0000&#x27;;<br>\
      var itemNumber = parseInt(id.substr(6)); // 先頭６文字&#x27;label#&#x27;を除いた文字列を整数化<br>\
      Mfapi.Features.PopUp[&#x27;popup#&#x27;+itemNumber].setVisible(true);<br>\
      var center = new Mfapi.Util.LonLat(pointData[itemNumber].lon, pointData[itemNumber].lat);<br>\
      Mfapi.Map.setCenterPosition(center);<br>\
      prevItemNumber = itemNumber;<br>\
    }<br>\
<br>\
    //### ルート検索＆描画終了時の処理 ###<br>\
    // ルート検索＆経路描画処理終了時に実行。<br>\
    // 検索中画面を表示OFFにする。また、ルート検索に失敗した場合、エラーを警告画面にて表示。<br>\
    function route_calc_and_draw_completed(result_routeId) {<br>\
<br>\
      //### 検索中画面の表示OFF ###<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //### エラー判定と警告表示 ###<br>\
      if(Mfapi.Route.RteInfo[result_routeId].calcData.status != &#x27;success&#x27; )<br>\
        window.alert(&quot;ルート検索に失敗しました。通信状況を確認してください。&quot;);<br>\
    }<br>\
<br>\
    //### ルート再描画処理 ###<br>\
    // プルダウンメニューのタイプ選択の状態が変化したときに実行。<br>\
    // 選択した各描画タイプで、描画データを再作成する。<br>\
    function doRedraw() {<br>\
    <br>\
      //### ルートデータ(検索結果のデータ)の存在確認 ###<br>\
      // 存在しない場合は処理を中止。<br>\
      if(!Mfapi.Route.isUsed(&#x27;route_sample&#x27;)) return;<br>\
      if(Mfapi.Route.RteInfo[&#x27;route_sample&#x27;].calcData == null ) return;<br>\
<br>\
      //### 描画データの削除 ###<br>\
      Mfapi.Route.removeRteDrawObjects(&#x27;route_sample&#x27;);<br>\
<br>\
      //### 経路描画条件&quot;optDraw&quot;の作成 ###<br>\
      // 各レイヤーIDの指定に加え、ユーザがプルダウンメニューで選択した各描画タイプを指定。<br>\
      var optDraw = {<br>\
        geometryLayerId : &#x27;gLayer&#x27;,<br>\
        markerLayerId : &#x27;mLayer&#x27;,<br>\
        drawPolylineType : document.getElementById(&#x27;select_polyline_type&#x27;).value,<br>\
        drawMarkerType : document.getElementById(&#x27;select_marker_type&#x27;).value<br>\
      };<br>\
<br>\
      //### 経路描画要求のメソッド実行 ###<br>\
      // 本メソッド終了後の処理は特に無いため、コールバック関数の指定は省略。<br>\
      Mfapi.Route.requestRouteDraw(&#x27;route_sample&#x27;,optDraw);<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図描画対象となるDIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地点リストDIVタグ--&gt;<br>\
  &lt;div id=&#x27;list&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--タイプ設定バーDIVタグ--&gt;<br>\
  &lt;div id=&#x27;type_bar&#x27;&gt;<br>\
    &lt;label class=&quot;item2&quot;&gt;ポリライン：&lt;/label&gt;<br>\
    &lt;form class=&quot;item3&quot;&gt;&lt;select id=&quot;select_polyline_type&quot; onchange=&quot;doRedraw()&quot;&gt;&lt;/select&gt;&lt;/form&gt;<br>\
    &lt;label class=&quot;item2&quot;&gt;マーカー：&lt;/label&gt;<br>\
    &lt;form class=&quot;item3&quot;&gt;&lt;select id=&quot;select_marker_type&quot; onchange=&quot;doRedraw()&quot;&gt;&lt;/select&gt;&lt;/form&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--検索中画面DIVタグ--&gt;<br>\
  &lt;div id=&quot;loading&quot;&gt;<br>\
    &lt;div id=&quot;loading_title&quot;&gt;ルート検索＆描画処理中&lt;img src=&quot;img/loader.gif&quot;&gt;&lt;/img&gt;&lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample9.html"
},

{
title: "10.ルート地点設定と案内表示",
sum: "<p>出発地、目的地の設定UIと案内表示のコードが確認できます。</p>",
detail: "\
本サンプルでは、出発地設定、および目的地設定ボタンを押すと、地図中心に出発地、および目的地のマーカーを登録します。\
計算実行ボタンを押すと、ルート検索、地図上のルート描画、および案内表示を行います。案内表示の案内地点の項目をクリックすると、\
該当緯度経度に地図が移動する機能も盛り込んでいます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１０&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      position: absolute;<br>\
      top: 4px;<br>\
      left: 4px;<br>\
      width: 380px;<br>\
      height: 256px;<br>\
    }<br>\
    #center_image {<br>\
      width: 34px;<br>\
      height: 30px;<br>\
    }<br>\
    #center_div {<br>\
      z-index: 5000000;<br>\
      position: absolute;<br>\
      left: 177px;<br>\
      top: 117px;<br>\
      pointer-events: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--ルート関連のDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #positions_bar {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 264px;<br>\
      left: 0px;<br>\
      width: 380px;<br>\
      height: 24px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #info_window {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 2px;<br>\
      left: 390px;<br>\
      width: 218px;<br>\
      height: 256px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #operation_bar {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 264px;<br>\
      left: 390px;<br>\
      width: 218px;<br>\
      height: 24px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #result_text {<br>\
      padding: 0px;<br>\
      position: absolute;<br>\
      top: 0px;<br>\
      left: 0px;<br>\
      width: 214px;<br>\
      height: 252px;<br>\
      overflow-y: scroll;<br>\
    }<br>\
    #loading {<br>\
      margin: 0px;<br>\
      position: absolute;<br>\
      top: 0px;<br>\
      left: 0px;<br>\
      width: 100%;<br>\
      height: 100%;<br>\
      z-index: 5000001;<br>\
      visibility : hidden;<br>\
      background-color: rgba(0,0,0,0.2);<br>\
      filter:progid:DXImageTransform.Microsoft.Gradient(<br>\
       GradientType=0,StartColorStr=#22000000,EndColorStr=#22000000);<br>\
    }<br>\
    #loading_title {<br>\
      padding-top: 20px;<br>\
      text-align: center;<br>\
      position: absolute;<br>\
      top: 40px;<br>\
      left:120px;<br>\
      width: 240px;<br>\
      height: 60px;<br>\
      color: black;<br>\
      background-color: white;<br>\
    }<br>\
    .info_box {<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 2px;<br>\
      left: 2px;<br>\
      width: 214px;<br>\
      height: 252px;<br>\
      background-color:#dddddd;<br>\
    }<br>\
    .item1 {<br>\
      margin: 0px;<br>\
      padding: 0px;<br>\
    }<br>\
    .item2 {<br>\
      margin-left: 2px;<br>\
      float: left;<br>\
    }<br>\
    .item3 {<br>\
      margin: 0px;<br>\
      padding: 0px;<br>\
      color: blue;<br>\
      text-decoration: underline;<br>\
      cursor: pointer;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１０．ルート地点設定と案内表示 ＊＊＊<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    //### 前操作で選択した案内リストのDIVタグのID ###<br>\
    var prevGuideId = &#x27;&#x27;;<br>\
<br>\
    //＊＊＊　イニシャル処理処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル９参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.routeHost = &#x27;api-route-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 認証後の各種イニシャル処理 ###<br>\
    // 地図作成やレイヤー追加の基本処理に加え、画面初期化処理を追加。<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル９参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        polylineThinningDown : true,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7472311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //--- ジオメトリーレイヤー、マーカーレイヤー追加：サンプル９参照 ---<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer&#x27;);<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### 画面初期化実行 ###<br>\
      initScreen();<br>\
    }<br>\
<br>\
    //＊＊＊　各種イベント処理　＊＊＊<br>\
<br>\
    //### 出発地、目的地セット処理 ###<br>\
    // 出発地、目的地ボタンを押したときに実行。<br>\
    // 出発地、目的地のマーカーを地図中心座標上に作成する。<br>\
    function setPoint(type) {<br>\
      if(type==&#x27;s&#x27;)<br>\
        createPointMarker(&#x27;start_marker&#x27;,0);<br>\
      else if(type==&#x27;d&#x27;)<br>\
        createPointMarker(&#x27;destination_marker&#x27;,50);<br>\
    }<br>\
<br>\
    //### ルート検索＆描画要求処理 ###<br>\
    // 検索実行ボタンを押したときに実行。<br>\
    // 各UIのアクティブ制御、検索条件、描画条件の作成などを行った後、<br>\
    // ルート検索＆描画要求のメソッドを実行する。<br>\
    function doCalcAndDraw() {<br>\
<br>\
      //### 各種ボタンのアクティブ制御 ###<br>\
      // 全てのボタンを非アクティブにする。<br>\
      document.getElementById(&#x27;calc&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;start&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;destination&#x27;).disabled=true;<br>\
<br>\
      //### 出発地、目的地の設定チェック ###<br>\
      // 出発地、目的地が設定されいてるかをチェック。<br>\
      // 設定されていない場合、警告を出し、ボタンのアクティブ制御を戻して中断。<br>\
      if( Mfapi.Features.getObjectType(&#x27;start_marker&#x27;) == -1 ) {<br>\
        window.alert(&quot;出発地が設定されていません。&quot;);<br>\
        document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
        document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
        return;<br>\
      }<br>\
      if( Mfapi.Features.getObjectType(&#x27;destination_marker&#x27;) == -1 ) {<br>\
        window.alert(&quot;目的地が設定されていません。&quot;);<br>\
        document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
        document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
        return;<br>\
      }<br>\
      <br>\
      //## リセットボタンを非アクティブ ##<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=true;<br>\
<br>\
      //### 検索中画面の表示ON ###<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      <br>\
      //### ルート検索条件&quot;optCalc&quot;の作成 ###<br>\
      // 出発地、目的地の地点マーカーの座標を利用して、条件を作成。<br>\
      var optCalc = {<br>\
        start : Mfapi.Features.Marker[&#x27;start_marker&#x27;].getPosition(),<br>\
        destination : Mfapi.Features.Marker[&#x27;destination_marker&#x27;].getPosition()<br>\
      };<br>\
<br>\
      //### 経路描画条件&quot;optDraw&quot;の作成 ###<br>\
      // 経路描画用のジオメトリーレイヤーIDのみを指定。<br>\
      // 経路描画でのマーカー描画は行わないため、マーカーレイヤーIDの指定は省略。<br>\
      var optDraw = {<br>\
        geometryLayerId : &#x27;gLayer&#x27;<br>\
      };<br>\
      <br>\
      //### ルート検索＆経路描画要求のメソッド実行 ###<br>\
      // 処理終了後に呼ばれるコールバック関数として&quot;route_calc_and_draw_completed&quot;を指定する。<br>\
      Mfapi.Route.requestRouteCalcAndDraw(&#x27;route_sample&#x27;,optCalc,optDraw,route_calc_and_draw_completed);<br>\
    }<br>\
<br>\
    //### ルート検索＆経路描画終了時の処理 ###<br>\
    // ルート検索＆経路描画処理終了時に実行。<br>\
    // ルート検索に成功した場合、検索結果から作成した案内テキストのDIVタグを、失敗した場合、エラー<br>\
    // 情報テキストのDIVタグを、&quot;result_text&quot;のDIVタグに追加する。<br>\
    // その後、情報窓の表示制御や戻るボタンのアクティブ制御などを行う。<br>\
    function route_calc_and_draw_completed(result_routeId) {<br>\
    <br>\
      //### 経路進行方向テキストの定義 ###<br>\
      // 経路進行の方向のコード値別に案内テキストを定義。<br>\
      // 本サンプルでは「未設定 」、「道なり」の場合は、案内を出さないようにしています。<br>\
      var DIRECTION_GUIDANCE = [<br>\
        &#x27;&#x27;, &#x27;&#x27;, &#x27;直進&#x27;, &#x27;右斜め&#x27;, &#x27;右斜め&#x27;, &#x27;右折&#x27;, &#x27;右斜め後ろ&#x27;, &#x27;右斜め後ろ&#x27;,<br>\
        &#x27;Ｕターン&#x27;, &#x27;左斜め後ろ&#x27;, &#x27;左斜め後ろ&#x27;, &#x27;左折&#x27;, &#x27;左斜め&#x27;, &#x27;左斜め&#x27; ];<br>\
<br>\
      //### ルート検索結果の取得 ###<br>\
      var calcData = Mfapi.Route.RteInfo[result_routeId].calcData;<br>\
<br>\
      //### 結果テキスト追加：ルート検索成功時 ###<br>\
      if(calcData.status==&#x27;success&#x27;) {<br>\
      <br>\
        //### 検索結果サマリー情報の取得＆テキスト作成 ###<br>\
        var summary = calcData.summary;<br>\
        addTextDiv(&#x27;result_text&#x27;,&#x27;ルート検索結果：&#x27;,&#x27;item1&#x27;);<br>\
        addTextDiv(&#x27;result_text&#x27;,&#x27;　距離　&#x27;+parseInt(summary.totalDistance)+&#x27;m&#x27;,&#x27;item1&#x27;);<br>\
        addTextDiv(&#x27;result_text&#x27;,&#x27;　時間　&#x27;+parseInt(summary.totalTravelTime)+&#x27;秒&#x27;,&#x27;item1&#x27;);<br>\
        addTextDiv(&#x27;result_text&#x27;,&#x27;　料金　&#x27;+parseInt(summary.totalToll.toll)+&#x27;円&#x27;,&#x27;item1&#x27;);<br>\
        addTextDiv(&#x27;result_text&#x27;,&#x27;--------------------&#x27;,&#x27;item1&#x27;);<br>\
<br>\
        //### 検索結果案内情報(案内区間単位)の取得＆テキスト作成 ###<br>\
        var guide = calcData.guide;<br>\
        var index=1;<br>\
        for(var i=0; i&lt;guide.length; i++) {<br>\
          var infoText=&#x27;&#x27;;<br>\
          <br>\
          //### 誘導ポイント(誘導区間のタイプ)の取得 ###<br>\
          var guideType=guide[i].type;<br>\
<br>\
          switch (guideType) {<br>\
<br>\
            //### 誘導ポイント＝出発地の場合 ###<br>\
            case 1:<br>\
              infoText = &#x27;[&#x27;+index+&#x27;]&#x27;+&#x27;出発地&#x27;;<br>\
              break;<br>\
<br>\
            //### 誘導ポイント＝目的地の場合 ###<br>\
            case 2:<br>\
              infoText = &#x27;[&#x27;+index+&#x27;]&#x27;+&#x27;目的地&#x27;;<br>\
              break;<br>\
<br>\
            //### 誘導ポイント＝案内ポイントの場合 ###<br>\
            case 0:<br>\
              //### 案内情報の有無確認 ###<br>\
              if(guide[i].guideInfo === undefined) break;<br>\
              <br>\
              //### 案内情報の各項目取得 ###<br>\
              var direction = DIRECTION_GUIDANCE[guide[i].guideInfo.guideDirection];<br>\
              var detailInfo = getDetailInfo(guide[i].guideInfo);<br>\
              var detailName = getDetailName(guide[i].guideInfo);<br>\
              var highwayFacilityName = getHighwayFacilityName(guide[i].guideInfo);<br>\
              var toll = getToll(guide[i].guideInfo);<br>\
              var tollFacilityName = getTollFacilityName(guide[i].guideInfo);<br>\
              var crossingName = getCrossingName(guide[i].guideInfo);<br>\
              <br>\
              //### 案内テキスト作成 ###<br>\
              var guideText = &#x27;&#x27;;<br>\
<br>\
              //## ①料金情報 ##<br>\
              if(toll!=&#x27;&#x27;) {<br>\
                // 料金所施設名称がある場合：料金施設名称と料金<br>\
                if(tollFacilityName!=&#x27;&#x27;)<br>\
                  guideText = tollFacilityName+&#x27; 料金：&#x27;+toll+&#x27;円&#x27;;<br>\
                // 料金所施設名称がない場合：料金のみ<br>\
                else<br>\
                  guideText =&#x27; 料金：&#x27;+toll+&#x27;円&#x27;;<br>\
                // 経路進行方向情報がある場合：経路進行方向テキストを追記<br>\
                if(direction!=&#x27;&#x27;)<br>\
                  guideText += &#x27; &#x27; + direction;<br>\
<br>\
              //## ②誘導詳細情報 ##<br>\
              } else if(detailInfo!=&#x27;&#x27;) {<br>\
                // 誘導詳細情報の名称(テキスト)情報がある場合：テキスト名称と詳細誘導情報<br>\
                if(detailName!=&#x27;&#x27;)<br>\
                  guideText = detailName+&#x27; &#x27;+detailInfo;<br>\
                // 誘導詳細情報の名称(テキスト)情報がない場合：詳細誘導情報のみ<br>\
                else<br>\
                  guideText = detailInfo;<br>\
                // 経路進行方向情報がある場合：経路進行方向テキストを追記<br>\
                if(direction!=&#x27;&#x27;)<br>\
                  guideText += &#x27; &#x27; + direction;<br>\
<br>\
              //## ③高速道路施設名称 ##<br>\
              // 高速道路施設名称と経路進行方向情報がある場合：高速道路施設名称と経路進行方向テキスト<br>\
              } else if(highwayFacilityName!=&#x27;&#x27;&amp;&amp;direction!=&#x27;&#x27;) {<br>\
                guideText = highwayFacilityName + &#x27; &#x27; + direction;<br>\
<br>\
              //## ④交差点名称 ##<br>\
              // 交差点名称と経路の進行方向情報がある場合：交差点名称と経路進行方向テキスト<br>\
              } else if(crossingName!=&#x27;&#x27;&amp;&amp;direction!=&#x27;&#x27;) {<br>\
                guideText = crossingName + &#x27; &#x27; + direction;<br>\
<br>\
              //## ⑤経路進行方向 ##<br>\
              // 経路進行方向情報のみある場合：経路進行方向テキスト<br>\
              } else if(direction!=&#x27;&#x27;) {<br>\
                guideText = direction;<br>\
              }<br>\
              <br>\
              //## 案内テキスト格納 ##<br>\
              if(guideText!=&#x27;&#x27;)<br>\
                infoText = &#x27;[&#x27;+index+&#x27;]&#x27;+guideText;<br>\
<br>\
              break;<br>\
          }<br>\
          //### テキスト作成 ###<br>\
          // 案内テキストに何か格納されていた場合のみ、同テキストを格納したDIVタグを作成。<br>\
          // 追加するタブのクリック(タップ)で、地図移動できるようにする。<br>\
          // 移動座標は、誘導データ下の緯度経度データの先頭値をセットする。<br>\
          if(infoText!=&#x27;&#x27;) {<br>\
            var move = guide[i].guidePoints[0];<br>\
            addTextDiv(&#x27;result_text&#x27;,infoText,&#x27;item3&#x27;,&#x27;guide&#x27;+index,move);<br>\
            index++;<br>\
          }<br>\
        }<br>\
        //### 選択状態をリセット ###<br>\
        prevGuideId = &#x27;&#x27;;<br>\
        <br>\
      //### 結果テキスト追加：ルート検索失敗時 ###<br>\
      } else {<br>\
         addTextDiv(&#x27;result_text&#x27;,&#x27;ルート検索エラー：&#x27;,&#x27;item1&#x27;);<br>\
         addTextDiv(&#x27;result_text&#x27;,calcData.status,&#x27;item1&#x27;);<br>\
      }<br>\
<br>\
      //### 情報窓：結果表示 ###<br>\
      document.getElementById(&#x27;explain&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
      document.getElementById(&#x27;result&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
<br>\
      //### 検索中画面の表示OFF ###<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //### 戻るボタンをアクティブ ###<br>\
      document.getElementById(&#x27;back&#x27;).disabled=false;<br>\
<br>\
      //### リセットボタンをアクティブ ###<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=false;<br>\
    }<br>\
<br>\
    //### 戻るボタンの処理 ###<br>\
    // 戻るボタンが押されたときに実行。<br>\
    // ルートデータを削除して、経路表示をoffにした後、情報窓も説明文表示に切り替える。<br>\
    // また、戻るボタン以外をアクティブにする。<br>\
    function doBack() {<br>\
<br>\
      //### ルートデータ削除 ###<br>\
      // データ削除時に関連するマーカー、ポリラインも削除される。<br>\
      Mfapi.Route.removeRteInfo(&#x27;route_sample&#x27;);<br>\
<br>\
      //### 結果テキストのDIVリセット ###<br>\
      recretateDiv(&#x27;result_text&#x27;,&#x27;result&#x27;);<br>\
<br>\
      //### 情報窓：説明文表示 ###<br>\
      document.getElementById(&#x27;explain&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      document.getElementById(&#x27;result&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //### 各種ボタンのアクティブ制御 ###<br>\
      // 戻るボタン以外をアクティブにする。<br>\
      document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
    }<br>\
<br>\
    //### リセットボタンの処理 ###<br>\
    // リセットボタンが押されたときに実行。<br>\
    // ルートデータを削除して、経路表示をoffにした後、情報窓も説明文表示に切り替える。<br>\
    // また、戻るボタン以外をアクティブにする。<br>\
    function doReset() {<br>\
<br>\
      //### ルートデータ削除 ###<br>\
      Mfapi.Route.removeRteInfo(&#x27;route_sample&#x27;);<br>\
<br>\
      //### 出発地、目的地のマーカー削除 ###<br>\
      if( Mfapi.Features.getObjectType(&#x27;start_marker&#x27;) != -1 ) {<br>\
        Mfapi.Features.remove(&#x27;start_marker&#x27;);<br>\
      }<br>\
      if( Mfapi.Features.getObjectType(&#x27;destination_marker&#x27;) != -1 ) {<br>\
        Mfapi.Features.remove(&#x27;destination_marker&#x27;);<br>\
      }<br>\
<br>\
      //### 画面初期化 ###<br>\
      initScreen();<br>\
    }<br>\
<br>\
    //＊＊＊　各種汎用処理　＊＊＊<br>\
<br>\
    //### 画面初期化処理 ###<br>\
    function initScreen() {<br>\
<br>\
      //### 情報窓の表示制御 ###<br>\
      // 初期時は説明文側を表示する。<br>\
      document.getElementById(&#x27;explain&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      document.getElementById(&#x27;result&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //### 結果テキストのリセット処理実行 ###<br>\
      recretateDiv(&#x27;result_text&#x27;,&#x27;result&#x27;);<br>\
<br>\
      //### 各種ボタンのアクティブ制御 ###<br>\
      // 戻るボタン以外をアクティブにする。(リセットボタンは常時アクティブのままとなる。)<br>\
      document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=false;<br>\
<br>\
      //### 検索中画面の表示OFF ###<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
    }<br>\
<br>\
    //### DIVタグのリセット処理 ###<br>\
    // &#x27;親DIVタグ&#x27;(parentId)の下にある&#x27;子DIVタグ&#x27;(targetId)を一度削除して、再追加する。<br>\
    function recretateDiv(targetId,parentId) {<br>\
      var div = document.getElementById(targetId);<br>\
      if( div )<br>\
        document.getElementById(parentId).removeChild(div);<br>\
      var new_div = document.createElement(&#x27;div&#x27;);<br>\
      new_div.setAttribute(&#x27;id&#x27;, targetId);<br>\
      document.getElementById(parentId).appendChild(new_div);<br>\
    }<br>\
<br>\
    //### 地点マーカー作成処理 ###<br>\
    // 指定されたマーカーID(marker_id)の地点マーカーを&#x27;mLayer&#x27;の上に登録する。<br>\
    // 座標は地図中心座標を適用する。<br>\
    // マーカー画像は&#x27;./img/route_points.png&#x27;を使用し、位置(cx,0)から50px×50pxの画像を<br>\
    // 切り出して、適用する。また、オフセット(-25px,-49px)とする。<br>\
    // なお、既に指定されたIDのマーカーがある場合、削除、再作成する。<br>\
    function createPointMarker(marker_id,cx) {<br>\
      if( Mfapi.Features.getObjectType(marker_id) != -1 )<br>\
        Mfapi.Features.remove(marker_id);<br>\
      var optMarker = {<br>\
        position: Mfapi.Map.getCenterPosition(),<br>\
        imageUrl: &#x27;./img/route_points.png&#x27;,<br>\
        cuttingPoint: { x: cx, y: 0 },<br>\
        imageSize : { width: 50, height: 50 },<br>\
        imageOffset : { x: -25, y: -49 }<br>\
      };<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(optMarker,marker_id);<br>\
    }<br>\
<br>\
    //### 料金情報取得処理 ###<br>\
    function getToll(guideInfo) {<br>\
      if(guideInfo.guideToll === undefined) return &#x27;&#x27;;<br>\
      return guideInfo.guideToll.toll;<br>\
    }<br>\
<br>\
    //### 料金所施設名称取得処理 ###<br>\
    function getTollFacilityName(guideInfo) {<br>\
      if(guideInfo.guideToll === undefined) return &#x27;&#x27;;<br>\
      return guideInfo.guideToll.name;<br>\
    }<br>\
<br>\
    //### 誘導詳細情報取得処理 ###<br>\
    function getDetailInfo(guideInfo) {<br>\
      if(guideInfo.guideDetail === undefined) return &#x27;&#x27;;<br>\
      switch (guideInfo.guideDetail.code) {<br>\
        case 32: return &#x27;入口&#x27;;<br>\
        case 33: return &#x27;出口&#x27;;<br>\
        case 34: return &#x27;&#x27;; // SA/PAは案内対象から除外<br>\
        case 48: return &#x27;フェリーターミナル&#x27;;<br>\
        default: return &#x27;&#x27;;<br>\
      }<br>\
    }<br>\
<br>\
    //### 誘導詳細名称情報取得処理 ###<br>\
    function getDetailName(guideInfo) {<br>\
      if(guideInfo.guideDetail === undefined) return &#x27;&#x27;;<br>\
      return guideInfo.guideDetail.name;<br>\
    }<br>\
<br>\
    //### 有料道路施設名称取得処理 ###<br>\
    function getHighwayFacilityName(guideInfo) {<br>\
      if(guideInfo.guideHighway === undefined) return &#x27;&#x27;;<br>\
      if(guideInfo.guideHighway.facilities === undefined) return &#x27;&#x27;;<br>\
      return guideInfo.guideHighway.facilities[0].name;<br>\
    }<br>\
<br>\
    //### 交差点名称取得処理 ###<br>\
    function getCrossingName(guideInfo) {<br>\
      if(guideInfo.guideCrossing === undefined) return &#x27;&#x27;;<br>\
      return guideInfo.guideCrossing.name;<br>\
    }<br>\
    <br>\
    //### テキストDIV追加汎用処理 ###<br>\
    // &quot;parentId&quot;で指定されたDIVタグに&quot;text&quot;で指定されたテキストのDIVタグを追加。<br>\
    // &quot;css_class&quot;が指定された場合、クラスとして適用。<br>\
    // &quot;id&quot;が指定された場合、idとして適用。<br>\
    // &quot;move&quot;が指定された場合、クリック時に地図移動処理&quot;moveMap&quot;を呼ぶようにする。<br>\
    function addTextDiv(parentId,text,css_class,id,move) {<br>\
      var textNode = document.createTextNode(text);<br>\
      var label = document.createElement(&#x27;label&#x27;);<br>\
      label.appendChild(textNode);<br>\
      if(css_class!=&#x27;&#x27;)<br>\
        label.setAttribute(&#x27;class&#x27;, css_class);<br>\
      if(id!=null) {<br>\
        if(id!=&#x27;&#x27;)<br>\
          label.setAttribute(&#x27;id&#x27;, id);<br>\
      }<br>\
      if(move!=null) {<br>\
        label.setAttribute(&#x27;onclick&#x27;,&#x27;moveMap(&#x27;+move.lon+&#x27;,&#x27;+move.lat+&#x27;,this)&#x27;);<br>\
      }<br>\
      var div = document.createElement(&#x27;div&#x27;);<br>\
      div.appendChild(label);<br>\
      document.getElementById(parentId).appendChild(div);<br>\
    }<br>\
<br>\
    //### 地図移動処理 ###<br>\
    // &quot;lon&quot;,&quot;lat&quot;で指定した緯度経度に地図を移動する。<br>\
    // また、&quot;element&quot;で指定されたタグの色を青から赤に変更し、前操作で選択したタグを青に変更する。<br>\
    function moveMap(lon,lat,element) {<br>\
<br>\
      //### 地図を移動 ###<br>\
      Mfapi.Map.setCenterPosition(new Mfapi.Util.LonLat(lon,lat));<br>\
<br>\
      //### 選択したラベルの色を赤に変更 ###<br>\
      element.style.color=&#x27;red&#x27;;<br>\
<br>\
      //### 前操作で選択したラベルの色を青に戻す ###<br>\
      if(prevGuideId!=&#x27;&#x27;)<br>\
        document.getElementById(prevGuideId).style.color=&#x27;blue&#x27;;<br>\
      prevGuideId=element.getAttribute(&#x27;id&#x27;);<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図描画対象となるDIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地図中心を示すパーツのDIVタグ--&gt;<br>\
  &lt;div id=&#x27;center_div&#x27;&gt;&lt;img id=&#x27;center_image&#x27; src=&#x27;img/center.png&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地点設定バーDIVタグ--&gt;<br>\
  &lt;div id=&#x27;positions_bar&#x27;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;出発地設定&quot; id=&quot;start&quot; onclick=&quot;setPoint(&#x27;s&#x27;);&quot;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;目的地設定&quot; id=&quot;destination&quot; onclick=&quot;setPoint(&#x27;d&#x27;);&quot;&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--情報窓DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info_window&#x27;&gt;<br>\
    &lt;div id=&#x27;explain&#x27; class=&quot;info_box&quot;&gt;<br>\
      &lt;label&gt;出発地、目的地を設定したら、検索実行ボタンを押してください。&lt;/label&gt;<br>\
    &lt;/div&gt;<br>\
    &lt;div id=&#x27;result&#x27; class=&quot;info_box&quot;&gt;&lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--操作バーDIVタグ--&gt;<br>\
  &lt;div id=&#x27;operation_bar&#x27;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;検索実行&quot; id=&quot;calc&quot; onclick=&quot;doCalcAndDraw();&quot;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;戻る&quot; id=&quot;back&quot; onclick=&quot;doBack();&quot;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;リセット&quot; id=&quot;reset&quot; onclick=&quot;doReset();&quot;&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--検索中画面DIVタグ--&gt;<br>\
  &lt;div id=&quot;loading&quot;&gt;<br>\
    &lt;div id=&quot;loading_title&quot;&gt;ルート検索＆描画処理中&lt;img src=&quot;img/loader.gif&quot;&gt;&lt;/img&gt;&lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample10.html"
},

{
title: "11.ルート検索条件設定",
sum: "<p>複数の検索条件（有料道路利用等）のルートを同時に表示するコードが確認できます。</p>",
detail: "\
本サンプルでは、出発地、目的地設定後、計算実行ボタンを押すと、３つの計算条件でルート検索および地図上のルート描画を行います。\
検索条件別にルート結果の表示ON/OFFをチェックボックスで制御するコードも確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１１&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      position: absolute;<br>\
      top: 4px;<br>\
      left: 4px;<br>\
      width: 380px;<br>\
      height: 256px;<br>\
    }<br>\
    #center_image {<br>\
      width: 34px;<br>\
      height: 30px;<br>\
    }<br>\
    #center_div {<br>\
      z-index: 5000000;<br>\
      position: absolute;<br>\
      left: 177px;<br>\
      top: 117px;<br>\
      pointer-events: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--ルート関連のDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #positions_bar {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 264px;<br>\
      left: 0px;<br>\
      width: 380px;<br>\
      height: 24px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #info_window {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 2px;<br>\
      left: 390px;<br>\
      width: 218px;<br>\
      height: 256px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #operation_bar {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 264px;<br>\
      left: 390px;<br>\
      width: 218px;<br>\
      height: 24px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #loading {<br>\
      margin: 0px;<br>\
      position: absolute;<br>\
      top: 0px;<br>\
      left: 0px;<br>\
      width: 100%;<br>\
      height: 100%;<br>\
      z-index: 5000001;<br>\
      visibility : hidden;<br>\
      background-color: rgba(0,0,0,0.2);<br>\
      filter:progid:DXImageTransform.Microsoft.Gradient(<br>\
       GradientType=0,StartColorStr=#22000000,EndColorStr=#22000000);<br>\
    }<br>\
    #loading_title {<br>\
      padding-top: 20px;<br>\
      text-align: center;<br>\
      position: absolute;<br>\
      top: 40px;<br>\
      left:120px;<br>\
      width: 240px;<br>\
      height: 60px;<br>\
      color: black;<br>\
      background-color: white;<br>\
    }<br>\
    .info_box {<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 2px;<br>\
      left: 2px;<br>\
      width: 214px;<br>\
      height: 252px;<br>\
      background-color:#dddddd;<br>\
    }<br>\
    .item1 {<br>\
      padding: 2px;<br>\
    }<br>\
    .item2 {<br>\
      margin-left: 2px;<br>\
      float: left;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１１．経路検索条件設定 ＊＊＊<br>\
<br>\
    //＊＊＊　イニシャル処理処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル１０参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.routeHost = &#x27;api-route-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 認証後の各種イニシャル処理：サンプル１０参照 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        polylineThinningDown : true,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7472311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### レイヤー追加 ###<br>\
      // ケース１，２，３それぞれで別のジオメトリーレイヤーを追加。<br>\
      // ケース１→２→３の優先順位で表示するように、3→2→1の順番で登録。<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer3&#x27;);<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer2&#x27;);<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer1&#x27;);<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      initScreen();<br>\
    }<br>\
<br>\
    //＊＊＊　各種イベント処理　＊＊＊<br>\
<br>\
    //--- 出発地、目的地セット処理：サンプル１０参照 ---<br>\
    function setPoint(type) {<br>\
      if(type==&#x27;s&#x27;)<br>\
        createPointMarker(&#x27;start_marker&#x27;,0);<br>\
      else if(type==&#x27;d&#x27;)<br>\
        createPointMarker(&#x27;destination_marker&#x27;,50);<br>\
    }<br>\
<br>\
    //### ルート検索＆描画要求処理 ###<br>\
    // 検索実行ボタンを押したときに実行。<br>\
    // ３つの条件の処理を以下の流れで実施。<br>\
    //   ①doCalcAndDraw()：ケース１の検索＆描画要求<br>\
    //   ②route_calc_and_draw_completed1()：ケース２の検索＆描画要求<br>\
    //   ③route_calc_and_draw_completed2()：ケース３の検索＆描画要求<br>\
    //   ④route_calc_and_draw_completed3()：経路表示ON-OFF操作画面の表示<br>\
    // ※３ケース同時にルート検索＆描画要求処理メソッドを実行すると、非同期に処理され、描画の<br>\
    // 　実行順が不定になります。<br>\
    // 　ここでは、標準のケース１が一番最初に表示されるように、上記処理の流れで実行しています。<br>\
    function doCalcAndDraw() {<br>\
<br>\
      //--- 各種ボタンのアクティブ制御：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;calc&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;start&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;destination&#x27;).disabled=true;<br>\
<br>\
      //--- 出発地、目的地の設定チェック：サンプル１０参照 ---<br>\
      if( Mfapi.Features.getObjectType(&#x27;start_marker&#x27;) == -1 ) {<br>\
        window.alert(&quot;出発地が設定されていません。&quot;);<br>\
        document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
        document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
        return;<br>\
      }<br>\
      if( Mfapi.Features.getObjectType(&#x27;destination_marker&#x27;) == -1 ) {<br>\
        window.alert(&quot;目的地が設定されていません。&quot;);<br>\
        document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
        document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
        document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
        return;<br>\
      }<br>\
      <br>\
      //--- リセットボタンを非アクティブ：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=true;<br>\
<br>\
      //--- 検索中画面の表示ON：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      <br>\
      //### ケース１：ルート検索条件&quot;optCalc&quot;の作成 ###<br>\
      // 条件：検索優先条件=標準、有料道路使用条件=標準<br>\
      var optCalc = {<br>\
        start : Mfapi.Features.Marker[&#x27;start_marker&#x27;].getPosition(),<br>\
        destination : Mfapi.Features.Marker[&#x27;destination_marker&#x27;].getPosition(),<br>\
        priority : 0,<br>\
        tollway : 0<br>\
      };<br>\
<br>\
      //### ケース１：経路描画条件&quot;optDraw&quot;の作成 ###<br>\
      // 条件：レイヤー&#x27;gLayer1&#x27;、ポリラインタイプ設定=グリーン<br>\
      var optDraw = {<br>\
        geometryLayerId : &#x27;gLayer1&#x27;,<br>\
        drawPolylineType : Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_GREEN<br>\
      };<br>\
      <br>\
      //### ケース１：ルート検索＆経路描画要求のメソッド実行 ###<br>\
      Mfapi.Route.requestRouteCalcAndDraw(&#x27;route-1&#x27;,optCalc,optDraw,route_calc_and_draw_completed1);<br>\
    }<br>\
<br>\
    //### ケース１：ルート検索＆経路描画終了時の処理 ###<br>\
    function route_calc_and_draw_completed1(result_routeId) {<br>\
<br>\
      //### ケース２：ルート検索条件&quot;optCalc&quot;の作成 ###<br>\
      // 条件：検索優先条件=標準、有料道路使用条件=優先<br>\
      var optCalc = {<br>\
        start : Mfapi.Features.Marker[&#x27;start_marker&#x27;].getPosition(),<br>\
        destination : Mfapi.Features.Marker[&#x27;destination_marker&#x27;].getPosition(),<br>\
        priority : 0,<br>\
        tollway : 1<br>\
      };<br>\
<br>\
      //### ケース２：経路描画条件&quot;optDraw&quot;の作成 ###<br>\
      // 条件：レイヤー&#x27;gLayer2&#x27;、ポリラインタイプ設定=イエロー<br>\
      var optDraw = {<br>\
        geometryLayerId : &#x27;gLayer2&#x27;,<br>\
        drawPolylineType : Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_YELLOW<br>\
      };<br>\
<br>\
      //### ケース２：ルート検索＆経路描画要求のメソッド実行 ###<br>\
      Mfapi.Route.requestRouteCalcAndDraw(&#x27;route-2&#x27;,optCalc,optDraw,route_calc_and_draw_completed2);<br>\
    }<br>\
<br>\
    //### ケース２：ルート検索＆経路描画終了時の処理 ###<br>\
    function route_calc_and_draw_completed2(result_routeId) {<br>\
<br>\
      //### ケース３：ルート検索条件&quot;optCalc&quot;の作成 ###<br>\
      // 条件：検索優先条件=標準、有料道路使用条件=優先<br>\
      var optCalc = {<br>\
        start : Mfapi.Features.Marker[&#x27;start_marker&#x27;].getPosition(),<br>\
        destination : Mfapi.Features.Marker[&#x27;destination_marker&#x27;].getPosition(),<br>\
        priority : 1,<br>\
        tollway : 0<br>\
      };<br>\
<br>\
      //### ケース３：経路描画条件&quot;optDraw&quot;の作成 ###<br>\
      // 条件：レイヤー&#x27;gLayer3&#x27;、ポリラインタイプ設定=ブルー<br>\
      var optDraw = {<br>\
        geometryLayerId : &#x27;gLayer3&#x27;,<br>\
        drawPolylineType :  Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_BLUE<br>\
      };<br>\
<br>\
      //### ケース３：ルート検索＆経路描画要求のメソッド実行 ###<br>\
      Mfapi.Route.requestRouteCalcAndDraw(&#x27;route-3&#x27;,optCalc,optDraw,route_calc_and_draw_completed3);<br>\
    }<br>\
<br>\
    //### ケース３：ルート検索＆経路描画終了時の処理 ###<br>\
    function route_calc_and_draw_completed3(result_routeId) {<br>\
<br>\
      //### 情報窓：経路表示ON-OFF操作画面表示 ###<br>\
      document.getElementById(&#x27;explain&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
      document.getElementById(&#x27;visibility_ctrl&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      document.getElementById(&#x27;cond1&#x27;).checked=&#x27;checked&#x27;;<br>\
      document.getElementById(&#x27;cond2&#x27;).checked=&#x27;checked&#x27;;<br>\
      document.getElementById(&#x27;cond3&#x27;).checked=&#x27;checked&#x27;;<br>\
<br>\
      //--- 検索中画面の表示OFF：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //--- 戻るボタンをアクティブ：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;back&#x27;).disabled=false;<br>\
<br>\
      //--- リセットボタンをアクティブ：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=false;<br>\
    }<br>\
<br>\
    //### 戻るボタンの処理 ###<br>\
    function doBack() {<br>\
<br>\
      //### ルートデータ全件削除 ###<br>\
      Mfapi.Route.removeAllRteInfo();<br>\
<br>\
      //--- 情報窓：説明文表示：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;explain&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      document.getElementById(&#x27;visibility_ctrl&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //--- 各種ボタンのアクティブ制御：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
    }<br>\
<br>\
    //### リセットボタンの処理 ###<br>\
    function doReset() {<br>\
<br>\
      //### ルートデータ全件削除 ###<br>\
      Mfapi.Route.removeAllRteInfo();<br>\
<br>\
      //--- 出発地、目的地のマーカー削除：サンプル１０参照 ---<br>\
      if( Mfapi.Features.getObjectType(&#x27;start_marker&#x27;) != -1 ) {<br>\
        Mfapi.Features.remove(&#x27;start_marker&#x27;);<br>\
      }<br>\
      if( Mfapi.Features.getObjectType(&#x27;destination_marker&#x27;) != -1 ) {<br>\
        Mfapi.Features.remove(&#x27;destination_marker&#x27;);<br>\
      }<br>\
<br>\
      //--- 画面初期化：サンプル１０参照 ---<br>\
      initScreen();<br>\
    }<br>\
<br>\
    //### 経路ポリライン表示状態切り替え時の処理 ###<br>\
    // 情報窓の各ケースのチェックボックスの状態が変わったときに実行。<br>\
    function changeVisibility(elem,route_id) {<br>\
      //### 該当ルートの表示条件に反映 ###<br>\
      Mfapi.Route.setVisible(route_id, elem.checked);<br>\
    }<br>\
<br>\
    //＊＊＊　各種汎用処理　＊＊＊<br>\
<br>\
    //### 画面初期化処理 ###<br>\
    // 結果テキストのリセットがない以外はサンプル１０と同じ。<br>\
    function initScreen() {<br>\
<br>\
      //### 情報窓の表示制御 ###<br>\
      // 初期時は説明文側を表示する。<br>\
      document.getElementById(&#x27;explain&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
      document.getElementById(&#x27;visibility_ctrl&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //### 各種ボタンのアクティブ制御 ###<br>\
      // 戻るボタン以外をアクティブにする。(リセットボタンは常時アクティブのままとなる。)<br>\
      document.getElementById(&#x27;start&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;destination&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;calc&#x27;).disabled=false;<br>\
      document.getElementById(&#x27;back&#x27;).disabled=true;<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=false;<br>\
<br>\
      //### 検索中画面の表示OFF ###<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
   }<br>\
<br>\
    //--- DIVタグのリセット処理：サンプル１０参照 ---<br>\
    function recretateDiv(targetId,parentId) {<br>\
      var div = document.getElementById(targetId);<br>\
      if( div )<br>\
        document.getElementById(parentId).removeChild(div);<br>\
      var new_div = document.createElement(&#x27;div&#x27;);<br>\
      new_div.setAttribute(&#x27;id&#x27;, targetId);<br>\
      document.getElementById(parentId).appendChild(new_div);<br>\
    }<br>\
<br>\
    //--- 地点マーカー作成処理：サンプル１０参照 ---<br>\
    function createPointMarker(marker_id,cx) {<br>\
      if( Mfapi.Features.getObjectType(marker_id) != -1 )<br>\
        Mfapi.Features.remove(marker_id);<br>\
      var optMarker = {<br>\
        position: Mfapi.Map.getCenterPosition(),<br>\
        imageUrl: &#x27;./img/route_points.png&#x27;,<br>\
        cuttingPoint: { x: cx, y: 0 },<br>\
        imageSize : { width: 50, height: 50 },<br>\
        imageOffset : { x: -25, y: -49 }<br>\
      };<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(optMarker,marker_id);<br>\
    }<br>\
<br>\
    //--- ラベル追加汎用処理：サンプル１０参照 ---<br>\
    function addLabel(parentId,text,css_class,id,move) {<br>\
      var textNode = document.createTextNode(text);<br>\
      var label = document.createElement(&#x27;label&#x27;);<br>\
      label.appendChild(textNode);<br>\
      if(css_class!=&#x27;&#x27;)<br>\
        label.setAttribute(&#x27;class&#x27;, css_class);<br>\
      if(id!=null) {<br>\
        if(id!=&#x27;&#x27;)<br>\
          label.setAttribute(&#x27;id&#x27;, id);<br>\
      }<br>\
      var div = document.createElement(&#x27;div&#x27;);<br>\
      if(move!=null) {<br>\
        label.setAttribute(&#x27;onclick&#x27;,&#x27;moveMap(&#x27;+move.lon+&#x27;,&#x27;+move.lat+&#x27;,this)&#x27;);<br>\
      }<br>\
      div.appendChild(label);<br>\
      document.getElementById(parentId).appendChild(div);<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図描画対象となるDIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地図中心を示すパーツのDIVタグ--&gt;<br>\
  &lt;div id=&#x27;center_div&#x27;&gt;&lt;img id=&#x27;center_image&#x27; src=&#x27;img/center.png&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--条件設定バーDIVタグ--&gt;<br>\
  &lt;div id=&#x27;positions_bar&#x27;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;出発地設定&quot; id=&quot;start&quot; onclick=&quot;setPoint(&#x27;s&#x27;);&quot;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;目的地設定&quot; id=&quot;destination&quot; onclick=&quot;setPoint(&#x27;d&#x27;);&quot;&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--情報窓DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info_window&#x27;&gt;<br>\
    &lt;div id=&#x27;explain&#x27; class=&quot;info_box&quot;&gt;<br>\
      &lt;label&gt;出発地、目的地を設定したら、検索実行ボタンを押してください。&lt;/label&gt;<br>\
    &lt;/div&gt;<br>\
    &lt;div id=&#x27;visibility_ctrl&#x27; class=&quot;info_box&quot;&gt;<br>\
      &lt;table&gt;<br>\
        &lt;tr&gt;&lt;th colspan=&quot;4&quot;&gt;ルート検索結果：&lt;/th&gt;&lt;/tr&gt;<br>\
        &lt;tr&gt;&lt;td&gt;&lt;input type=&quot;checkbox&quot; id=&quot;cond1&quot; onclick=&quot;changeVisibility(this,&#x27;route-1&#x27;)&quot;&gt;&lt;/td&gt;<br>\
          &lt;td&gt;①&lt;/td&gt;&lt;td&gt;&lt;img src=&quot;img/green_line.png&quot;&gt;&lt;/td&gt;&lt;td&gt;標準&lt;/td&gt;&lt;/tr&gt;<br>\
        &lt;tr&gt;&lt;td&gt;&lt;input type=&quot;checkbox&quot; id=&quot;cond2&quot; onclick=&quot;changeVisibility(this,&#x27;route-2&#x27;)&quot;&gt;&lt;/td&gt;<br>\
          &lt;td&gt;②&lt;/td&gt;&lt;td&gt;&lt;img src=&quot;img/yellow_line.png&quot;&gt;&lt;/td&gt;&lt;td&gt;有料道路優先&lt;/td&gt;&lt;/tr&gt;<br>\
        &lt;tr&gt;&lt;td&gt;&lt;input type=&quot;checkbox&quot; id=&quot;cond3&quot; onclick=&quot;changeVisibility(this,&#x27;route-3&#x27;)&quot;&gt;&lt;/td&gt;<br>\
          &lt;td&gt;③&lt;/td&gt;&lt;td&gt;&lt;img src=&quot;img/blue_line.png&quot;&gt;&lt;/td&gt;&lt;td&gt;距離優先&lt;/td&gt;&lt;/tr&gt;<br>\
      &lt;/table&gt;<br>\
    &lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--操作バーDIVタグ--&gt;<br>\
  &lt;div id=&#x27;operation_bar&#x27;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;検索実行&quot; id=&quot;calc&quot; onclick=&quot;doCalcAndDraw();&quot;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;戻る&quot; id=&quot;back&quot; onclick=&quot;doBack();&quot;&gt;<br>\
    &lt;input type=&quot;button&quot; class=&quot;item2&quot; value=&quot;リセット&quot; id=&quot;reset&quot; onclick=&quot;doReset();&quot;&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--検索中画面DIVタグ--&gt;<br>\
  &lt;div id=&quot;loading&quot;&gt;<br>\
    &lt;div id=&quot;loading_title&quot;&gt;ルート検索＆描画処理中&lt;img src=&quot;img/loader.gif&quot;&gt;&lt;/img&gt;&lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample11.html"
},

{
title: "12.現在地住所の表示",
sum: "<p>住所逆引き検索APIサービスを利用した地図中心付近の住所表示を行うコードが確認できます。</p>",
detail: "\
本サンプルでは、サンプル６をベースに、地図座標の移動を検出したら、JSONPの仕組みを使って、住所逆引き検索APIを実行し、\
地図中心付近の住所表示をリアルタイムに行う機能を追加したコードが確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１２&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      float: left;<br>\
      width: 480px;<br>\
      height: 280px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
      outline: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--情報表示DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #info {<br>\
      float: left;<br>\
      margin: 4px;<br>\
      padding: 4px;<br>\
      background-color:#eeeeee;<br>\
    }<br>\
    .value1 {<br>\
      width: 130px;<br>\
    }<br>\
    .value2 {<br>\
      width: 36px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--地図中心を示すパーツのアイコン画像とDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #center_image {<br>\
      width: 34px;<br>\
      height: 30px;<br>\
    }<br>\
    #center_div {<br>\
      position: absolute;<br>\
      z-index: 5000000;<br>\
      left: 233px;<br>\
      top: 135px;<br>\
      pointer-events: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--住所情報表示DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #address_info {<br>\
      position: absolute;<br>\
      z-index: 5000000;<br>\
      left: 80px;<br>\
      top: 246px;<br>\
      width: 260px;<br>\
      height: 18px;<br>\
    }<br>\
    .value3 {<br>\
      width: 250px;<br>\
      background-color: #eeeeee;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１２．現在地住所の表示 ＊＊＊<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    //### 検索サーバーのホスト名 ###<br>\
    var srchHost = &#x27;api-srch-pre.mapfan.com&#x27;;<br>\
<br>\
    //### 最新のAPI要求受付時刻 ###<br>\
    // 住所逆引きAPI実行要求を受け付けた最新の時刻が上書きで記録される。<br>\
    var latestReqTime = 0;<br>\
<br>\
    //### 最新のAPI要求受付緯度経度 ###<br>\
    // 住所逆引きAPI実行要求を受け付けた最新の緯度経度が上書きで記録される。<br>\
    var latestReqPosition = new Mfapi.Util.LonLat(0,0);<br>\
<br>\
    //### API要求キュー配列 ###<br>\
    // 住所逆引きAPI実行要求を受け付けると、緯度、経度、要求受付時刻のプロパティからなるオブジェクト<br>\
    // を追加。<br>\
    // 住所逆引きAPIの実行が開始されると、該当オブジェクトを削除する。<br>\
    var queArray = [];<br>\
<br>\
    //### API実行対象の要求受付時刻 ###<br>\
    // 住所逆引きAPI実行中は、同API実行要求の受け付け時刻が格納される。<br>\
    // 住所逆引きAPIが実行していないときは、0が格納される。<br>\
    var apiTargetReqTime = 0;<br>\
<br>\
    //＊＊＊　イニシャル処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル６参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 認証後の各種イニシャル処理：サンプル６参照 ---<br>\
    function task_func(authStatus) {<br>\
      //--- 地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        mapOperationEnable: true,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.68119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //--- 地図状態変更イベントのコールバック関数をセット：サンプル６参照  ---<br>\
      Mfapi.Events.onChangedMapCenter = map_position_event;<br>\
      Mfapi.Events.onChangedMapScale = map_scale_event;<br>\
<br>\
      //--- 初期の地図DIVのフォーカスをonに設定：サンプル６参照  ---<br>\
      document.getElementById(&#x27;sample_map&#x27;).focus();<br>\
<br>\
      //### 情報表示：初期の中心緯度経度、スケール、フォーカスを代入 ###<br>\
      // サンプル６から住所表示のタグのリセットを追加。<br>\
      var scale = Mfapi.Map.getMapScale();<br>\
      var position = Mfapi.Map.getCenterPosition();<br>\
      document.getElementById(&#x27;scale&#x27;).value = scale;<br>\
      document.getElementById(&#x27;lon&#x27;).value = position.lon;<br>\
      document.getElementById(&#x27;lat&#x27;).value = position.lat;<br>\
      document.getElementById(&#x27;key-ctrl&#x27;).value = &#x27;on&#x27;;<br>\
      document.getElementById(&#x27;address&#x27;).value = &#x27;&#x27;;<br>\
    }<br>\
<br>\
    //＊＊＊　各種イベント処理　＊＊＊<br>\
<br>\
    //--- フォーカスの状態表示(on/off)：サンプル６参照  ---<br>\
    function onMapFocus() {<br>\
      document.getElementById(&#x27;key-ctrl&#x27;).value = &#x27;on&#x27;;<br>\
    }<br>\
    function onMapBlur() {<br>\
      document.getElementById(&#x27;key-ctrl&#x27;).value = &#x27;off&#x27;;<br>\
    }<br>\
<br>\
    //--- 地図スケール変更時の処理：サンプル６参照  ---<br>\
    function map_scale_event(scale) {<br>\
      document.getElementById(&#x27;scale&#x27;).value = scale;<br>\
    }<br>\
<br>\
    //### 地図中心緯度経度変更(地図移動)時の処理 ###<br>\
    function map_position_event(position) {<br>\
<br>\
      //--- 情報表示：中心緯度経度を代入：サンプル６参照  ---<br>\
      document.getElementById(&#x27;lon&#x27;).value = position.lon;<br>\
      document.getElementById(&#x27;lat&#x27;).value = position.lat;<br>\
<br>\
      //### 地図移動チェック処理実行のタイマーセット ###<br>\
      // 0.1秒後に実行するようにタイマーをセット<br>\
      var method = &quot;checkMoving(&quot;+position.lon+&quot;,&quot;+position.lat+&quot;);&quot;;<br>\
      window.setTimeout(method, 100);<br>\
    }<br>\
<br>\
    //### 地図移動チェック処理 ###<br>\
    // 地図移動イベントから0.1秒後に呼ばれる。<br>\
    // 地図移動が停止していることを確認したら、API要求処理を実行する。<br>\
    function checkMoving(prevPositionLon,prevPositionLat) {<br>\
<br>\
      //### 現在の地図中心緯度経度を取得 ###<br>\
      var currentPosition = Mfapi.Map.getCenterPosition();<br>\
<br>\
      //### 移動判定 ###<br>\
      // 地図移動イベントがあったときの緯度経度と現在の緯度経度が異なる場合、移動中と判断。<br>\
      // 移動中と判断した場合、本処理を中止する。(＝移動が完了したら、本処理が動作する。)<br>\
      if( prevPositionLon != currentPosition.lon || prevPositionLat != currentPosition.lat)<br>\
        return;<br>\
<br>\
      //### 重複API要求の確認 ###<br>\
      // 最新のAPI要求を受け付けた緯度経度と、現時点の地図中心点緯度経度とを照合し、同じ場合は<br>\
      // 重複でAPIを要求することになるので、本処理を中止。<br>\
      if( latestReqPosition.lon == currentPosition.lon &amp;&amp; latestReqPosition.lat == currentPosition.lat)<br>\
        return;<br>\
<br>\
      //### 最新のAPI要求を受け付けた時刻の更新 ###<br>\
      var currentDate = new Date();<br>\
      latestReqTime = currentDate.valueOf();<br>\
<br>\
      //### 最新のAPI要求を受け付けた緯度経度の更新 ###<br>\
      latestReqPosition = currentPosition;<br>\
<br>\
      //### キュー追加 ###<br>\
      // キューの最後に緯度経度と要求時刻を入れたデータを追加<br>\
      var queData = { lon:latestReqPosition.lon, lat:latestReqPosition.lat, reqTime:latestReqTime };<br>\
      queArray.push(queData);<br>\
<br>\
      //### API実行を要求 ###<br>\
      requestAPI();<br>\
    }<br>\
    <br>\
    //### API要求処理 ###<br>\
    // API要求受付時か、APIが完了後もキューがたまっている場合に呼ばれる。<br>\
    // APIが実行中でないときのみ、JSONPスクリプトを作成して、API実行を行う。<br>\
    function requestAPI() {<br>\
    <br>\
      //### API実行中判定 ###<br>\
      // API実行中の場合、この先の処理を実施しない。<br>\
      if(apiTargetReqTime!=0) return;<br>\
      <br>\
      //### キュー確認 ###<br>\
      // キューがたまっていない場合、この先の処理を実施しない。<br>\
      // (通常、この関数が呼ばれるとき、キューは１件以上あるが、異常時の対応のために実施)<br>\
      if(queArray.length==0) return;<br>\
    <br>\
      //### キューにたまっている一番古い(先頭の)データを取得＆削除 ###<br>\
      var queData = queArray.shift();<br>\
    <br>\
      //### APIターゲットの要求受付時刻をセット ###<br>\
      apiTargetReqTime = queData.reqTime;<br>\
<br>\
      //### API URL作成 ###<br>\
      var apiname = &#x27;/v1/addrname&#x27;;<br>\
      var param1 = &#x27;key=&#x27; + encodeURIComponent(Mfapi.getAuthAccessKey());<br>\
      var param2 = &#x27;lonlat=&#x27;+queData.lon+&quot;,&quot;+queData.lat;<br>\
      var param3 = &#x27;callback=addressWrite&#x27;;<br>\
      var protocol = window.location.protocol;<br>\
      if( protocol != &#x27;https:&#x27; ) protocol = &#x27;http:&#x27;;<br>\
      var reqUrl = protocol + &#x27;//&#x27; + srchHost + apiname + &#x27;?&#x27; + param1 + &#x27;&amp;&#x27; + param2 + &#x27;&amp;&#x27; + param3;<br>\
<br>\
      //### API実行(JSONPのスクリプト作成) ###<br>\
      var scrpJsonp = document.createElement(&#x27;script&#x27;);<br>\
      scrpJsonp.setAttribute(&#x27;type&#x27;, &#x27;text/javascript&#x27;);<br>\
      scrpJsonp.setAttribute(&#x27;charset&#x27;, &#x27;utf-8&#x27;);<br>\
      scrpJsonp.setAttribute(&#x27;id&#x27;, &#x27;addr&#x27;+apiTargetReqTime);<br>\
      scrpJsonp.setAttribute(&#x27;src&#x27;, reqUrl);<br>\
      var head = document.getElementsByTagName(&#x27;head&#x27;).item(0);<br>\
      head.appendChild(scrpJsonp);<br>\
    }<br>\
<br>\
    //### 現在地表示の処理 ###<br>\
    // 住所検索逆引きAPI終了後に呼ばれる。<br>\
    // 現在地表示を更新して、JSONPのスクリプトタグを削除する。<br>\
    function addressWrite(data) {<br>\
<br>\
      //### 現在地表示更新 ###<br>\
      // APIターゲットの要求受付時刻が、要求受付時刻のときのみ表示を更新<br>\
      if(apiTargetReqTime == latestReqTime) {<br>\
        //### 現在地表示 ###<br>\
        if( data.status == &#x27;success&#x27; ) {<br>\
          //### 現在地表示：住所を代入 ###<br>\
          document.getElementById(&#x27;address&#x27;).value = data.address;<br>\
        } else if ( data.status.slice(0,8) == &#x27;[I00001]&#x27; ) {<br>\
          //### 現在地表示：住所データなしのメッセージを代入 ###<br>\
          document.getElementById(&#x27;address&#x27;).value = &#x27;（住所データがありません）&#x27;;<br>\
        } else {<br>\
          //### 現在地表示：エラーメッセージを代入 ###<br>\
          document.getElementById(&#x27;address&#x27;).value = &#x27;エラー &#x27;+data.status;<br>\
        }<br>\
      }<br>\
<br>\
      //### JSONPスクリプトタグの削除 ###<br>\
      var head = document.getElementsByTagName(&#x27;head&#x27;).item(0);<br>\
      if(document.getElementById(&#x27;addr&#x27;+apiTargetReqTime)!=null) {<br>\
        head.removeChild(document.getElementById(&#x27;addr&#x27;+apiTargetReqTime));<br>\
      }<br>\
      <br>\
      //### APIターゲットの要求受付時刻をリセット ###<br>\
      apiTargetReqTime=0;<br>\
<br>\
      //### キュー確認 ###<br>\
      // キューにリクエストがたまっている場合、API要求処理を呼び出す<br>\
      if(queArray.length&gt;0)<br>\
        requestAPI();<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ：地図画面にフォーカスがあたるようにtabindexを追記しています。--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27; tabindex=&#x27;1&#x27; onfocus=&#x27;onMapFocus();&#x27;  onblur=&#x27;onMapBlur();&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--情報表示DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info&#x27;&gt;<br>\
    &lt;p&gt;経度(longitude)：&lt;br&gt;<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;lon&#x27; class=&#x27;value1&#x27; tabindex=&#x27;2&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
    &lt;p&gt;緯度(latitude)：&lt;br&gt;<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;lat&#x27; class=&#x27;value1&#x27; tabindex=&#x27;3&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
    &lt;p&gt;スケール：<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;scale&#x27; class=&#x27;value2&#x27; tabindex=&#x27;4&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
    &lt;p&gt;フォーカス：<br>\
      &lt;input type=&#x27;text&#x27; id=&#x27;key-ctrl&#x27; class=&#x27;value2&#x27; tabindex=&#x27;5&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--地図中心を示すパーツのDIVタグ--&gt;<br>\
  &lt;div id=&#x27;center_div&#x27;&gt;&lt;img id=&#x27;center_image&#x27; src=&#x27;img/center.png&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--住所情報表示DIVタグ--&gt;<br>\
  &lt;div id=&#x27;address_info&#x27;&gt;<br>\
    &lt;p&gt;&lt;input type=&#x27;text&#x27; id=&#x27;address&#x27; class=&#x27;value3&#x27; readonly&gt;&lt;/input&gt;&lt;/p&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample12.html"
},

{
title: "13.地図クリック",
sum: "<p>地図上で左ボタンをクリックしたときに発生するイベントを使ったコードが確認できます。</p>",
detail: "\
本サンプルでは、地図クリックイベント機能を用いて、地図上を直接クリックしてルートの出発地\
および目的地を設定する機能を実現しています。また、マウスムーブ機能のイベントを用いて、マウスカーソルが\
指した地点の緯度経度をリアルタイムに表示するコードも確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１３&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      position: absolute;<br>\
      top: 4px;<br>\
      left: 4px;<br>\
      width: 380px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--ルート関連のDIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #info_window {<br>\
      margin: 2px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 2px;<br>\
      left: 390px;<br>\
      width: 218px;<br>\
      height: 280px;<br>\
      background-color:#cccccc;<br>\
    }<br>\
    #loading {<br>\
      margin: 0px;<br>\
      position: absolute;<br>\
      top: 0px;<br>\
      left: 0px;<br>\
      width: 100%;<br>\
      height: 100%;<br>\
      z-index: 5000001;<br>\
      visibility : hidden;<br>\
      background-color: rgba(0,0,0,0.2);<br>\
      filter:progid:DXImageTransform.Microsoft.Gradient(<br>\
       GradientType=0,StartColorStr=#22000000,EndColorStr=#22000000);<br>\
    }<br>\
    #loading_title {<br>\
      padding-top: 20px;<br>\
      text-align: center;<br>\
      position: absolute;<br>\
      top: 40px;<br>\
      left:120px;<br>\
      width: 240px;<br>\
      height: 60px;<br>\
      color: black;<br>\
      background-color: white;<br>\
    }<br>\
    .divA {<br>\
      padding: 0px;<br>\
    }<br>\
    .item1 {<br>\
      margin: 1px;<br>\
    }<br>\
    .item2 {<br>\
      margin: 1px;<br>\
      position: relative;<br>\
      left: 10px;<br>\
    }<br>\
    .item3 {<br>\
      margin: 1px;<br>\
      position: relative;<br>\
      left: 16px;<br>\
    }<br>\
    .item4 {<br>\
      margin: 1px;<br>\
      width: 80px;<br>\
    }<br>\
    .item5 {<br>\
      margin: 1px;<br>\
      height: 22px;<br>\
    }<br>\
    .item6 {<br>\
      margin: 1px;<br>\
      align: center;<br>\
    }<br>\
    .item7 {<br>\
      margin: 2px;<br>\
    }<br>\
    .item8 {<br>\
      margin: 1px;<br>\
    }<br>\
    .item9 {<br>\
      width: 214px;<br>\
      margin: 1px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１３．地図クリック ＊＊＊<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    var phase = 1; //画面フェーズ情報(1=出発地設定,2=目的地設定,3=ルート計算結果表示)<br>\
<br>\
    //＊＊＊　イニシャル処理処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル９参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.routeHost = &#x27;api-route-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth( &#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 認証後の各種イニシャル処理 ###<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        polylineThinningDown : true,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7472311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### マーカー、ジオメトリーレイヤー追加 ###<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer&#x27;);<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### 地図クリック、マウスムーブイベントのコールバック関数指定 ###<br>\
      Mfapi.Events.onMapClick = mapClick;<br>\
      Mfapi.Events.onMapMouseMove = mapMouseMove;<br>\
<br>\
      //### 地図マウスムーブイベントの利用許可 ###<br>\
      Mfapi.Events.setEnableToUseMapMouseMoveEvent(true);<br>\
<br>\
      //### 画面初期化 ###<br>\
      initScreen();<br>\
    }<br>\
<br>\
    //＊＊＊　各種イベント処理　＊＊＊<br>\
<br>\
    //### 地図クリックイベント時の処理 ###<br>\
    function mapClick(screenPosition,mapPosition) {<br>\
<br>\
      //### クリック１回目：出発地セット ###<br>\
      if(phase==1) {<br>\
<br>\
        //### 出発地の緯度経度の表示色を黒色に変更 ###<br>\
        document.getElementById(&#x27;start_lon&#x27;).style.color = &#x27;black&#x27;;<br>\
        document.getElementById(&#x27;start_lat&#x27;).style.color = &#x27;black&#x27;;<br>\
<br>\
        //### クリックされた地図地点を、出発地の緯度経度として表示 ###<br>\
        document.getElementById(&#x27;start_lon&#x27;).innerHTML=mapPosition.lon;<br>\
        document.getElementById(&#x27;start_lat&#x27;).innerHTML=mapPosition.lat;<br>\
<br>\
        //### 目的地の緯度経度の表示色を青色に変更 ###<br>\
        document.getElementById(&#x27;destination_lon&#x27;).style.color = &#x27;blue&#x27;;<br>\
        document.getElementById(&#x27;destination_lat&#x27;).style.color = &#x27;blue&#x27;;<br>\
<br>\
        //### クリックされた地図地点上に出発地のマーカーを作成 ###<br>\
        createPointMarker(&#x27;start_marker&#x27;,0,mapPosition);<br>\
<br>\
        //### メッセージを変更 ###<br>\
        document.getElementById(&#x27;message&#x27;).innerHTML=&#x27;目的地を設定してください。&#x27;;<br>\
<br>\
        //### フェーズ変数の値を変更 ###<br>\
        phase = 2;<br>\
<br>\
      //###  クリック２回目：目的地セット ###<br>\
      } else if(phase==2) {<br>\
<br>\
        //### 目的地の緯度経度の表示色を黒色に変更 ###<br>\
        document.getElementById(&#x27;destination_lon&#x27;).style.color = &#x27;black&#x27;;<br>\
        document.getElementById(&#x27;destination_lat&#x27;).style.color = &#x27;black&#x27;;<br>\
<br>\
        //### クリックされた地図地点を、目的地の緯度経度として表示 ###<br>\
        document.getElementById(&#x27;destination_lon&#x27;).innerHTML=mapPosition.lon;<br>\
        document.getElementById(&#x27;destination_lat&#x27;).innerHTML=mapPosition.lat;<br>\
<br>\
        //### クリックされた地図地点上に出発地のマーカーを作成 ###<br>\
        createPointMarker(&#x27;destination_marker&#x27;,50,mapPosition);<br>\
<br>\
        //### メッセージを変更 ###<br>\
        document.getElementById(&#x27;message&#x27;).innerHTML=&#x27;&#x27;;<br>\
<br>\
        //### フェーズ変数の値を変更 ###<br>\
        phase = 3;<br>\
<br>\
        //--- リセットボタンを非アクティブ：サンプル１０参照 ---<br>\
        document.getElementById(&#x27;reset&#x27;).disabled=true;<br>\
<br>\
        //--- ルート検索中画面の表示ON：サンプル１０参照 ---<br>\
        document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
<br>\
        //--- ルート計算条件、描画条件のセット：サンプル１０参照 ---<br>\
        var optCalc = {<br>\
          start : Mfapi.Features.Marker[&#x27;start_marker&#x27;].getPosition(),<br>\
          destination : Mfapi.Features.Marker[&#x27;destination_marker&#x27;].getPosition(),<br>\
          priority : 0,<br>\
          tollway : 0<br>\
        };<br>\
        var optDraw = {<br>\
          geometryLayerId : &#x27;gLayer&#x27;,<br>\
          drawPolylineType : Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_GREEN<br>\
        };<br>\
<br>\
        //--- ルート検索＆経路描画リクエスト：サンプル１０参照 ---<br>\
        Mfapi.Route.requestRouteCalcAndDraw(&#x27;route&#x27;,optCalc,optDraw,route_calc_and_draw_completed);<br>\
      }<br>\
    }<br>\
<br>\
    //### ルート検索＆経路描画終了時の処理 ###<br>\
    function route_calc_and_draw_completed(result_routeId) {<br>\
<br>\
      //### ルート検索結果の取得 ###<br>\
      var calcData = Mfapi.Route.RteInfo[result_routeId].calcData;<br>\
<br>\
      //### 結果テキストセット ###<br>\
      // 検索結果サマリーの総所要時間と総距離を表示。<br>\
      // ルート検索失敗時はステータスを表示。<br>\
      if(calcData.status==&#x27;success&#x27;) {<br>\
        document.getElementById(&#x27;message&#x27;).innerHTML=&#x27;ルート計算が完了しました。&#x27;;<br>\
        var distanse = parseInt(calcData.summary.totalDistance)+&#x27;m&#x27;;<br>\
        var time = parseInt(calcData.summary.totalTravelTime)+&#x27;秒&#x27;;<br>\
        document.getElementById(&#x27;distance&#x27;).innerHTML = distanse;<br>\
        document.getElementById(&#x27;time&#x27;).innerHTML = time;<br>\
      } else {<br>\
        window.alert(&#x27;ルート検索エラー：&#x27;+calcData.status);<br>\
      }<br>\
<br>\
      //--- 検索中画面の表示OFF：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;loading&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
<br>\
      //--- リセットボタンをアクティブ：サンプル１０参照 ---<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=false;<br>\
    }<br>\
<br>\
    //### 地図マウスムーブイベント時の処理 ###<br>\
    function mapMouseMove(screenPosition,mapPosition) {<br>\
<br>\
      //### フェーズ１：出発地セット中 ###<br>\
      if(phase==1) {<br>\
        //### 現在マウスカーソルが指している地図の位置を、出発地の緯度経度として表示 ###<br>\
        document.getElementById(&#x27;start_lon&#x27;).innerHTML=mapPosition.lon;<br>\
        document.getElementById(&#x27;start_lat&#x27;).innerHTML=mapPosition.lat;<br>\
<br>\
      //### フェーズ２：目的地セット中 ###<br>\
      } else if(phase==2) {<br>\
        //### 現在マウスカーソルが指している地図の位置を、目的地の緯度経度として表示 ###<br>\
        document.getElementById(&#x27;destination_lon&#x27;).innerHTML=mapPosition.lon;<br>\
        document.getElementById(&#x27;destination_lat&#x27;).innerHTML=mapPosition.lat;<br>\
      }<br>\
    }<br>\
<br>\
    //### リセットボタンの処理：サンプル１０参照 ###<br>\
    function doReset() {<br>\
      //### ルートのデータ削除とマーカーの削除 ###<br>\
      Mfapi.Route.removeAllRteInfo();<br>\
      if( Mfapi.Features.getObjectType(&#x27;start_marker&#x27;) != -1 ) {<br>\
        Mfapi.Features.remove(&#x27;start_marker&#x27;);<br>\
      }<br>\
      if( Mfapi.Features.getObjectType(&#x27;destination_marker&#x27;) != -1 ) {<br>\
        Mfapi.Features.remove(&#x27;destination_marker&#x27;);<br>\
      }<br>\
<br>\
      //### フェーズの値を1に戻す ###<br>\
      phase = 1;<br>\
<br>\
      //### 画面初期化 ###<br>\
      initScreen();<br>\
    }<br>\
<br>\
    //＊＊＊　各種汎用処理　＊＊＊<br>\
<br>\
    //### 画面初期化処理 ###<br>\
    function initScreen() {<br>\
      //### 各種テキスト、スタイルの初期値セット ###<br>\
      document.getElementById(&#x27;start_lon&#x27;).style.color = &#x27;blue&#x27;;<br>\
      document.getElementById(&#x27;start_lat&#x27;).style.color = &#x27;blue&#x27;;<br>\
      document.getElementById(&#x27;destination_lon&#x27;).style.color = &#x27;black&#x27;;<br>\
      document.getElementById(&#x27;destination_lat&#x27;).style.color = &#x27;black&#x27;;<br>\
      document.getElementById(&#x27;start_lon&#x27;).innerHTML=&#x27;&#x27;;<br>\
      document.getElementById(&#x27;start_lat&#x27;).innerHTML=&#x27;&#x27;;<br>\
      document.getElementById(&#x27;destination_lon&#x27;).innerHTML=&#x27;&#x27;;<br>\
      document.getElementById(&#x27;destination_lat&#x27;).innerHTML=&#x27;&#x27;;<br>\
      document.getElementById(&#x27;distance&#x27;).innerHTML=&#x27;&#x27;;<br>\
      document.getElementById(&#x27;time&#x27;).innerHTML=&#x27;&#x27;;<br>\
      document.getElementById(&#x27;message&#x27;).innerHTML=&#x27;出発地を設定してください。&#x27;;<br>\
      document.getElementById(&#x27;reset&#x27;).disabled=false;<br>\
   }<br>\
<br>\
    //--- DIVタグのリセット処理：サンプル１０参照 ---<br>\
    function recretateDiv(targetId,parentId) {<br>\
      var div = document.getElementById(targetId);<br>\
      if( div )<br>\
        document.getElementById(parentId).removeChild(div);<br>\
      var new_div = document.createElement(&#x27;div&#x27;);<br>\
      new_div.setAttribute(&#x27;id&#x27;, targetId);<br>\
      document.getElementById(parentId).appendChild(new_div);<br>\
    }<br>\
<br>\
    //--- 地点マーカー作成処理：サンプル１０参照 ---<br>\
    function createPointMarker(marker_id,cx,mapPosition) {<br>\
      if( Mfapi.Features.getObjectType(marker_id) != -1 )<br>\
        Mfapi.Features.remove(marker_id);<br>\
      var optMarker = {<br>\
        position: mapPosition,<br>\
        imageUrl: &#x27;./img/route_points.png&#x27;,<br>\
        cuttingPoint: { x: cx, y: 0 },<br>\
        imageSize : { width: 50, height: 50 },<br>\
        imageOffset : { x: -25, y: -49 }<br>\
      };<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(optMarker,marker_id);<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図描画対象となるDIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--情報窓DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info_window&#x27;&gt;<br>\
    &lt;div class=&#x27;divA&#x27;&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item8&#x27;&gt;出発地&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item2&#x27;&gt;経度&lt;/label&gt;&lt;label id=&#x27;start_lon&#x27; class=&#x27;item3&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item2&#x27;&gt;緯度&lt;/label&gt;&lt;label id=&#x27;start_lat&#x27; class=&#x27;item3&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
    &lt;/div&gt;<br>\
    &lt;div class=&#x27;divA&#x27;&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item8&#x27;&gt;目的地&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item2&#x27;&gt;経度&lt;/label&gt;&lt;label id=&#x27;destination_lon&#x27; class=&#x27;item3&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item2&#x27;&gt;緯度&lt;/label&gt;&lt;label id=&#x27;destination_lat&#x27; class=&#x27;item3&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
    &lt;/div&gt;<br>\
    &lt;div class=&#x27;divA&#x27;&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item8&#x27;&gt;ルート計算結果&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item2&#x27;&gt;距離&lt;/label&gt;&lt;label id=&#x27;distance&#x27; class=&#x27;item3&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item1&#x27;&gt;<br>\
        &lt;label class=&#x27;item2&#x27;&gt;時間&lt;/label&gt;&lt;label id=&#x27;time&#x27; class=&#x27;item3&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
    &lt;/div&gt;<br>\
    &lt;div class=&#x27;divA&#x27;&gt;<br>\
      &lt;hr class=&#x27;item7&#x27;&gt;<br>\
      &lt;p class=&#x27;item5&#x27;&gt;<br>\
        &lt;label class=&#x27;item9&#x27; id=&#x27;message&#x27;&gt;&lt;/label&gt;<br>\
      &lt;/p&gt;<br>\
      &lt;p class=&#x27;item6&#x27; align=&#x27;center&#x27;&gt;<br>\
        &lt;input type=&quot;button&quot; class=&quot;item4&quot; value=&quot;リセット&quot; id=&quot;reset&quot; onclick=&quot;doReset();&quot;&gt;<br>\
      &lt;/p&gt;<br>\
    &lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
  &lt;!--検索中画面DIVタグ--&gt;<br>\
  &lt;div id=&quot;loading&quot;&gt;<br>\
    &lt;div id=&quot;loading_title&quot;&gt;ルート検索＆描画処理中&lt;img src=&quot;img/loader.gif&quot;&gt;&lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample13.html"
},

{
title: "14.マーカークリック",
sum: "<p>マーカー上で左ボタンをクリックしたときに発生するイベントを使ったコードが確認できます。</p>",
detail: "\
本サンプルでは、マーカークリックイベント機能を用いて、マーカー上をクリックしたら、オリジナルデザインの\
ポップアップを表示する機能を実現しています。\
また、指定した緯度経度に地図を少しずつスクロールする処理のコードも確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１４&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      position: absolute;<br>\
      left: 0px;<br>\
      top: 0px;<br>\
      width: 660px;<br>\
      height: 280px;<br>\
      margin: 0px;<br>\
    }<br>\
    #popup_base {<br>\
      margin: 0px;<br>\
      position: absolute;<br>\
      top: 0px;<br>\
      left: 0px;<br>\
      width: 660px;<br>\
      height: 280px;<br>\
      z-index: 5000001;<br>\
      visibility : hidden;<br>\
      background-color: rgba(0,0,0,0.4);<br>\
      filter:progid:DXImageTransform.Microsoft.Gradient(<br>\
       GradientType=0,StartColorStr=#44000000,EndColorStr=#44000000);<br>\
    }<br>\
    #popup {<br>\
      position: absolute;<br>\
      left: 170px;<br>\
      top: 20px;<br>\
      width: 320px;<br>\
      height: 160px;<br>\
      margin: 0px;<br>\
    }<br>\
    .popup_content {<br>\
      position: absolute;<br>\
      padding: 30px;<br>\
      left: 0px;<br>\
      top: 0px;<br>\
      margin: 0px;<br>\
    }<br>\
    .item1 {<br>\
      position: absolute;<br>\
      left: 10px;<br>\
      top: 10px;<br>\
      color: white;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１４．マーカークリック ＊＊＊<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    //### 地点データ列セット ###<br>\
    var pointData = [<br>\
      { name: &#x27;東京駅&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
        text:&#x27;とうきょうえき が クリックされた！&#x27; },<br>\
      { name: &#x27;新橋駅&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
        text:&#x27;しんばしえき が クリックされた！&#x27; },<br>\
      { name: &#x27;豊洲駅&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
        text:&#x27;とよすえき が クリックされた！&#x27; },<br>\
      { name: &#x27;有明駅&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
        text:&#x27;ありあけえき が クリックされた！&#x27; },<br>\
      { name: &#x27;品川駅&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
        text:&#x27;しながわえき が クリックされた！&#x27; },<br>\
      { name: &#x27;渋谷駅&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
        text:&#x27;しぶやえき が クリックされた！&#x27; },<br>\
      { name: &#x27;新宿駅&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
        text:&#x27;しんじゅくえき が クリックされた！&#x27; }<br>\
    ];<br>\
<br>\
    //### ポップアップの表示位置に関する定義 ###<br>\
    // 本サンプルでは、ポップアップ表示時、ポップアップが画面中心付近で、その下にマーカーが表示される<br>\
    // ように地図を移動。このとき、マーカーの緯度経度を基準として、地図中心座標の上方向にシフトする量<br>\
    // をピクセル値で指定。<br>\
    var mapX0 = 330;  // 地図DIVタグの中心座標X値<br>\
    var mapY0 = 140;  // 地図DIVタグの中心座標Y値<br>\
    var mapOffsetY = 60;  // 表示位置下オフセット量<br>\
<br>\
    //### 地図座標移動のアニメ効果に関する定義 ###<br>\
    // 本サンプルでは、現在地から指定された緯度経度に徐々にスクロールする関数&quot;smoothMovePosition&quot;<br>\
    // を用意。ここで定義するパラメータによって、コマ数や表示速度を指定。<br>\
    var posArrayCount = 10;  // 移動コマ数<br>\
    var deltaTime = 10;  // １コマあたりの時間。単位はms。<br>\
<br>\
    //### マーカーに関する定義 ###<br>\
    var iconSizeX = 84, iconSizeY = 100;  // マーカー画像のサイズ<br>\
    var iconOffsetX = -42, iconOffsetY = -92;  // マーカー画像のオフセット<br>\
    var iconImageUrl = &#x27;./img/c.png&#x27;;  // マーカー画像のURL<br>\
<br>\
    //### その他変数 ###<br>\
    var popupShow = false;  // ポップアップ表示の状態変数<br>\
    var posArray = [];  // 地図座標移動のアニメ効果における座標配列<br>\
    var callbackForMovPos = null;  // 地図座標移動のアニメ効果で使うコールバック関数<br>\
<br>\
    //＊＊＊　イニシャル処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth( &#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 認証後の各種イニシャル処理 ###<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        mapStyle : &#x27;rpg_pc&#x27;,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### マーカーレイヤー追加 ###<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### マーカー作成ループ処理 ###<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
<br>\
        //### マーカー　フィーチャー識別子作成および条件セット ###<br>\
        var id = &#x27;marker#&#x27;+i;<br>\
        var opt = {<br>\
          position : new Mfapi.Util.LonLat(pointData[i].lon, pointData[i].lat),<br>\
          imageUrl : iconImageUrl,<br>\
          imageSize : new Mfapi.Util.ScreenSize(iconSizeX, iconSizeY),<br>\
          imageOffset : new Mfapi.Util.ScreenPoint(iconOffsetX, iconOffsetY),<br>\
          imageOpacity : 1.0<br>\
        };<br>\
<br>\
        //### マーカー作成＆レイヤー追加 ###<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt, id);<br>\
      }<br>\
<br>\
      //### マーカークリックのコールバック関数指定 ###<br>\
      Mfapi.Events.onMarkerClick = markerClick;<br>\
<br>\
      //### 地図クリックのコールバック関数指定 ###<br>\
      // ポップアップを消す処理のInternet Explorer向けの対策。<br>\
      // (解説)<br>\
      // 　ポップアップが表示されるとき、下記優先順位で表示している。<br>\
      // 　　①ポップアップコンテンツ(ID=popup_contentのDIVタグ)<br>\
      // 　　②ポップアップ画像(IMAGEタグ)<br>\
      // 　　③ポップアップベース(ID=popup_baseのDIVタグ。黒い半透明の地図と同じ大きさの矩形)<br>\
      // 　　④地図(ID=sample_mapのDIVタグ)<br>\
      // 　　　→①、②は③の子階層に属しているため、③、④より上に表示。<br>\
      // 　　　　①は②と同階層だが、HTMLファイル上、②の後に記述されているため、②より上に表示。<br>\
      // 　　　　③は④と同階層だが、z-indexを設定して、④より上に表示されるようにしている。<br>\
      // 　　　　なお、HTMLファイル上は③のほうが④より後に記述されている。<br>\
      // 　これに対し、以下のイベント登録を実施。(下方のDIVの記述参照）<br>\
      // 　　DIVタグ③：マウスダウン検出でポップアップを消す関数hidePopupを呼ぶ<br>\
      // 　この実装によって、ポップアップ表示後、黒い半透明部分とその子階層のポップアップ自身上で<br>\
      // 　マウスダウンを検出したら、ポップアップが消える仕様を実現している。<br>\
      // 　しかし、Internet Explorer8等では、z-indexで指定した表示優先順位に関係なく、同一階層の<br>\
      // 　DIVは、HTMLファイル上で最初に記述されているDIVのほうが、マウス操作のイベントを最初に<br>\
      // 　取得する仕様になっていて、③にイベントが伝播しない問題ある。そこで、④でマウスダウン<br>\
      // 　の代わりにクリックイベントを検出したら、関数hidePopupを呼ぶようにしている。<br>\
      Mfapi.Events.onMapClick = hidePopup;<br>\
<br>\
    }<br>\
<br>\
    //＊＊＊　各種イベント処理　＊＊＊<br>\
<br>\
    //### マーカークリックイベント検出時の処理 ###<br>\
    function markerClick(screenPosition,mapPosition,featureId,directAction) {<br>\
<br>\
      //### ポップアップ表示中のマーカークリックでの処理 ###<br>\
      // ポップアップを消す処理のInternet Explorer向けの対策。<br>\
      if(popupShow==true) {<br>\
        hidePopup();<br>\
        return;<br>\
      }<br>\
<br>\
      //### クリックされたマーカーの番号を取得 ###<br>\
      var i = parseInt(featureId.substr(7,featureId.length-7));<br>\
<br>\
      //### ポップアップで表示するテキストのセット ###<br>\
      document.getElementById(&#x27;popup_label&#x27;).innerHTML=pointData[i].text;<br>\
<br>\
      //### スクロール後の地図中心緯度経度の計算 ###<br>\
      // マーカーが画面中心から｢offsetPopupY｣ピクセル分下に表示することを前提に、中心緯度経度を計算。<br>\
      // 　①地図中心の緯度経度を取得<br>\
      // 　②画像中心のスクリーン座標から｢offsetPopupY｣ピクセル分オフセットした座標を緯度経度に変換<br>\
      // 　③①、②の結果から緯度方向の差分を計算<br>\
      // 　④該当マーカーの座標を取得<br>\
      // 　⑤④の座標から③の値分オフセットした緯度経度を計算<br>\
      var mapPoint0 = Mfapi.Map.getCenterPosition();<br>\
      var mapPoint1 = Mfapi.Map.getLonLatFromScreenPosition(new Mfapi.Util.ScreenPoint(mapX0,mapY0+mapOffsetY));<br>\
      var deltaLat = mapPoint1.lat - mapPoint0.lat;<br>\
      var markerPoint = Mfapi.Features.Marker[featureId].getPosition();<br>\
      var newMapPoint = new Mfapi.Util.LonLat(markerPoint.lon,markerPoint.lat-deltaLat);<br>\
<br>\
      //### 地図スクロールアニメ処理の呼び出し ###<br>\
      // アニメ処理が完了したら呼び出すコールバック関数として&quot;showPopup&quot;(ポップアップ表示処理)を指定。<br>\
      smoothMovePosition(newMapPoint,showPopup);<br>\
    }<br>\
<br>\
    //＊＊＊　各種汎用処理　＊＊＊<br>\
<br>\
    //### ポップアップ表示処理 ###<br>\
    function showPopup() {<br>\
      if( popupShow == false ) {<br>\
        document.getElementById(&#x27;popup_base&#x27;).style.visibility = &#x27;visible&#x27;;<br>\
        popupShow = true;<br>\
      }<br>\
    }<br>\
<br>\
    //### ポップアップ非表示処理 ###<br>\
    function hidePopup() {<br>\
      if( popupShow == true ) {<br>\
        document.getElementById(&#x27;popup_base&#x27;).style.visibility = &#x27;hidden&#x27;;<br>\
        popupShow = false;<br>\
      }<br>\
    }<br>\
<br>\
    //### 地図スクロールアニメ処理 ###<br>\
    // タイマー機能を使って、指定された緯度経度に少しずつ移動する機能。<br>\
    // この関数では補間点を計算して、タイマーで処理を繰り返す移動処理を呼び出す。<br>\
    function smoothMovePosition(newPos,callback) {<br>\
<br>\
      //### 現在の緯度経度を取得 ###<br>\
      var oldPos = Mfapi.Map.getCenterPosition();<br>\
<br>\
      //### 指定された緯度経度と現在の緯度経度との比較 ###<br>\
      // ピクセル単位で移動量がゼロの場合、指定されたコールバックを呼び出す。<br>\
      var newScreenPos = Mfapi.Map.getScreenPositionFromLonLat(newPos);<br>\
      var oldScreenPos = Mfapi.Map.getScreenPositionFromLonLat(oldPos);<br>\
      if( parseInt(newScreenPos.x) == parseInt(oldScreenPos.x)<br>\
       &amp;&amp; parseInt(newScreenPos.y) == parseInt(oldScreenPos.y) ) {<br>\
        callback();<br>\
      }<br>\
<br>\
      //### 補間点の計算 ###<br>\
      for( var i=0; i&lt;posArrayCount; i++) {<br>\
        posArray[i] = new Mfapi.Util.LonLat(<br>\
          oldPos.lon+(i+1)/posArrayCount*(newPos.lon-oldPos.lon),<br>\
          oldPos.lat+(i+1)/posArrayCount*(newPos.lat-oldPos.lat));<br>\
      }<br>\
<br>\
      //### コールバック関数を変数に格納 ###<br>\
      callbackForMovPos = callback;<br>\
<br>\
      //### 地図移動処理の呼び出し ###<br>\
      moveTimerFunc(0);<br>\
    }<br>\
<br>\
    //### 地図移動処理 ###<br>\
    function moveTimerFunc(index) {<br>\
<br>\
      //### 地図中心緯度経度の移動とインデックス更新 ###<br>\
      Mfapi.Map.setCenterPosition(posArray[index++]);<br>\
<br>\
      //### 移動処理が全て完了したら、指定されたコールバックを呼び出す ###<br>\
      if(index&gt;=posArray.length) {<br>\
        if( callbackForMovPos!= null )<br>\
          callbackForMovPos();<br>\
<br>\
      //### 移動処理が完了てなければ、再度タイマー処理で、本処理を呼び出す ###<br>\
      } else {<br>\
        var funcText = &quot;moveTimerFunc(&quot;+index+&quot;)&quot;;<br>\
        setTimeout(funcText, deltaTime);<br>\
      }<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;div id=&#x27;popup_base&#x27; onmousedown=&#x27;hidePopup();&#x27;&gt;<br>\
    &lt;div id=&#x27;popup&#x27;&gt;<br>\
      &lt;div&gt;&lt;img src=&#x27;img/d.png&#x27;&gt;&lt;/div&gt;<br>\
      &lt;div id=&#x27;popup_content&#x27;&gt;&lt;label id=&#x27;popup_label&#x27; class=&#x27;item1&#x27; /&gt;&lt;/div&gt;<br>\
    &lt;/div&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample14.html"
},

{
title: "15.マウス操作によるマーカー移動",
sum: "<p>マウス操作によるマーカー移動のサンプルコードが確認できます。</p>",
detail: "\
ドラッグ＆ドロップによる移動操作で、マーカーの座標を更新することができます。\
また、移動操作中、マーカーを画面の枠付近に移動すると、地図がスクロールするようになっています。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１５&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      position: absolute;<br>\
      left: 10px;<br>\
      top: 10px;<br>\
      width: 640px;<br>\
      height: 260px;<br>\
      margin: 0px;<br>\
    }<br>\
    #face_layer {<br>\
      position: absolute;<br>\
      top: 10px;<br>\
      left: 10px;<br>\
      width: 640px;<br>\
      height: 260px;<br>\
      margin: 0px;<br>\
      z-index: 5000001;<br>\
      display: none;<br>\
      background-color: #808080;<br>\
      opacity: 0.2;<br>\
      filter: alpha(opacity=20);<br>\
    }<br>\
    #moving_marker {<br>\
      position: absolute;<br>\
      z-index: 5000000;<br>\
      left: 0px;<br>\
      top: 0px;<br>\
      display: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１５．マウス操作によるマーカー移動 ＊＊＊<br>\
    // 処理フロー解説：<br>\
    //   ①地図のマーカーレイヤーに、全マーカーを登録。<br>\
    //   ②マーカーのクリックを検出したら、対象マーカーを地図のマーカーレイヤーから削除し、地図全体を<br>\
    //     覆う&quot;face_layer&quot;タグと移動中のマーカーを示す&quot;moving_marker&quot;タグを表示します。<br>\
    //   ③&quot;face_layer&quot;タグ上でマウスムーブイベントを検出したら、&quot;moving_marker&quot;タグを移動させます。<br>\
    //     このとき、地図画面枠付近にきたら、地図がスクロールする処理を有効にします。<br>\
    //   ④&quot;face_layer&quot;タグ上でマウスアップイベントを検出したら、&quot;face_layer&quot;タグと&quot;moving_marker&quot;タグ<br>\
    //     を非表示とした後、緯度経度を更新して、地図のマーカーレイヤーに再登録します。<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    //### 地点データ列セット ###<br>\
    var pointData = [<br>\
      { name: &#x27;東京駅&#x27;, lon: 139.7672311841094, lat: 35.68119593467379 },<br>\
      { name: &#x27;新橋駅&#x27;, lon: 139.75821002138233, lat: 35.66657238126213 },<br>\
      { name: &#x27;豊洲駅&#x27;, lon: 139.7959191978587, lat: 35.655211407306176 },<br>\
      { name: &#x27;有明駅&#x27;, lon: 139.79315890678254, lat: 35.63467955160454 },<br>\
      { name: &#x27;品川駅&#x27;, lon: 139.73875357500563, lat: 35.62850770123775 },<br>\
      { name: &#x27;渋谷駅&#x27;, lon: 139.70134957426947, lat: 35.65864567145413 },<br>\
      { name: &#x27;新宿駅&#x27;, lon: 139.70090283767686, lat: 35.68851826791775 }<br>\
    ];<br>\
<br>\
    //### マーカーに関する定義 ###<br>\
    var markerSizeX = 84, markerSizeY = 100;  // マーカー画像のサイズ<br>\
    var markerOffsetX = -43, markerOffsetY = -91;  // マーカー画像のオフセット<br>\
    var markerImageUrl = &#x27;./img/c.png&#x27;;  // マーカー画像のURL<br>\
<br>\
    //### マーカードラッグに関する共通変数 ###<br>\
    var dragFlag = false;  // ドラッグモードフラグ<br>\
    var dragOffsetX, dragOffsetY;  // ドラッグ開始時のマーカー上でのオフセット座標<br>\
    var dragObj = null;  // ドラッグ時に表示するDIVオブジェクト<br>\
    var faceLayerObj = null;  // フェイスレイヤーDIVオブジェクト(ドラッグ時に地図を覆う半透明のDIV)<br>\
    var prevPointerX, prevPointerY;  // カーソル座標の保存値<br>\
    var targetIndex = -1; // 移動対象のマーカーの識別番号(識別子の番号部分)<br>\
    var targetMarkerPos = null;  // 移動対象のマーカータップ時のスクリーン座標<br>\
<br>\
    //### マーカーの移動範囲および地図スクロールに関する定義 ###<br>\
    var mapWidth = 640, mapHeight = 260;  // 地図DIVタグのサイズ<br>\
    var pointerXMin = -markerOffsetX;  // ポインターX最小値<br>\
    var pointerXMax = mapWidth-1-markerSizeX-markerOffsetX;  // ポインターX最大値<br>\
    var pointerYMin = -markerOffsetY;  // ポインターY最小値<br>\
    var pointerYMax = mapHeight-1-markerSizeY-markerOffsetY;  // ポインターY最大値<br>\
    var mapScrollIntevalTime = 100;  // 地図スクロールの処理間隔（単位:ms）<br>\
    var mapScrollEdgeX = 0.1;  // スクロール枠水平方向の範囲定数(0.1ならば、画面の左右10%が枠部分となる)<br>\
    var mapScrollEdgeY = 0.1;  // スクロール枠垂直方向の範囲定数(0.1ならば、画面の上下10%が枠部分となる)<br>\
    var mapScrollDeltaX = 20;  // １回の処理での水平方向のスクロール量(単位:ピクセル)<br>\
    var mapScrollDeltaY = 20;  // １回の処理での垂直方向のスクロール量(単位:ピクセル)<br>\
<br>\
    //### 地図スクロールに関する共通変数 ###<br>\
    var mapScrollDx=0, mapScrollDy=0;  // スクロール移動方向(=-1/0/+1)<br>\
    var intervalId=null;  // タイマー処理のID<br>\
<br>\
    //＊＊＊　イニシャル処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth( &#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 認証後の各種イニシャル処理 ###<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        mapStyle : &#x27;rpg_pc&#x27;,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### マーカーレイヤー追加 ###<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### マーカー作成ループ処理 ###<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
<br>\
        //### マーカー追加処理呼び出し ###<br>\
        addMarker(i);<br>\
      }<br>\
<br>\
      //### マーカーポインタースタートのコールバック関数指定 ###<br>\
      Mfapi.Events.onMarkerPointerStart = markerPointerStart;<br>\
<br>\
      //### ドラッグ時のマーカー、フェイスレイヤーのDIVオブジェクト取得 ###<br>\
      faceLayerObj = document.getElementById(&#x27;face_layer&#x27;);<br>\
      dragObj = document.getElementById(&quot;moving_marker&quot;);<br>\
<br>\
      //### フェイスレイヤーDIVタグのイベント時に呼ぶ関数の指定 ###<br>\
      // ポインターイベントが使える場合はポインターイベントを、それ以外はマウスイベントを使う。<br>\
      if(navigator.msPointerEnabled) {<br>\
        faceLayerObj.onpointermove=faceLayerPointerMove;<br>\
        faceLayerObj.onpointerup=faceLayerPointerEnd;<br>\
      } else {<br>\
        faceLayerObj.onmousemove=faceLayerPointerMove;<br>\
        faceLayerObj.onmouseup=faceLayerPointerEnd;<br>\
      }<br>\
    }<br>\
<br>\
    //### マーカーポインタースタートイベント検出時の処理 ###<br>\
    function markerPointerStart(screenPosition,mapPosition,featureId,directAction,buttonType) {<br>\
<br>\
      //### 左ボタン以外の場合、本処理を実施しない ###<br>\
      if(buttonType!=&#x27;left&#x27;) return;<br>\
<br>\
      //### ドラッグモードフラグを有効にする ###<br>\
      dragFlag = true;<br>\
<br>\
      //### フェイスレイヤーを表示状態とする ###<br>\
      faceLayerObj.style.display=&#x27;block&#x27;;<br>\
<br>\
      //### 選択したマーカーの識別番号(識別子の数値部分)の抽出＆保存 ###<br>\
      targetIndex = parseInt(featureId.substr(7));<br>\
<br>\
      //### 選択したマーカーの緯度経度(ピンの先部分)を取得し、スクリーン座標に換算 ###<br>\
      targetMarkerPos = Mfapi.Map.getScreenPositionFromLonLat(Mfapi.Features.Marker[featureId].getPosition());<br>\
<br>\
      //### 選択したマーカーを、一旦、Mfapiのマーカーレイヤーから削除 ###<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].removeFeature(featureId);<br>\
<br>\
      //### ドラッグ中に表示するマーカー左上のスクリーン座標をセット ###<br>\
      dragObj.style.left = (targetMarkerPos.x +markerOffsetX +parseInt(faceLayerObj.offsetLeft)) +&#x27;px&#x27;;<br>\
      dragObj.style.top = (targetMarkerPos.y +markerOffsetY +parseInt(faceLayerObj.offsetTop)) +&#x27;px&#x27;;<br>\
<br>\
      //### ドラッグ中に表示するマーカーを表示状態とする ###<br>\
      dragObj.style.display=&#x27;block&#x27;;<br>\
<br>\
      //### マーカー左上座標とポインターのカーソル座標と差分を保存 ###<br>\
      dragOffsetX = screenPosition.x - targetMarkerPos.x;<br>\
      dragOffsetY = screenPosition.y - targetMarkerPos.y;<br>\
<br>\
      //### ポインターのカーソル座標を保存 ###<br>\
      prevPointerX = screenPosition.x;<br>\
      prevPointerY = screenPosition.y;<br>\
    }<br>\
<br>\
    //### フェイスレイヤー　ポインタームーブ(マウスムーブ)検出時の処理 ###<br>\
    function faceLayerPointerMove(objEvent) {<br>\
<br>\
      //### Internet Explorer対応(イベント情報がwindow.eventで渡される場合を考慮) ###<br>\
      objEvent = objEvent || window.event;<br>\
<br>\
      //### ドラッグモードフラグ無効時の処理(例外対応) ###<br>\
      if(!dragFlag) {<br>\
        stopMapScroll();<br>\
        return false;<br>\
      }<br>\
<br>\
      //### ポインターのカーソル座標を計算 ###<br>\
      var pointerX = calcPointerX(objEvent);<br>\
      var pointerY = calcPointerY(objEvent);<br>\
<br>\
      //### ドラッグ中に表示するマーカー左上のスクリーン座標をセット ###<br>\
      var dragObjX = parseInt(dragObj.offsetLeft) + pointerX - prevPointerX;<br>\
      var dragObjY = parseInt(dragObj.offsetTop) + pointerY - prevPointerY;<br>\
      dragObj.style.left = dragObjX + &quot;px&quot;;<br>\
      dragObj.style.top = dragObjY + &quot;px&quot;;<br>\
<br>\
      //### 地図スクロール制御処理を呼ぶ ###<br>\
      mapScrollCtrl(dragObjX,dragObjY);<br>\
<br>\
      //### ポインターのカーソル座標を保存 ###<br>\
      prevPointerX = pointerX;<br>\
      prevPointerY = pointerY;<br>\
<br>\
      return false;<br>\
    }<br>\
<br>\
    //### フェイスレイヤー　ポインターエンド(マウスアップ)検出時の処理 ###<br>\
    function faceLayerPointerEnd(objEvent){<br>\
<br>\
      //### Internet Explorer対応(イベント情報がwindow.eventで渡される場合を考慮) ###<br>\
      objEvent = objEvent || window.event;<br>\
<br>\
      //### ドラッグモードフラグ無効時の処理(例外対応) ###<br>\
      if(!dragFlag) {<br>\
        stopMapScroll();<br>\
        return false;<br>\
      }<br>\
<br>\
      //### ポインターのカーソル座標を計算 ###<br>\
      var pointerX = calcPointerX(objEvent);<br>\
      var pointerY = calcPointerY(objEvent);<br>\
<br>\
      //### フェイスレイヤーを非表示状態とする ###<br>\
      faceLayerObj.style.display=&#x27;none&#x27;;<br>\
<br>\
      //### ドラッグ中に表示するマーカーを非表示状態とする ###<br>\
      dragObj.style.display=&#x27;none&#x27;;<br>\
<br>\
      //### マーカーの緯度経度(ピンの先部分)を計算し、地点データを更新 ###<br>\
      var markerScreenPos = new Mfapi.Util.ScreenPoint( pointerX-dragOffsetX, pointerY-dragOffsetY );<br>\
      var markerMapPos = Mfapi.Map.getLonLatFromScreenPosition( markerScreenPos );<br>\
      pointData[targetIndex].lon = markerMapPos.lon;<br>\
      pointData[targetIndex].lat = markerMapPos.lat;<br>\
<br>\
      //### マーカー追加処理呼び出し ###<br>\
      addMarker(targetIndex);<br>\
<br>\
      //### 地図スクロールを停止 ###<br>\
      stopMapScroll();<br>\
<br>\
      //### ドラッグモードフラグを無効にする ###<br>\
      dragFlag = false;<br>\
<br>\
      return false;<br>\
    }<br>\
<br>\
    //＊＊＊　各種汎用処理　＊＊＊<br>\
<br>\
    //### 地図スクロール制御処理 ###<br>\
    // ドラッグしているマーカーが地図の｢枠｣付近にいる場合、地図をスクロールさせる機能。<br>\
    // 枠付近と判断した場合、スクロール方向をmapScrollDx,mapScrollDyにセット。<br>\
    // mapScrollDx,mapScrollDyがゼロでない場合、タイマーでスクロール処理を繰り返す。<br>\
    function mapScrollCtrl(dragObjX,dragObjY) {<br>\
<br>\
      //### 水平方向のスクロール判定 ###<br>\
      if( dragObjX &lt; mapWidth * mapScrollEdgeX ) mapScrollDx = -1;<br>\
      else if( dragObjX +markerSizeX &gt; mapWidth *(1-mapScrollEdgeX)) mapScrollDx = +1;<br>\
      else mapScrollDx = 0;<br>\
<br>\
      //### 垂直方向のスクロール判定 ###<br>\
      if( dragObjY &lt; mapHeight * mapScrollEdgeY ) mapScrollDy = -1;<br>\
      else if( dragObjY +markerSizeY &gt; mapHeight *(1-mapScrollEdgeY)) mapScrollDy = +1;<br>\
      else mapScrollDy = 0;<br>\
<br>\
      //### スクロールさせる場合 ###<br>\
      if( mapScrollDx!=0 || mapScrollDy!=0 ) {<br>\
<br>\
        //### スクロールのタイマー処理 ###<br>\
        if(intervalId==null) {<br>\
          intervalId = window.setInterval( function () {<br>\
            var center = new Mfapi.Util.ScreenPoint( <br>\
              mapWidth/2+mapScrollDx*mapScrollDeltaX, mapHeight/2+mapScrollDy*mapScrollDeltaY );<br>\
            Mfapi.Map.setCenterPosition( Mfapi.Map.getLonLatFromScreenPosition(center) );<br>\
          }, mapScrollIntevalTime );<br>\
        }<br>\
<br>\
      //### スクロールさせない場合 ###<br>\
      } else {<br>\
        stopMapScroll();<br>\
      }<br>\
    }<br>\
<br>\
    //### 地図スクロール停止処理 ###<br>\
    function stopMapScroll() {<br>\
      //### タイマー処理を無効化 ###<br>\
      if(intervalId!=null) {<br>\
        window.clearInterval(intervalId);<br>\
        intervalId = null;<br>\
      }<br>\
      //### スクロール方向の変数をリセット ###<br>\
      mapScrollDx=0;<br>\
      mapScrollDy=0;<br>\
    }<br>\
<br>\
    //### ポインタースクリーン座標Xの計算 ###<br>\
    function calcPointerX(objEvent) {<br>\
<br>\
      //### イベント情報から座標を計算 ###<br>\
      var pointerX = parseInt(objEvent.clientX)-parseInt(faceLayerObj.offsetLeft);<br>\
<br>\
      //### 地図の範囲外の場合、最小値または最大値をセット ###<br>\
      if( pointerX &lt;= pointerXMin+dragOffsetX ) pointerX = pointerXMin+dragOffsetX;<br>\
      if( pointerX &gt;= pointerXMax+dragOffsetX ) pointerX = pointerXMax+dragOffsetX;<br>\
      <br>\
      return pointerX;<br>\
    }<br>\
<br>\
    function calcPointerY(objEvent) {<br>\
<br>\
      //### イベント情報から座標を計算 ###<br>\
      var pointerY = parseInt(objEvent.clientY)-parseInt(faceLayerObj.offsetTop);<br>\
<br>\
      //### 地図の範囲外の場合、最小値または最大値をセット ###<br>\
      if( pointerY &lt;= pointerYMin+dragOffsetY ) pointerY = pointerYMin+dragOffsetY;<br>\
      if( pointerY &gt;= pointerYMax+dragOffsetY ) pointerY = pointerYMax+dragOffsetY;<br>\
      <br>\
      return pointerY;<br>\
    }<br>\
<br>\
    //### マーカー追加処理 ###<br>\
    function addMarker(index) {<br>\
<br>\
      //### マーカー　フィーチャー識別子作成および条件セット ###<br>\
      var id = &#x27;marker#&#x27;+index;<br>\
      var opt = {<br>\
        position : new Mfapi.Util.LonLat(pointData[index].lon, pointData[index].lat),<br>\
        imageUrl : markerImageUrl,<br>\
        imageSize : new Mfapi.Util.ScreenSize(markerSizeX, markerSizeY),<br>\
        imageOffset : new Mfapi.Util.ScreenPoint(markerOffsetX, markerOffsetY),<br>\
        imageOpacity : 0.7<br>\
      };<br>\
<br>\
      //### マーカー作成＆レイヤー追加 ###<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt, id);<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;face_layer&#x27;&gt;&lt;/div&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;img src=&#x27;img/c.png&#x27; id=&#x27;moving_marker&#x27; ondragstart=&quot;return false&quot;&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample15.html"
},

{
title: "16.タッチ操作によるマーカー移動",
sum: "<p>タッチ操作によるマーカー移動のサンプルコードが確認できます。</p>",
detail: "\
iOS/Android OSのスマートフォンおよびタブレットにて、マーカーをタップして対象の透明度が\
変わったことを確認後、再びタッチ＆スライドする操作によりマーカーの座標を更新することができます。\
また、移動操作中、マーカーを画面の枠付近に移動すると、地図がスクロールするようになっています。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１６&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    body, html {<br>\
      overflow: hidden;<br>\
      height: 100%;<br>\
    }<br>\
    #sample_map {<br>\
      position: absolute;<br>\
      left: 10px;<br>\
      top: 10px;<br>\
      width: 640px;<br>\
      height: 260px;<br>\
      margin: 0px;<br>\
    }<br>\
    #face_layer {<br>\
      position: absolute;<br>\
      top: 10px;<br>\
      left: 10px;<br>\
      width: 640px;<br>\
      height: 260px;<br>\
      margin: 0px;<br>\
      z-index: 5000001;<br>\
      display: none;<br>\
      background-color: #808080;<br>\
      opacity: 0.2;<br>\
      filter: alpha(opacity=20);<br>\
      -webkit-touch-callout:none;<br>\
      -webkit-user-select:none;<br>\
    }<br>\
    #moving_marker {<br>\
      position: absolute;<br>\
      z-index: 5000000;<br>\
      left: 0px;<br>\
      top: 0px;<br>\
      display: none;<br>\
      -webkit-touch-callout:none;<br>\
      -webkit-user-select:none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１６．タッチ操作によるマーカー移動 ＊＊＊<br>\
    // 処理フロー解説：<br>\
    //   ①地図のマーカーレイヤーに、全マーカーを登録。<br>\
    //   ②マーカーのタップを検出したら、対象マーカーを地図のマーカーレイヤーから削除し、地図全体を覆う<br>\
    //     &quot;face_layer&quot;タグと移動中のマーカーを示す&quot;moving_marker&quot;タグを表示します。<br>\
    //   ③&quot;face_layer&quot;タグ上でタッチスタートイベントを検出し、それが&quot;moving_marker&quot;タグの表示範囲外の<br>\
    //     場合、&quot;face_layer&quot;タグと&quot;moving_marker&quot;タグを非表示として、緯度経度を更新して、地図のマー<br>\
    //     カーレイヤーに同じ位置で再登録します。<br>\
    //   ④&quot;face_layer&quot;タグ上でタッチムーブイベントを検出したら、&quot;moving_marker&quot;タグを移動させます。<br>\
    //     このとき、地図画面枠付近にきたら、地図がスクロールする処理を有効にします。<br>\
    //   ⑤&quot;face_layer&quot;タグ上でタッチエンドイベントを検出したら、&quot;face_layer&quot;タグと&quot;moving_marker&quot;タグ<br>\
    //     を非表示とした後、緯度経度を更新して、地図のマーカーレイヤーに再登録します。<br>\
<br>\
    //＊＊＊　共通変数の宣言　＊＊＊<br>\
<br>\
    //### 地点データ列セット ###<br>\
    var pointData = [<br>\
      { name: &#x27;東京駅&#x27;, lon: 139.7672311841094, lat: 35.68119593467379 },<br>\
      { name: &#x27;新橋駅&#x27;, lon: 139.75821002138233, lat: 35.66657238126213 },<br>\
      { name: &#x27;豊洲駅&#x27;, lon: 139.7959191978587, lat: 35.655211407306176 },<br>\
      { name: &#x27;有明駅&#x27;, lon: 139.79315890678254, lat: 35.63467955160454 },<br>\
      { name: &#x27;品川駅&#x27;, lon: 139.73875357500563, lat: 35.62850770123775 },<br>\
      { name: &#x27;渋谷駅&#x27;, lon: 139.70134957426947, lat: 35.65864567145413 },<br>\
      { name: &#x27;新宿駅&#x27;, lon: 139.70090283767686, lat: 35.68851826791775 }<br>\
    ];<br>\
<br>\
    //### マーカーに関する定義 ###<br>\
    var markerSizeX = 84, markerSizeY = 100;  // マーカー画像のサイズ<br>\
    var markerOffsetX = -43, markerOffsetY = -91;  // マーカー画像のオフセット<br>\
    var markerImageUrl = &#x27;./img/c.png&#x27;;  // マーカー画像のURL<br>\
<br>\
    //### マーカードラッグに関する共通変数 ###<br>\
    var dragFlag = false;  // ドラッグモードフラグ<br>\
    var dragOffsetX, dragOffsetY;  // ドラッグ開始時のマーカー上でのオフセット座標<br>\
    var dragObj = null;  // ドラッグ時に表示するDIVオブジェクト<br>\
    var faceLayerObj = null;  // フェイスレイヤーDIVオブジェクト(ドラッグ時に地図を覆う半透明のDIV)<br>\
    var prevPointerX, prevPointerY;  // カーソル座標の保存値<br>\
    var targetIndex = 0; // 移動対象のマーカーの識別番号(識別子の番号部分)<br>\
    var targetMarkerPos = null;  // 移動対象のマーカータップ時のスクリーン座標<br>\
<br>\
    //### マーカーの移動範囲および地図スクロールに関する定義 ###<br>\
    var mapWidth = 640, mapHeight = 260;  // 地図DIVタグのサイズ<br>\
    var pointerXMin = -markerOffsetX;  // ポインターX最小値<br>\
    var pointerXMax = mapWidth-1-markerSizeX-markerOffsetX;  // ポインターX最大値<br>\
    var pointerYMin = -markerOffsetY;  // ポインターY最小値<br>\
    var pointerYMax = mapHeight-1-markerSizeY-markerOffsetY;  // ポインターY最大値<br>\
    var mapScrollIntevalTime = 100;  // 地図スクロールの処理間隔（単位:ms）<br>\
    var mapScrollEdgeX = 0.1;  // スクロール枠水平方向の範囲定数(0.1ならば、画面の左右10%が枠部分となる)<br>\
    var mapScrollEdgeY = 0.1;  // スクロール枠垂直方向の範囲定数(0.1ならば、画面の上下10%が枠部分となる)<br>\
    var mapScrollDeltaX = 20;  // １回の処理での水平方向のスクロール量(単位:ピクセル)<br>\
    var mapScrollDeltaY = 20;  // １回の処理での垂直方向のスクロール量(単位:ピクセル)<br>\
<br>\
    //### 地図スクロールに関する共通変数 ###<br>\
    var mapScrollDx=0, mapScrollDy=0;  // スクロール移動方向(=-1/0/+1)<br>\
    var intervalId=null;  // タイマー処理のID<br>\
<br>\
    //＊＊＊　イニシャル処理　＊＊＊<br>\
<br>\
    //--- 認証処理とパス設定：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth( &#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //### 認証後の各種イニシャル処理 ###<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
      var options = {<br>\
        mapStyle : &#x27;rpg_pc&#x27;,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### マーカーレイヤー追加 ###<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### マーカー作成ループ処理 ###<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
<br>\
        //### マーカー追加処理呼び出し ###<br>\
        addMarker(i);<br>\
      }<br>\
<br>\
      //### マーカーポインタースタートのコールバック関数指定 ###<br>\
      Mfapi.Events.onMarkerPointerStart = markerPointerStart;<br>\
<br>\
      //### ドラッグ時のマーカー、フェイスレイヤーのDIVオブジェクト取得 ###<br>\
      faceLayerObj = document.getElementById(&#x27;face_layer&#x27;);<br>\
      dragObj = document.getElementById(&quot;moving_marker&quot;);<br>\
<br>\
      //### フェイスレイヤーDIVタグのイベント時に呼ぶ関数の指定 ###<br>\
      faceLayerObj.ontouchstart=faceLayerPointerStart;<br>\
      faceLayerObj.ontouchmove=faceLayerPointerMove;<br>\
      faceLayerObj.ontouchend=faceLayerPointerEnd;<br>\
    }<br>\
<br>\
    //### マーカーポインタースタートイベント検出時の処理 ###<br>\
    function markerPointerStart(screenPosition,mapPosition,featureId,directAction,buttonType) {<br>\
<br>\
      //### フェイスレイヤーを表示状態とする ###<br>\
      faceLayerObj.style.display=&#x27;block&#x27;;<br>\
<br>\
      //### 選択したマーカーの識別番号(識別子の数値部分)の抽出＆保存 ###<br>\
      targetIndex = parseInt(featureId.substr(7));<br>\
<br>\
      //### 選択したマーカーの緯度経度(ピンの先部分)を取得し、スクリーン座標に換算 ###<br>\
      targetMarkerPos = Mfapi.Map.getScreenPositionFromLonLat(Mfapi.Features.Marker[featureId].getPosition());<br>\
<br>\
      //### 選択したマーカーを、一旦、Mfapiのマーカーレイヤーから削除 ###<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].removeFeature(featureId);<br>\
<br>\
      //### ドラッグ中に表示するマーカー左上のスクリーン座標をセット ###<br>\
      dragObj.style.left = (targetMarkerPos.x +markerOffsetX +parseInt(faceLayerObj.offsetLeft)) +&#x27;px&#x27;;<br>\
      dragObj.style.top = (targetMarkerPos.y +markerOffsetY +parseInt(faceLayerObj.offsetTop)) +&#x27;px&#x27;;<br>\
<br>\
      //### ドラッグ中に表示するマーカーを表示状態とする ###<br>\
      dragObj.style.display=&#x27;block&#x27;;<br>\
    }<br>\
<br>\
    //### フェイスレイヤー　ポインタースタート(タッチスタート)検出時の処理 ###<br>\
    function faceLayerPointerStart(objEvent) {<br>\
<br>\
      //### タッチイベント取得 ###<br>\
      if(objEvent.changedTouches!==undefined &amp;&amp; objEvent.changedTouches.length&gt;=1)<br>\
        objEvent=objEvent.changedTouches.item(0);<br>\
      else if(objEvent.touches!==undefined &amp;&amp; objEvent.touches.length&gt;=1)<br>\
        objEvent=objEvent.touches.item(0);<br>\
      else<br>\
        return false;<br>\
<br>\
      if(dragFlag==false) {<br>\
        //### ポインターの座標情報の取得 ###<br>\
        var pointerX = parseInt(objEvent.clientX)-parseInt(faceLayerObj.offsetLeft);<br>\
        var pointerY = parseInt(objEvent.clientY)-parseInt(faceLayerObj.offsetTop);<br>\
<br>\
        //### マーカーの座標範囲の計算 ###<br>\
        var markerXmin = parseInt(dragObj.style.left)-parseInt(faceLayerObj.offsetLeft);<br>\
        var markerYmin = parseInt(dragObj.style.top)-parseInt(faceLayerObj.offsetTop);<br>\
        var markerXmax = markerXmin + markerSizeX -1;<br>\
        var markerYmax = markerYmin + markerSizeX -1;<br>\
<br>\
        //### マーカー内のタップでの処理 ###<br>\
        if(pointerX&gt;=markerXmin &amp;&amp; pointerX&lt;=markerXmax &amp;&amp; pointerY&gt;=markerYmin &amp;&amp; pointerY&lt;=markerYmax ) {<br>\
<br>\
          //### ドラッグモードフラグを有効にする ###<br>\
          dragFlag = true;<br>\
<br>\
          //### マーカー左上座標とポインターのカーソル座標と差分を保存 ###<br>\
          dragOffsetX = pointerX - targetMarkerPos.x;<br>\
          dragOffsetY = pointerY - targetMarkerPos.y;<br>\
<br>\
          //### ポインターのカーソル座標を保存 ###<br>\
          prevPointerX = pointerX;<br>\
          prevPointerY = pointerY;<br>\
<br>\
        //### マーカー内のタップ以外の処理：元に戻す ###<br>\
        } else {<br>\
<br>\
          //### フェイスレイヤーを非表示状態とする ###<br>\
          faceLayerObj.style.display=&#x27;none&#x27;;<br>\
<br>\
          //### ドラッグ中に表示するマーカーを非表示状態とする ###<br>\
          dragObj.style.display=&#x27;none&#x27;;<br>\
<br>\
          //### マーカー追加処理呼び出し ###<br>\
          addMarker(targetIndex);<br>\
        }<br>\
      }<br>\
      return false;<br>\
    }<br>\
<br>\
    //### フェイスレイヤー　ポインタームーブ(タッチムーブ)検出時の処理 ###<br>\
    function faceLayerPointerMove(objEvent) {<br>\
<br>\
      //### タッチイベント取得 ###<br>\
      if(objEvent.changedTouches!==undefined &amp;&amp; objEvent.changedTouches.length&gt;=1)<br>\
        objEvent=objEvent.changedTouches.item(0);<br>\
      else if(objEvent.touches!==undefined &amp;&amp; objEvent.touches.length&gt;=1)<br>\
        objEvent=objEvent.touches.item(0);<br>\
      else<br>\
        return false;<br>\
<br>\
      //### ドラッグモードフラグ無効時の処理(例外対応) ###<br>\
      if(!dragFlag) {<br>\
        stopMapScroll();<br>\
        return false;<br>\
      }<br>\
<br>\
      //### ポインターのカーソル座標を計算 ###<br>\
      var pointerX = calcPointerX(objEvent);<br>\
      var pointerY = calcPointerY(objEvent);<br>\
<br>\
      //### ドラッグ中に表示するマーカー左上のスクリーン座標をセット ###<br>\
      var dragObjX = parseInt(dragObj.offsetLeft) + pointerX - prevPointerX;<br>\
      var dragObjY = parseInt(dragObj.offsetTop) + pointerY - prevPointerY;<br>\
      dragObj.style.left = dragObjX + &quot;px&quot;;<br>\
      dragObj.style.top = dragObjY + &quot;px&quot;;<br>\
<br>\
      //### 地図スクロール制御処理を呼ぶ ###<br>\
      mapScrollCtrl(dragObjX,dragObjY);<br>\
<br>\
      //### ポインターのカーソル座標を保存 ###<br>\
      prevPointerX = pointerX;<br>\
      prevPointerY = pointerY;<br>\
<br>\
      return false;<br>\
    }<br>\
<br>\
    //### フェイスレイヤー　ポインターエンド(タッチエンドアップ)検出時の処理 ###<br>\
    function faceLayerPointerEnd(objEvent){<br>\
<br>\
      //### タッチイベント取得 ###<br>\
      if(objEvent.changedTouches!==undefined &amp;&amp; objEvent.changedTouches.length&gt;=1)<br>\
        objEvent=objEvent.changedTouches.item(0);<br>\
      else if(objEvent.touches!==undefined &amp;&amp; objEvent.touches.length&gt;=1)<br>\
        objEvent=objEvent.touches.item(0);<br>\
      else<br>\
        return false;<br>\
<br>\
      //### ドラッグモードフラグ無効時の処理(例外対応) ###<br>\
      if(!dragFlag) {<br>\
        stopMapScroll();<br>\
        return false;<br>\
      }<br>\
<br>\
      //### ポインターのカーソル座標を計算 ###<br>\
      var pointerX = calcPointerX(objEvent);<br>\
      var pointerY = calcPointerY(objEvent);<br>\
<br>\
      //### フェイスレイヤーを非表示状態とする ###<br>\
      faceLayerObj.style.display=&#x27;none&#x27;;<br>\
<br>\
      //### ドラッグ中に表示するマーカーを非表示状態とする ###<br>\
      dragObj.style.display=&#x27;none&#x27;;<br>\
<br>\
      //### マーカーの緯度経度(ピンの先部分)を計算し、地点データを更新 ###<br>\
      var markerScreenPos = new Mfapi.Util.ScreenPoint( pointerX-dragOffsetX, pointerY-dragOffsetY );<br>\
      var markerMapPos = Mfapi.Map.getLonLatFromScreenPosition( markerScreenPos );<br>\
      pointData[targetIndex].lon = markerMapPos.lon;<br>\
      pointData[targetIndex].lat = markerMapPos.lat;<br>\
<br>\
      //### マーカー追加処理呼び出し ###<br>\
      addMarker(targetIndex);<br>\
<br>\
      //### 地図スクロールを停止 ###<br>\
      stopMapScroll();<br>\
<br>\
      //### ドラッグモードフラグを無効にする ###<br>\
      dragFlag = false;<br>\
<br>\
      return false;<br>\
    }<br>\
<br>\
    //＊＊＊　各種汎用処理　＊＊＊<br>\
<br>\
    //### 地図スクロール制御処理 ###<br>\
    // ドラッグしているマーカーが地図の｢枠｣付近にいる場合、地図をスクロールさせる機能。<br>\
    // 枠付近と判断した場合、スクロール方向をmapScrollDx,mapScrollDyにセット。<br>\
    // mapScrollDx,mapScrollDyがゼロでない場合、タイマーでスクロール処理を繰り返す。<br>\
    function mapScrollCtrl(dragObjX,dragObjY) {<br>\
<br>\
      //### 水平方向のスクロール判定 ###<br>\
      if( dragObjX &lt; mapWidth * mapScrollEdgeX ) mapScrollDx = -1;<br>\
      else if( dragObjX +markerSizeX &gt; mapWidth *(1-mapScrollEdgeX)) mapScrollDx = +1;<br>\
      else mapScrollDx = 0;<br>\
<br>\
      //### 垂直方向のスクロール判定 ###<br>\
      if( dragObjY &lt; mapHeight * mapScrollEdgeY ) mapScrollDy = -1;<br>\
      else if( dragObjY +markerSizeY &gt; mapHeight *(1-mapScrollEdgeY)) mapScrollDy = +1;<br>\
      else mapScrollDy = 0;<br>\
<br>\
      //### スクロールさせる場合 ###<br>\
      if( mapScrollDx!=0 || mapScrollDy!=0 ) {<br>\
<br>\
        //### スクロールのタイマー処理 ###<br>\
        if(intervalId==null) {<br>\
          intervalId = window.setInterval( function () {<br>\
            var center = new Mfapi.Util.ScreenPoint( <br>\
              mapWidth/2+mapScrollDx*mapScrollDeltaX, mapHeight/2+mapScrollDy*mapScrollDeltaY );<br>\
            Mfapi.Map.setCenterPosition( Mfapi.Map.getLonLatFromScreenPosition(center) );<br>\
          }, mapScrollIntevalTime );<br>\
        }<br>\
<br>\
      //### スクロールさせない場合 ###<br>\
      } else {<br>\
        stopMapScroll();<br>\
      }<br>\
    }<br>\
<br>\
    //### 地図スクロール停止処理 ###<br>\
    function stopMapScroll() {<br>\
      //### タイマー処理を無効化 ###<br>\
      if(intervalId!=null) {<br>\
        window.clearInterval(intervalId);<br>\
        intervalId = null;<br>\
      }<br>\
      //### スクロール方向の変数をリセット ###<br>\
      mapScrollDx=0;<br>\
      mapScrollDy=0;<br>\
    }<br>\
<br>\
    //### ポインタースクリーン座標Xの計算 ###<br>\
    function calcPointerX(objEvent) {<br>\
<br>\
      //### イベント情報から座標を計算 ###<br>\
      var pointerX = parseInt(objEvent.clientX)-parseInt(faceLayerObj.offsetLeft);<br>\
<br>\
      //### 地図の範囲外の場合、最小値または最大値をセット ###<br>\
      if( pointerX &lt;= pointerXMin+dragOffsetX ) pointerX = pointerXMin+dragOffsetX;<br>\
      if( pointerX &gt;= pointerXMax+dragOffsetX ) pointerX = pointerXMax+dragOffsetX;<br>\
      <br>\
      return pointerX;<br>\
    }<br>\
<br>\
    function calcPointerY(objEvent) {<br>\
<br>\
      //### イベント情報から座標を計算 ###<br>\
      var pointerY = parseInt(objEvent.clientY)-parseInt(faceLayerObj.offsetTop);<br>\
<br>\
      //### 地図の範囲外の場合、最小値または最大値をセット ###<br>\
      if( pointerY &lt;= pointerYMin+dragOffsetY ) pointerY = pointerYMin+dragOffsetY;<br>\
      if( pointerY &gt;= pointerYMax+dragOffsetY ) pointerY = pointerYMax+dragOffsetY;<br>\
      <br>\
      return pointerY;<br>\
    }<br>\
<br>\
    //### マーカー追加処理 ###<br>\
    function addMarker(index) {<br>\
<br>\
      //### マーカー　フィーチャー識別子作成および条件セット ###<br>\
      var id = &#x27;marker#&#x27;+index;<br>\
      var opt = {<br>\
        position : new Mfapi.Util.LonLat(pointData[index].lon, pointData[index].lat),<br>\
        imageUrl : markerImageUrl,<br>\
        imageSize : new Mfapi.Util.ScreenSize(markerSizeX, markerSizeY),<br>\
        imageOffset : new Mfapi.Util.ScreenPoint(markerOffsetX, markerOffsetY),<br>\
        imageOpacity : 0.7<br>\
      };<br>\
<br>\
      //### マーカー作成＆レイヤー追加 ###<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt, id);<br>\
    }<br>\
<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;face_layer&#x27;&gt;&lt;/div&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;img src=&#x27;img/c.png&#x27; id=&#x27;moving_marker&#x27; ondragstart=&quot;return false&quot;&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;\
</pre>",
url: "./src/MfapiSample16.html"
},

{
title: "17.「おもてなしマップ」推奨設定",
sum: "<p>観光案内向け地図デザイン「おもてなしマップ」を表示するコードが確認できます。</p>",
detail: "\
本サンプルでは、カラーユニバーサルデザインに配慮した推奨設定を使用して、地図表示/マーカー表示/ルート描画を行うコードが確認できます。<br>\
「おもてなしマップ」および推奨設定の詳細は、別紙「MapFanAPI_おもてなしマップご利用案内」をご覧ください。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１７&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
    &lt;!--地図中心を示すパーツのアイコン画像とDIVのスタイル--&gt;<br>\
    #center_image {<br>\
      width: 34px;<br>\
      height: 30px;<br>\
    }<br>\
    #center_div {<br>\
      position: absolute;<br>\
      z-index: 5000000;<br>\
      left: 321px;<br>\
      top: 133px;<br>\
      pointer-events: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１７．「おもてなしマップ」の表示 ＊＊＊<br>\
<br>\
    //＊＊＊ イニシャル処理 ＊＊＊<br>\
    //--- 認証処理とパス設定：サンプル９参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.routeHost = &#x27;api-route-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // &quot;mapstyle&quot;は地図表示スタイルを指定するプロパティです。<br>\
      // &quot;mapstyle&quot;にカラーユニバーサルデザインに対応した設定値「&#x27;tourism_pc&#x27;」を設定します。<br>\
      // 詳細は別紙「地図デザイン設定方法と表示イメージ」の仕様をご参照下さい。<br>\
      var options = {<br>\
        mapStyle       : &#x27;tourism_pc&#x27;,<br>\
        logoSettings   : &#x27;off&#x27;,<br>\
        lang           : &#x27;ja&#x27;,<br>\
        centerPosition : new Mfapi.Util.LonLat(139.69782652169118,35.69313060143928),<br>\
        mapScale       : 16<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //--- ジオメトリーレイヤー、図形追加：サンプル２参照 ---<br>\
      Mfapi.Map.addGeometryLayer(&#x27;gLayer&#x27;);<br>\
<br>\
      //### サークル　条件セット ###<br>\
      // &quot;edgeColor&quot;はサークルの枠線の色を指定するプロパティです。<br>\
      // &quot;edgeColor&quot;にカラーユニバーサルデザインに対応した設定値「#606060：グレー」を設定します。<br>\
      // &quot;fillColor&quot;はサークルの塗り色を指定するプロパティです。<br>\
      // &quot;fillColor&quot;にカラーユニバーサルデザインに対応した設定値「#777777：グレー」を設定します。<br>\
      // 詳細は別紙「MapFanAPI_おもてなしマップご利用案内」の仕様をご参照下さい。<br>\
      var circleOptions = {<br>\
        edgeColor : &#x27;#606060&#x27;, // 枠線の色<br>\
        edgeWidth : &#x27;2&#x27;, // 枠線の幅<br>\
        fillColor : &#x27;#777777&#x27;, // 塗り色<br>\
        opacity   : &#x27;0.5&#x27;, // 不透明度<br>\
        position  : new Mfapi.Util.LonLat(139.69183625107152,35.69215748858982),<br>\
        radius    : 120, // 半径<br>\
        visible   : true // 表示状態<br>\
      };<br>\
<br>\
      //### ポリライン　条件セット ###<br>\
      // &quot;lineColor&quot;はポリラインの線の色を指定するプロパティです。<br>\
      // &quot;lineColor&quot;にカラーユニバーサルデザインに対応した設定値「#000000：黒」を設定します。<br>\
      // 詳細は別紙「MapFanAPI_おもてなしマップご利用案内」の仕様をご参照下さい。<br>\
      var polylineOptions = {<br>\
        lineColor : &#x27;#000000&#x27;, // 線の色<br>\
        lineWidth : &#x27;2&#x27;, // 線の幅<br>\
        opacity   : 1, // 不透明度<br>\
        positions : [  <br>\
                       new Mfapi.Util.LonLat(139.6933848251336,35.69130359092341),<br>\
                       new Mfapi.Util.LonLat(139.6933848251336,35.69301138625623),<br>\
                       new Mfapi.Util.LonLat(139.69443625107152,35.69215748858982),<br>\
                       new Mfapi.Util.LonLat(139.69548767700945,35.69301138625623),<br>\
                       new Mfapi.Util.LonLat(139.69548767700945,35.69130359092341)<br>\
                    ],<br>\
        visible   : true // 表示状態<br>\
      };<br>\
<br>\
      //### ポリゴン　条件セット ###<br>\
      // &quot;edgeColor&quot;はポリゴンの枠線の色を指定するプロパティです。<br>\
      // &quot;edgeColor&quot;にカラーユニバーサルデザインに対応した設定値「#606060：グレー」を設定します。<br>\
      // &quot;fillColor&quot;はポリゴンの塗り色を指定するプロパティです。<br>\
      // &quot;fillColor&quot;にカラーユニバーサルデザインに対応した設定値「#777777：グレー」を設定します。<br>\
      // 詳細は別紙「MapFanAPI_おもてなしマップご利用案内」の仕様をご参照下さい。<br>\
      var polygonOptions = {<br>\
        edgeColor : &#x27;#606060&#x27;, // 枠線の色<br>\
        edgeWidth : &#x27;2&#x27;, // 枠線の幅<br>\
        fillColor : &#x27;#777777&#x27;, // 塗り色<br>\
        opacity   : 0.5, // 不透明度<br>\
        positions : [  <br>\
                       new Mfapi.Util.LonLat(139.69703625107152,35.69301138625623),<br>\
                       new Mfapi.Util.LonLat(139.69794681264398,35.69258443742302),<br>\
                       new Mfapi.Util.LonLat(139.69794681264398,35.69173053975662),<br>\
                       new Mfapi.Util.LonLat(139.69703625107152,35.69130359092341),<br>\
                       new Mfapi.Util.LonLat(139.69612568949907,35.69173053975662),<br>\
                       new Mfapi.Util.LonLat(139.69612568949907,35.69258443742302),<br>\
                       new Mfapi.Util.LonLat(139.69703625107152,35.69301138625623)<br>\
                    ],<br>\
        visible   : true // 表示状態<br>\
      };<br>\
<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addCircle(circleOptions, &#x27;circle#1&#x27;);<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolyline(polylineOptions, &#x27;polyline#1&#x27;);<br>\
      Mfapi.Map.GeometryLayer[&#x27;gLayer&#x27;].addPolygon(polygonOptions, &#x27;polygon#1&#x27;);<br>\
<br>\
      //--- ルート：サンプル９参照 ---<br>\
      var routeId = &#x27;route1&#x27;;<br>\
<br>\
      var rteCalcOptions = {<br>\
        start       : new Mfapi.Util.LonLat(139.692305587146767,35.69462305393875),<br>\
        via         : [new Mfapi.Util.LonLat(139.69615709913361,35.69347678961987)],<br>\
        destination : new Mfapi.Util.LonLat(139.6988151539445,35.693702766741)<br>\
      };<br>\
<br>\
      //### 経路描画条件&quot;rteDrawOptions&quot;の作成 ###<br>\
      // &quot;drawMarkerType&quot;はルートのマーカー描画タイプを指定するプロパティです。<br>\
      // &quot;drawMarkerType&quot;にカラーユニバーサルデザインに対応した設定値「STANDARD_ROUTE：標準デザインの標準サイズ」を設定します。<br>\
      // &quot;drawPolylineType&quot;はルートのポリライン描画タイプを指定するプロパティです。<br>\
      // &quot;drawPolylineType&quot;にカラーユニバーサルデザインに対応した設定値「STANDARD_ROUTE_COLOR_GREEN：グリーンの標準サイズ」を設定します。<br>\
      // 詳細は別紙「MapFanAPI_おもてなしマップご利用案内」の仕様をご参照下さい。<br>\
      var rteDrawOptions = {<br>\
        drawMarkerType   : Mfapi.Const.DrawMarkerType.STANDARD_ROUTE,<br>\
        drawPolylineType : Mfapi.Const.DrawPolylineType.STANDARD_ROUTE_COLOR_GREEN,<br>\
        geometryLayerId : &#x27;gLayer&#x27;,<br>\
        markerLayerId : &#x27;mLayer&#x27;<br>\
      };<br>\
<br>\
      var func = function(id) {<br>\
      };<br>\
<br>\
      Mfapi.Route.requestRouteCalcAndDraw(routeId,rteCalcOptions,rteDrawOptions,func);<br>\
<br>\
      //--- マーカーレイヤー、マーカー追加：サンプル３参照 ---<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### ポップアップ　フィーチャー識別子作成および条件セット ###<br>\
      // 詳細は別紙「MapFanAPI_おもてなしマップご利用案内」の仕様をご参照下さい。<br>\
      var popupId = &#x27;popup#1&#x27;;<br>\
      var popupOptions = {<br>\
        contentHtml : &quot;&lt;p style=&#x27;color:black;&#x27;&gt;Kadoshima Bridge&lt;br/&gt;&lt;img src=&#x27;./img/samplePicture.jpg&#x27; style=&#x27;width:80px; border:1px solid #808080;&#x27; /&gt;【&lt;a href=&#x27;http://www.mapfan.com/&#x27; target=&#x27;_blank&#x27; style=&#x27;color:#1784ff;&#x27;&gt;Website&lt;/a&gt;】&quot;,<br>\
        popUpType   : Mfapi.Const.PopUpType.STANDARD_WHITE,<br>\
        size        : new Mfapi.Util.ScreenSize(200,100),<br>\
        visible     : true<br>\
      };<br>\
<br>\
      Mfapi.Features.createPopUp(popupOptions, popupId);<br>\
<br>\
      //### マーカー　フィーチャー識別子作成および条件セット ###<br>\
      // &quot;imageUrl&quot;はユーザー指定イメージパスを指定するプロパティです。<br>\
      // &quot;imageUrl&quot;にカラーユニバーサルデザインに対応した設定値「./img/pin_cud1.png」を設定します。<br>\
      // 詳細は別紙「MapFanAPI_おもてなしマップご利用案内」の仕様をご参照下さい。<br>\
      var markerId = &#x27;marker#1&#x27;;<br>\
      var markerOptions = {<br>\
        popUpKey   : popupId,<br>\
        position   : new Mfapi.Util.LonLat(139.7037461199879,35.69480019636429),<br>\
        imageUrl   : &#x27;./img/pin_cud1.png&#x27;,<br>\
        imageSize  : new Mfapi.Util.ScreenSize(31,37),<br>\
        imageOffset: new Mfapi.Util.ScreenPoint(-16, -34)<br>\
      };<br>\
<br>\
      Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(markerOptions, markerId);<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--地図中心を示すパーツのDIVタグ--&gt;<br>\
  &lt;div id=&#x27;center_div&#x27;&gt;&lt;img id=&#x27;center_image&#x27; src=&#x27;img/center.png&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample17.html"
},

{
title: "1８.マーカー・図形の操作",
sum: "<p>マーカーオブジェクトを取得し、任意のスタイルに変更するコードが確認できます。</p>",
detail: "\
本サンプルでは、マーカーのDIVオブジェクトを取得し、そのオブジェクトにstyleを指定することでアニメーションや画像効果を付けるコードが確認できます。<br>\
CSS3の機能を使用しているため、一部ブラウザでは正常に表示されない場合があります。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１８&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
<br>\
    /* ### マーカー回転用のスタイル設定 ### */<br>\
    .markerSpin {<br>\
        /* 1.5秒間隔でspinのスタイルを呼び出します。 */<br>\
        animation: spin 4s linear infinite;<br>\
    }<br>\
    /* 360度回転させます。 */<br>\
    @keyframes spin {<br>\
        from {transform: rotate(0deg);}<br>\
        to {transform: rotate(360deg);}<br>\
    }<br>\
<br>\
    /* ### マーカー回転用のスタイル設定 ### */<br>\
    /* マーカーを-45度回転します。 */<br>\
    .markerRotateA {<br>\
      transform: rotate(-45deg);<br>\
    }<br>\
<br>\
    /* マーカーを240度回転します。 */<br>\
    .markerRotateB {<br>\
      transform: rotate(240deg);<br>\
    }<br>\
<br>\
    /* ### マーカー拡大用のスタイル設定 ### */<br>\
    /* カーソルが乗っている要素を2倍に拡大します。 */<br>\
    .markerAnimation:hover {<br>\
      animation-name: extend;<br>\
      animation-duration: 0.2s;<br>\
      animation-fill-mode: forwards;<br>\
    }<br>\
<br>\
    /* マーカーの足元を固定させます。 */<br>\
    /* margin-topの指定により画像の大きさによってオフセット位置を調節します。<br>\
       margin-topには画像が2倍時のオフセット位置を設定します。*/<br>\
    @keyframes extend {<br>\
        100% {<br>\
          margin-top: -11px;<br>\
          transform: scale(2);<br>\
        }<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１８．マーカーの操作 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### 地点データ列セット ###<br>\
      var pointData = [<br>\
        { name: &#x27;東京本社ビル&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;東京本社ビル&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/star.png&#x27;, width:48, height:48, x:-24, y:-36 },<br>\
        { name: &#x27;新橋営業所&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新橋営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 10:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;豊洲配送事業所&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;豊洲配送事業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/car.png&#x27;, width:48, height:48, x:-24, y:-30 },<br>\
        { name: &#x27;有明駅営業所&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;有明駅営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 11:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, imageUrl:&#x27;./img/car.png&#x27;, width:48, height:48, x:-24, y:-30 },<br>\
        { name: &#x27;品川営業所&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;品川営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;渋谷営業所&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;渋谷営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1 },<br>\
        { name: &#x27;新宿営業所&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新宿営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 ２４時間営業&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 6 }<br>\
      ];<br>\
<br>\
      //--- マーカーレイヤー追加：サンプル３参照 ---<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //--- マーカー、ポップアップ作成ループ処理：サンプル３参照 ---<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
<br>\
        //--- ポップアップ　フィーチャー識別子作成および条件セット：サンプル３参照 ---<br>\
        var id1 = &#x27;popup#&#x27;+i;<br>\
        var opt2 = {<br>\
          size : new Mfapi.Util.ScreenSize(180,80),<br>\
          popUpType : pointData[i].popUpType,<br>\
          contentHtml : pointData[i].text,<br>\
          visible : false<br>\
        };<br>\
<br>\
        //--- ポップアップ作成：サンプル３参照 ---<br>\
        Mfapi.Features.createPopUp(opt2, id1);<br>\
<br>\
        //--- マーカー　フィーチャー識別子作成および条件セット：サンプル３参照 ---<br>\
        var id2 = &#x27;marker#&#x27;+i;<br>\
        var opt2 = {<br>\
          position : new Mfapi.Util.LonLat(pointData[i].lon, pointData[i].lat),<br>\
          popUpKey : id1<br>\
        };<br>\
        if( pointData[i].imageUrl !== undefined ) {<br>\
          opt2.imageUrl = pointData[i].imageUrl;<br>\
          opt2.imageSize = new Mfapi.Util.ScreenSize(pointData[i].width, pointData[i].height);<br>\
          opt2.imageOffset = new Mfapi.Util.ScreenPoint(pointData[i].x, pointData[i].y);<br>\
          opt2.imageOpacity = 1;<br>\
        } else {<br>\
          opt2.markerType = pointData[i].markerType;<br>\
        }<br>\
<br>\
        //--- マーカー作成＆レイヤー追加：サンプル３参照 ---<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt2, id2);<br>\
      }<br>\
<br>\
      //### マーカーオブジェクト取得＆スタイル設定 ###<br>\
      var markers = Mfapi.Features.Marker;<br>\
      var className;<br>\
      if (markers) {<br>\
        for (var markerId in markers) {<br>\
          var markerObj = markers[markerId].getObject();<br>\
          if (!markerObj) continue;<br>\
          if (markerId == &quot;marker#0&quot;) {<br>\
            //### マーカーの回転アニメーション指定 ###<br>\
            className = &quot;markerSpin&quot;;<br>\
          } else if (markerId == &quot;marker#2&quot;) {<br>\
            //### マーカーの回転指定(-45度) ###<br>\
            className = &quot;markerRotateA&quot;;<br>\
          } else if (markerId == &quot;marker#3&quot;) {<br>\
            //### マーカーの回転指定(240度) ###<br>\
            className = &quot;markerRotateB&quot;;<br>\
          } else {<br>\
            //### マーカーの拡大縮小指定 ###<br>\
            className = &quot;markerAnimation&quot;;<br>\
          }<br>\
          // マーカーのオブジェクトを取得し、スタイルで使用するクラスを指定します。<br>\
          markerObj.setAttribute(&#x27;class&#x27;, className);<br>\
        }<br>\
      }<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample18.html"
},

{
title: "１９.地図移動開始・終了イベント",
sum: "<p>地図移動開始時、または地図移動終了時のイベントを取得し、任意のメソッドを実行するコードが確認できます。</p>",
detail: "\
本サンプルでは、地図移動開始時のイベントを取得し、ポップアップを一括非表示にするメソッドの実行、および地図移動終了時のイベントを取得し、ポップアップを再度表示するコードが確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル１９&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル１９．地図移動開始・終了イベント ＊＊＊<br>\
    <br>\
    //＊＊＊ 共通変数の宣言 ＊＊＊<br>\
    var _owner = this;<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### 地点データ列セット ###<br>\
      var pointData = [<br>\
        { name: &#x27;東京本社ビル&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;東京本社ビル&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/a.gif&#x27;, width:48, height:48, x:-24, y:-36, popUpVisible: false },<br>\
        { name: &#x27;新橋営業所&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新橋営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 10:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1, popUpVisible: false },<br>\
        { name: &#x27;豊洲配送事業所&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
          text: &#x27;&lt;div style=&quot;color:white;&quot;&gt;&lt;b&gt;豊洲配送事業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;/div&gt;&#x27;,<br>\
          popUpType: 2, imageUrl:&#x27;./img/b.gif&#x27;, width:48, height:48, x:-24, y:-30, popUpVisible: true },<br>\
        { name: &#x27;有明駅営業所&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;有明駅営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 11:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1, popUpVisible: false },<br>\
        { name: &#x27;品川営業所&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;品川営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-19:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1, popUpVisible: true },<br>\
        { name: &#x27;渋谷営業所&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;渋谷営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 8:00-21:00&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 1, popUpVisible: true },<br>\
        { name: &#x27;新宿営業所&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
          text: &#x27;&lt;div&gt;&lt;b&gt;新宿営業所&lt;/b&gt;&lt;br&gt;tel 03-XXXX-XXXX&lt;br&gt;営業時間 ２４時間営業&lt;/div&gt;&#x27;,<br>\
          popUpType: 1, markerType: 6, popUpVisible: false }<br>\
      ];<br>\
<br>\
      //--- マーカーレイヤー追加：サンプル３参照 ---<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### マーカー、ポップアップ作成ループ処理 ###<br>\
      for( var i=0; i&lt;pointData.length; i++ ) {<br>\
<br>\
        //### ポップアップ　フィーチャー識別子作成および条件セット ###<br>\
        // ポップアップ用にユニークなフィーチャー識別子 id1を生成します。<br>\
        // また、ポップアップ用の作成条件 opt1 を作成します。<br>\
        // 詳細はPopUpOptionsクラスの仕様をご参照下さい。<br>\
        var id1 = &#x27;popup#&#x27;+i;<br>\
        var opt1 = {<br>\
          size : new Mfapi.Util.ScreenSize(180,80),<br>\
          popUpType : pointData[i].popUpType,<br>\
          contentHtml : pointData[i].text,<br>\
          visible : pointData[i].popUpVisible<br>\
        };<br>\
<br>\
        //--- ポップアップ作成：サンプル３参照 ---<br>\
        Mfapi.Features.createPopUp(opt1, id1);<br>\
<br>\
        //--- マーカー　フィーチャー識別子作成および条件セット：サンプル３参照 ---<br>\
        var id2 = &#x27;marker#&#x27;+i;<br>\
        var opt2 = {<br>\
          position : new Mfapi.Util.LonLat(pointData[i].lon, pointData[i].lat),<br>\
          popUpKey : id1<br>\
        };<br>\
        if( pointData[i].imageUrl !== undefined ) {<br>\
          opt2.imageUrl = pointData[i].imageUrl;<br>\
          opt2.imageSize = new Mfapi.Util.ScreenSize(pointData[i].width, pointData[i].height);<br>\
          opt2.imageOffset = new Mfapi.Util.ScreenPoint(pointData[i].x, pointData[i].y);<br>\
          opt2.imageOpacity = 0.8;<br>\
        } else {<br>\
          opt2.markerType = pointData[i].markerType;<br>\
        }<br>\
<br>\
        //--- マーカー作成＆レイヤー追加：サンプル３参照 ---<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt2, id2);<br>\
      }<br>\
<br>\
      //### 地図移動開始のコールバック関数指定 ###<br>\
      Mfapi.Events.onMapMoveStart = mapMoveStart;<br>\
<br>\
      //### 地図移動終了のコールバック関数指定 ###<br>\
      Mfapi.Events.onMapMoveEnd = mapMoveEnd;<br>\
<br>\
    }<br>\
<br>\
    //### 地図移動開始イベント検出時の処理 ###<br>\
    function mapMoveStart(){<br>\
      //### 表示中のポップアップ識別子格納配列 ###<br>\
      // 地図移動開始時に表示中のポップアップの識別子を格納します。<br>\
      // 地図移動終了時に配列に格納されている識別子のポップアップのみ表示させます。<br>\
      // 識別子格納後、ポップアップ一括非表示処理メソッドを呼び出します。<br>\
      _owner.visiblePopUpList = [];<br>\
      var popUp = Mfapi.Features.PopUp;<br>\
      if (popUp) {<br>\
        for (var popUpKey in popUp) {<br>\
          //### ポップアップ表示状態取得 ###<br>\
          // ポップアップの場合のみdivのIDがポップアップ作成時に設定したフィーチャー識別子となります。<br>\
          // ポップアップが非表示の時はstyleのdisplay値が&#x27;none&#x27;となりますので、&#x27;none&#x27;以外のものをリストに格納します。<br>\
          var popUpDiv = document.getElementById(popUpKey);<br>\
          if (!popUpDiv) continue;<br>\
          if (popUpDiv.style.display != &#x27;none&#x27;) {<br>\
            _owner.visiblePopUpList.push(popUpKey);<br>\
          }<br>\
        }<br>\
      }<br>\
      Mfapi.Map.hidePopUpAll();<br>\
    }<br>\
<br>\
    //### 地図移動終了イベント検出時の処理 ###<br>\
    // 地図移動開始イベントで表示されているポップアップの識別子リスト(visiblePopUpList)に格納された識別子を表示させます。<br>\
    function mapMoveEnd(){<br>\
      var len = _owner.visiblePopUpList.length;<br>\
      var popUp = Mfapi.Features.PopUp;<br>\
      if (popUp && _owner.processFlg == false) {<br>\
        for (var i=0; i&lt;len; i++) {<br>\
          if (!popUp[_owner.visiblePopUpList[i]]) continue;<br>\
          popUp[_owner.visiblePopUpList[i]].setVisible(true);<br>\
        }<br>\
      }<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample19.html"
},

{
title: "20.ラベル表示",
sum: "<p>地点データ配列を用いたラベル表示設定の基本的なコードが確認できます。</p>",
detail: "\
地図作成後にマーカーレイヤーを追加します。<br>\
ラベルの条件をセットし、addLabelメソッドで、マーカーレイヤーへの登録が行われると地図上に表示されます。<br>\
マーカーとラベルを紐付ける場合は、ラベルの条件にマーカーのフィーチャー識別子をセット後addLabelメソッドを実行すると、紐付ける線を表示することができます。<br>\
また、ラベルをクリックすると最前面に表示するコードも確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル２０&lt;/title&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      width: 660px;<br>\
      height: 280px;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
    //＊＊＊ サンプル２０．ラベル表示 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
      //--- 認証結果確認と地図作成：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // 地図作成条件をセット。<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.7672311841094,35.66119593467379),<br>\
        mapScale : 12<br>\
      };<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
<br>\
      //### 地点データ列セット ###<br>\
      // ラベル表示するデータ<br>\
      var labelData = [<br>\
        { name: &#x27;ラベル１&#x27;, lon: 139.6606863619212, lat: 35.65864567145413,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;ラベル１&lt;/div&gt;&#x27;, x:0, y:0 },<br>\
        { name: &#x27;ラベル２&#x27;, lon: 139.6606863619212, lat: 35.65064567145413,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;ラベル２&lt;/div&gt;&#x27;, x:0, y:0 },<br>\
        { name: &#x27;ラベル３&#x27;, lon: 139.6606863619212, lat: 35.64264567145413,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;ラベル３&lt;/div&gt;&#x27;, x:0, y:0 }<br>\
      ];<br>\
<br>\
      // マーカーとラベルを紐付けるデータ<br>\
      var markerData = [<br>\
        { name: &#x27;東京本社ビル&#x27;, lon: 139.7672311841094, lat: 35.68119593467379,<br>\
          text: &#x27;&lt;div style=&quot;color:white;border:solid 1px #ee7800;background-color:black;&quot;&gt;東京本社ビル&lt;/div&gt;&#x27;, x:0, y:20 },<br>\
        { name: &#x27;新橋営業所&#x27;, lon: 139.75821002138233, lat: 35.66657238126213,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;新橋営業所&lt;/div&gt;&#x27;, x:-20, y:20 },<br>\
        { name: &#x27;豊洲配送事業所&#x27;, lon: 139.7959191978587, lat: 35.655211407306176,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;豊洲配送事業所&lt;/div&gt;&#x27;, x:0, y:-70 },<br>\
        { name: &#x27;有明駅営業所&#x27;, lon: 139.79315890678254, lat: 35.63467955160454,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;有明駅営業所&lt;/div&gt;&#x27;, x:-10, y:20 },<br>\
        { name: &#x27;品川営業所&#x27;, lon: 139.73875357500563, lat: 35.62850770123775,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;品川営業所&lt;/div&gt;&#x27;, x:-20, y:20 },<br>\
        { name: &#x27;渋谷営業所&#x27;, lon: 139.70134957426947, lat: 35.65864567145413,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;渋谷営業所&lt;/div&gt;&#x27;, x:-20, y:20 },<br>\
        { name: &#x27;新宿営業所&#x27;, lon: 139.70090283767686, lat: 35.68851826791775,<br>\
          text: &#x27;&lt;div style=&quot;color:black;border:solid 1px #000000;background-color:white;&quot;&gt;新宿営業所&lt;/div&gt;&#x27;, x:-20, y:20 }<br>\
      ];<br>\
<br>\
      //### マーカーレイヤー追加 ###<br>\
      // マーカーレイヤーを生成し、地図のあるDIVタグに追加します。<br>\
      Mfapi.Map.addMarkerLayer(&#x27;mLayer&#x27;);<br>\
<br>\
      //### ラベルを作成するループ処理 ###<br>\
      for( var i=0; i&lt;labelData.length; i++ ) {<br>\
        <br>\
        //### ラベル　フィーチャー識別子作成および条件セット ###<br>\
        // マーカーとの紐付けがないラベルを作成します。<br>\
        // ラベル用にユニークなフィーチャー識別子 id1を生成します。<br>\
        // また、ラベル用の作成条件 opt1 を作成します。<br>\
        // 詳細はLabelOptionsクラスの仕様をご参照下さい。<br>\
        // マーカーとの紐付けがないため、markerKeyは設定しません。<br>\
        var id1 = &#x27;label1#&#x27;+i;<br>\
        var opt1 = {<br>\
          position : new Mfapi.Util.LonLat(labelData[i].lon, labelData[i].lat),<br>\
          offset : new Mfapi.Util.ScreenPoint(labelData[i].x, labelData[i].y),<br>\
          contentHtml : labelData[i].text,<br>\
          visible : true<br>\
        };<br>\
<br>\
        //### ラベル作成＆レイヤー追加 ###<br>\
        // オブジェクト作成＋マーカーレイヤーへの登録を行います。<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addLabel(opt1, id1);<br>\
      }<br>\
<br>\
      //### マーカーに紐付けるラベルを作成するループ処理 ###<br>\
      for( var i=0; i&lt;markerData.length; i++ ) {<br>\
<br>\
        //### マーカー　フィーチャー識別子作成および条件セット ###<br>\
        // 詳細はMarkerOptionsクラスの仕様をご参照下さい。<br>\
<br>\
        var markerKey = null;<br>\
<br>\
        if (markerData[i].name) {<br>\
          var id1 = &#x27;marker#&#x27;+i;<br>\
          var opt1 = {<br>\
            position : new Mfapi.Util.LonLat(markerData[i].lon, markerData[i].lat)<br>\
          };<br>\
          //### マーカー作成＆レイヤー追加 ###<br>\
          // オブジェクト作成＋マーカーレイヤーへの登録を行います。<br>\
          Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addMarker(opt1, id1);<br>\
          // マーカーフィーチャー識別子を保持します。<br>\
          markerKey = id1;<br>\
        }<br>\
<br>\
        //### ラベル　フィーチャー識別子作成および条件セット ###<br>\
        // マーカーと紐付けるラベルを作成します。<br>\
        // マーカーと紐付けるため、markerKeyにマーカーのフィーチャー識別子を設定します。<br>\
        var id2 = &#x27;label2#&#x27;+i;<br>\
        var opt2 = {<br>\
          position : new Mfapi.Util.LonLat(markerData[i].lon, markerData[i].lat),<br>\
          offset : new Mfapi.Util.ScreenPoint(markerData[i].x, markerData[i].y),<br>\
          contentHtml : markerData[i].text,<br>\
          markerKey : markerKey,<br>\
          visible : true<br>\
        };<br>\
<br>\
        //### ラベル作成＆レイヤー追加 ###<br>\
        // オブジェクト作成＋マーカーレイヤーへの登録を行います。<br>\
        Mfapi.Map.MarkerLayer[&#x27;mLayer&#x27;].addLabel(opt2, id2);<br>\
      }<br>\
      <br>\
      // ### ラベル イベント登録 ###<br>\
      // ラベルクリック通知イベントに関数を設定します。<br>\
      // クリックしたラベルを最前面に表示します。<br>\
      // 詳細はEventsクラス、Labelクラスの仕様をご参照下さい。<br>\
      // コールバックで画面座標、緯度経度、ラベルのフィーチャー識別子を取得できます。<br>\
      Mfapi.Events.onLabelClick = function(screenPosition, mapPosition, featureId) {<br>\
        Mfapi.Features.Label[featureId].setForeground();<br>\
      };<br>\
<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27;&gt;&lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample20.html"
},

{
title: "21.VICS渋滞情報表示",
sum: "<p>VICS渋滞情報を表示するコードが確認できます。</p>",
detail: "\
本サンプルでは、指定した条件でVICS渋滞情報表示を行う基本的な処理のコードが確認できます。<br>\
また、表示する条件をチェックボックスで変更して再描画するコードも確認できます。\
",
src: "<pre>\
&lt;!DOCTYPE html&gt;<br>\
&lt;html&gt;<br>\
&lt;head&gt;<br>\
  &lt;meta http-equiv=&#x27;content-type&#x27; content=&#x27;text/html; charset=utf-8&#x27; /&gt;<br>\
  &lt;title&gt;MFAPIサンプル２１&lt;/title&gt;<br>\
  &lt;!--地図DIVのスタイル：<br>\
    本サンプルではフォーカスが当たったときに枠線が出ないように、outlineをnoneとしています。--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #sample_map {<br>\
      float: left;<br>\
      width: 440px;<br>\
      height: 290px;<br>\
      margin: 10px;<br>\
      padding: 0px;<br>\
      outline: none;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;!--地図中心を示すパーツのアイコン画像とDIVのスタイル：サンプル４参照--&gt;<br>\
  &lt;style type=&quot;text/css&quot;&gt;<br>\
    #info_window {<br>\
      margin: 4px;<br>\
      padding: 2px;<br>\
      position: absolute;<br>\
      top: 2px;<br>\
      left: 450px;<br>\
      width: 215px;<br>\
      height: 285px;<br>\
      background-color:#eeeeee;<br>\
    }<br>\
  &lt;/style&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27; src=&#x27;http://api-auth-pre.mapfan.com/v1/jslib/js/map/mfjsapi&#x27;&gt;&lt;/script&gt;<br>\
  &lt;script type=&#x27;text/javascript&#x27;&gt;<br>\
<br>\
    //＊＊＊ サンプル２１．VICS渋滞情報表示 ＊＊＊<br>\
<br>\
    //--- イニシャル処理：サンプル１参照 ---<br>\
    window.onload = function() {<br>\
      Mfapi.mapHost = &#x27;api-map-pre.mapfan.com&#x27;;<br>\
      // VICSのサーバーを指定します。<br>\
      // 詳細はサーバーAPI技術仕様書の付則 サーバーホスト一覧をご参照下さい。<br>\
      Mfapi.vicsHost = &#x27;api-vics-pre.mapfan.com&#x27;;<br>\
      Mfapi.auth(&#x27;＃＃＃ここにお客様の認証ＩＤを設定してください＃＃＃&#x27;,task_func);<br>\
    }<br>\
<br>\
    //--- 各種処理 ---<br>\
    function task_func(authStatus) {<br>\
<br>\
      //--- 認証結果確認：サンプル１参照 ---<br>\
      if( authStatus != &#x27;success&#x27; ) {<br>\
        return;<br>\
      }<br>\
<br>\
      //### 地図条件セット ###<br>\
      // このサンプルでは中心緯度経度とスケールに加え、VICS渋滞情報表示設定も指定します。<br>\
      // 詳細はMapOptionsクラスの仕様をご参照下さい。<br>\
      var options = {<br>\
        centerPosition : new Mfapi.Util.LonLat(139.767294067,35.680959631),<br>\
        mapScale : 14,<br>\
        vics : true<br>\
      };<br>\
<br>\
      //--- 地図作成：サンプル１参照 ---<br>\
      Mfapi.mapCreate(&#x27;sample_map&#x27;,options);<br>\
    }<br>\
    <br>\
    // 画面の設定ボタンを押下した際に呼ばれます。<br>\
    function setVics() {<br>\
      // チェックボックスの状態取得<br>\
      // 渋滞情報（渋滞/混雑）をチェックした場合、true<br>\
      var congestion =  document.getElementById(&quot;vicsCongestion&quot;).checked;<br>\
      // 渋滞情報（順調）をチェックした場合、true<br>\
      var fine =  document.getElementById(&quot;vicsFine&quot;).checked;<br>\
      // 規制情報をチェックした場合、true<br>\
      var restriction =  document.getElementById(&quot;vicsRestriction&quot;).checked;<br>\
      // 駐車場情報をチェックした場合、true<br>\
      var parking =  document.getElementById(&quot;vicsParking&quot;).checked;<br>\
<br>\
      // VICS渋滞情報表示条件作成<br>\
      var options = {<br>\
        vics : true,<br>\
        vicsCongestion : congestion,<br>\
        vicsFine : fine,<br>\
        vicsRestriction : restriction,<br>\
        vicsParking : parking<br>\
      };<br>\
      // VICS渋滞情報表示条件を地図にセット<br>\
      Mfapi.Map.setOptions(options);<br>\
    }<br>\
  &lt;/script&gt;<br>\
&lt;/head&gt;<br>\
&lt;body&gt;<br>\
  &lt;!--地図DIVタグ：地図画面にフォーカスがあたるようにtabindexを追記しています。--&gt;<br>\
  &lt;div id=&#x27;sample_map&#x27; tabindex=&#x27;1&#x27;&gt;&lt;/div&gt;<br>\
  &lt;!--情報表示DIVタグ--&gt;<br>\
  &lt;div id=&#x27;info_window&#x27;&gt;<br>\
    &lt;p&gt;VICS渋滞情報表示設定&lt;/p&gt;<br>\
    &lt;p&gt;&lt;input type=&quot;checkbox&quot; id=&quot;vicsCongestion&quot; checked&gt;渋滞情報（渋滞/混雑）&lt;/p&gt;<br>\
    &lt;p&gt;&lt;input type=&quot;checkbox&quot; id=&quot;vicsFine&quot;&gt;渋滞情報（順調）&lt;/p&gt;<br>\
    &lt;p&gt;&lt;input type=&quot;checkbox&quot; id=&quot;vicsRestriction&quot; checked&gt;規制情報&lt;/p&gt;<br>\
    &lt;p&gt;&lt;input type=&quot;checkbox&quot; id=&quot;vicsParking&quot; checked&gt;駐車場情報&lt;/p&gt;<br>\
    &lt;p class=&quot;center&quot;&gt;&lt;input type=&#x27;button&#x27; value=&quot;　適　用　&quot; onClick=&quot;setVics()&quot;&gt;&lt;/p&gt;<br>\
  &lt;/div&gt;<br>\
&lt;/body&gt;<br>\
&lt;/html&gt;<br>\
</pre>",
url: "./src/MfapiSample21.html"
}
];
